<!DOCTYPE html>
<html lang="zh">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"> 
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Jn——刷取任务创建</title>
    <!doctype html>
<html lang="zh-cmn-Hans">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, shrink-to-fit=no"/>
    <meta name="renderer" content="webkit"/>
    <meta name="force-rendering" content="webkit"/>
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"/>

<!-- MDUI CSS -->
    <link
      rel="stylesheet"
      href="https://unpkg.com/mdui@1.0.2/dist/css/mdui.min.css"

    />
       <body class="mdui-appbar-with-toolbar">
  <div class="mdui-appbar mdui-appbar-fixed mdui-appbar-scroll-hide">
    <div class="mdui-toolbar mdui-color-theme">
  <a href="javascript:window.history.back();" class="mdui-btn mdui-btn-icon"><i class="mdui-icon material-icons">keyboard_arrow_left</i></a>
  <span class="mdui-typo-title">Jn</span>
  <div class="mdui-toolbar-spacer"></div>
  
  

  <a href="javascript:location.reload();" class="mdui-btn mdui-btn-icon"><i class="mdui-icon material-icons">refresh</i></a>
<button class="mdui-btn mdui-btn-icon" mdui-menu="{target:'#main-menu'}"><i class="mdui-icon material-icons">more_vert</i></button>


          </div>
    </div>
        <script src="./js/mdui.min.js"></script>       <script>     if(localStorage.darkTheme)         document.body.classList.add("mdui-theme-layout-dark");      document.getElementById("switch-theme").addEventListener(         "click",         () => document.body.classList.toggle("mdui-theme-layout-dark") ?             (localStorage.darkTheme = true) :             (delete localStorage.darkTheme)     );  </script><p id="switch-theme">>点此切换黑白</p> <script>      if(localStorage.darkTheme)         document.body.classList.add("mdui-theme-layout-dark");           document.getElementById("switch-theme").addEventListener(         "click",         () => document.body.classList.toggle("mdui-theme-layout-dark") ?             (localStorage.darkTheme = true) :             (delete localStorage.darkTheme)     ); </script><script type="text/javascript" src="https://s9.cnzz.com/z_stat.php?id=1279812358&web_id=1279812358"></script></a>                   </li>             </ul>           </div>     </div>     
    <script src="./js/jquery.min.js"></script>
    <script type="text/javascript" charset="utf-8">
      $(window).scroll(function(){
        var scrollTop = $(window).scrollTop();
       if (scrollTop < 100) {
          $(".mdui-APPbar").removeClass("mdui-color-theme");
          $(".mdui-APPbar").addClass("mdui-text-color-black");
          $(".mdui-APPbar").removeClass("mdui-text-color-white")
       } else {
          $(".mdui-APPbar").addClass("mdui-text-color-white");
          $(".mdui-APPbar").addClass("mdui-color-theme");
          $(".mdui-APPbar").removeClass("mdui-text-color-black");
       }
      });
    </script>
  </head>
  <div class="mdui-ripple">
<div class="mdui-panel-item mdui-panel-item-open">
    <div class="mdui-panel-item-header">Jn刷浏览量</div>
    <div class="mdui-panel-item-body">
    
       <p>1，永久免费</p>
      <p>2，专属任务</p>
      <p>3，专属账号</p>
      <p>4，随机IP，无需担心封IP</p>
      <p>5，超大自定义数量</div>
    </div>
  </div>


<form action ="lll.php" method ="get">

<div class="mdui-textfield">
  <i class="mdui-icon material-icons">account_circle</i>
  <label class="mdui-textfield-label">刷取次数</label>
  <input name="k" class="mdui-textfield-input" type="text"value=""/>
  <div class="mdui-textfield-helper">1-∞</div>
</div>

<!-- 固定标签 -->
<div class="mdui-textfield">
  <i class="mdui-icon material-icons">account_circle</i>
  <label class="mdui-textfield-label">帖子ID</label>
  <input name="url" class="mdui-textfield-input" type="text"value=""/>
  
</div>


</div>

      <br><button class="mdui-btn mdui-btn-raised" mdui-dialog="{target: '#exampleDialog'}" input type ="submit"  />确认刷取
</button>

<div class="mdui-dialog" id="exampleDialog">
  <div class="mdui-dialog-title">我们正在使用Jn之力刷取浏览量</div>
  <div class="mdui-dialog-content">请保持前台运行，不要退出当前页面<div class="mdui-spinner mdui-spinner-colorful"></div></div>
  <div class="mdui-dialog-actions">
  
  </div>
</div></form>


</div>
    
<script>
  var tab = new mdui.Tab('#example4-tab');
  document.getElementById('example-4').addEventListener('open.mdui.dialog', function () {
    tab.handleUpdate();
  });
</script>
    


 
</body>

<!-- MDUI JavaScript -->
    <script
      src="https://unpkg.com/mdui@1.0.2/dist/js/mdui.min.js"

    ></script>
  
    <!--可无视-->
    <link rel="stylesheet" type="text/css" href="css/bootstrap-grid.min.css" /><!--CSS RESET-->

    
    <!--必要样式-->
    <link rel="stylesheet" href="css/naranja.min.css">
</head>
<body>