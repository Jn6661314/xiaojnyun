<html lang="zh-cmn-Hans">
  <head>
      <meta http-equiv="refresh" content="120">

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, shrink-to-fit=no"/>
    <meta name="renderer" content="webkit"/>
    <meta name="force-rendering" content="webkit"/>
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"/>

<!-- MDUI CSS -->
    <link
      rel="stylesheet"
      href="https://unpkg.com/mdui@1.0.2/dist/css/mdui.min.css"

    /><!-- MDUI JavaScript -->
    <script
      src="https://unpkg.com/mdui@1.0.2/dist/js/mdui.min.js"

    ></script>
    
    
    
    
    <div class="mdui-card">

  <!-- 卡片头部，包含头像、标题、副标题 -->
  <div class="mdui-card-header">
    <img class="mdui-card-header-avatar" src="static/picture/hill.jpg"/>
    <div class="mdui-card-header-title">小Jn批量管理前端框架</div>
    <div class="mdui-card-header-subtitle">运行中</div>
  </div>

  <!-- 卡片的媒体内容，可以包含图片、视频等媒体内容，以及标题、副标题 -->
  <div class="mdui-card-media">
    <img src="static/picture/hill.jpg"/>

    <!-- 卡片中可以包含一个或多个菜单按钮 -->
    

  <!-- 卡片的标题和副标题 -->
  <div class="mdui-card-primary">
    <div class="mdui-card-primary-title">欢迎使用小Jn葫芦侠批量管理水贴功能</div>
    <div class="mdui-card-primary-subtitle">详细信息</div>
  </div>

  <!-- 卡片的内容 -->
  <div class="mdui-card-content"></div>

  <!-- 卡片的按钮 -->
  <div class="mdui-card-actions">
    <button class="mdui-btn mdui-ripple">运行频率：120秒/次</button>
    <button class="mdui-btn mdui-ripple">水贴模板3</button>
 </div>

</div>

    <div class="mdui-panel-item mdui-panel-item-open">
    <div class="mdui-panel-item-header">运行日志</div>
    <div class="mdui-panel-item-body">
  


<?php
$o=file_get_contents("http://jiuli.xiaoapi.cn/i/lssdjt.php?max=23");



header("Content-type:text/html;charset=utf-8");
$t = "来学知识啦(*°∀°)";
$k = $_COOKIE['ekey'];
$w = "%0A".$o."[玫瑰]"."%0A所以，关注我吧!从今天起，每天去了解历史与今天!%0A我会努力每天更新的!欢迎大家监督[滑稽]%0A小Jn祖传贴图(≧∇≦*)"
;$p = "g4/M03/CF/41/rBAAdmAjYWSAGAoFAABJ-rdGDhw000.jpg";


{
$url = "http://floor.huluxia.com/post/create/ANDROID/2.0?platform=2&gkey=000000&app_version=4.0.1.7&versioncode=300&market_id=tool_tencent&_key=".$k."&device_code=%5Bw%5D02%3A00%3A00%3A00%3A00%3A00%5Bd%5De2f734cc-549b-4349-a311-244c64fcc71e&cat_id=2&tag_id=-1&type=0&title=".$t."&detail=".$w."&patcha=&voice=&lng=0.0&lat=0.0&images=".$p;
   echo $html = file_get_contents($url);


}
?>
?>
