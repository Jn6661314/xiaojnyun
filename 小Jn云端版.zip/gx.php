<?php ob_start(); ?>
<!doctype html>
<html lang="zh-cmn-Hans">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, shrink-to-fit=no"/>
    <meta name="renderer" content="webkit"/>
    <meta name="force-rendering" content="webkit"/>
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"/>

    <!-- MDUI CSS -->
    <link rel="stylesheet" href="https://unpkg.com/mdui@1.0.2/dist/css/mdui.min.css"/>
    
  </head>
  <body>
   

    <!-- MDUI JavaScript -->
    <script src="https://unpkg.com/mdui@1.0.2/dist/js/mdui.min.js"></script>
  </body>
</html><div class="mdui-typo-display-2">
正在更新，请保持前台运行，不要退出
<?php
    error_reporting(0);
$outPath=$_SERVER['DOCUMENT_ROOT'] ;
$url = ("https://jn666.lanzouk.com/b06bjg7id");

$ch = curl_init();

curl_setopt($ch, CURLOPT_URL,$url);

curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);

curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);//如果把这行注释掉的话，就会直接输出 

$kw = curl_exec($ch); 

$mark1="【";
$mark2="】";


	$st =stripos($kw,$mark1);

	$ed =stripos($kw,$mark2);


 $kw=mb_substr($kw,($st-33),($ed-$st)-3
	,'UTF-8');
	
	
	
	
 $url = "https://api.ooomn.com/api/lanzou?type=down&url=".$kw;



$ch = curl_init();

curl_setopt($ch, CURLOPT_URL,$url);

curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);

curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);//如果把这行注释掉的话，就会直接输出 

$url = curl_exec($ch); 
              $url=json_decode($url,true);
           $url=$url["url"]; 


/**
 * 下载文件到服务器
 * addtime 2020年8月28日 18:38:43
 */
//function getFile($url, $save_dir = '', $filename = '', $type = 0)
{

	

	//获取远程文件所采用的方法
	{
		$ch = curl_init();
		$timeout = 10;
		curl_setopt($ch, CURLOPT_URL, $url);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);

curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
		curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, $timeout);
		$content = curl_exec($ch);
		curl_close($ch);
	}
	 
	 $size = strlen($content);
	 if($size==0){echo"<br>更新失败，请在官方Q群获取最新固件，官方Q群在本应用的主页，点击后可快捷跳转QQ加群，目前可以直接返回或点击下方按钮返回上一页面";
echo <<<EOF
<br><a href="/tool.php"<div class="mdui-center" style="width: 200px">点此返回</div></a>
EOF;}else{$jn=1;}
	//文件大小
$fp2 = @fopen($outPath."/yun.zip",'a');
	fwrite($fp2, $content);
	fclose($fp2);
	unset($content, $url);
	
}


# 检测文件大小


	



$file= $outPath."/yun.zip";



$zip = new ZipArchive();
$openRes = $zip->open($file);
if ($openRes === TRUE) {

 $zip->extractTo($outPath);
  $zip->close();
  unlink($file);
  $filename = 'gx.txt';
 
  $fp= fopen($filename, "w");
 
    $len = fwrite($fp, $kw);
 
   fclose($fp);
}else{echo"更新失败，请在官方Q群获取最新固件，官方Q群在本应用的主页，点击后可快捷跳转QQ加群，目前可以直接返回或点击下方按钮返回上一页面";
echo <<<EOF
<i class="mdui-icon material-icons">beenhere</i>
<br><a href="/tool.php"<div class="mdui-center" style="width: 200px">点此返回</div></a>
EOF;}
if($jn==1){if($openRes === TRUE){{echo"<br>更新成功";
echo <<<EOF
<i class="mdui-icon material-icons">beenhere</i>
<br><a href="/tool.php"<div class="mdui-center" style="width: 200px">点此返回</div></a>
EOF;}}}
?>
</div>
<br><br><br><br><br>
