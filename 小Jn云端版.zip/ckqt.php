<!DOCTYPE html>
<html lang="zh">
<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"> 
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>小Jn——词库编辑</title>
	<!doctype html>
<html lang="zh-cmn-Hans">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, shrink-to-fit=no"/>
    <meta name="renderer" content="webkit"/>
    <meta name="force-rendering" content="webkit"/>
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"/>

<!-- MDUI CSS -->
    <link
      rel="stylesheet"
      href="https://unpkg.com/mdui@1.0.2/dist/css/mdui.min.css"

    />
        <body class="mdui-appbar-with-toolbar">
  <div class="mdui-appbar mdui-appbar-fixed mdui-appbar-scroll-hide">
    <div class="mdui-toolbar mdui-color-theme">
  <a href="javascript:window.history.back();" class="mdui-btn mdui-btn-icon"><i class="mdui-icon material-icons">keyboard_arrow_left</i></a>
  <span class="mdui-typo-title">小Jn</span>
  <div class="mdui-toolbar-spacer"></div>
  
  

  <a href="javascript:location.reload();" class="mdui-btn mdui-btn-icon"><i class="mdui-icon material-icons">refresh</i></a>
<button class="mdui-btn mdui-btn-icon" mdui-menu="{target:'#main-menu'}"><i class="mdui-icon material-icons">more_vert</i></button>

<ul class="mdui-menu" id="main-menu">

              	<li class="mdui-menu-item" >
                	<a href="/tool.php" class="mdui-ripple">首页</a>
              	</li>
              	<li class="mdui-menu-item" >
                	<a href="/jqrcz.php" class="mdui-ripple">批量管理</a>
              	</li>
              	<li class="mdui-menu-item" >
                	<a href="/box.php" class="mdui-ripple">工具箱</a>
              	</li>
              	<li class="mdui-menu-item" >
                	<a href="/site.php" class="mdui-ripple">分站</a>
              	</li>
            </ul>
  		</div>
	</div>
		<script src="./js/mdui.min.js"></script> 	  <script>     if(localStorage.darkTheme)         document.body.classList.add("mdui-theme-layout-dark");      document.getElementById("switch-theme").addEventListener(         "click",         () => document.body.classList.toggle("mdui-theme-layout-dark") ?             (localStorage.darkTheme = true) :             (delete localStorage.darkTheme)     );  </script><p id="switch-theme">>点此切换黑白</p> <script>      if(localStorage.darkTheme)         document.body.classList.add("mdui-theme-layout-dark");           document.getElementById("switch-theme").addEventListener(         "click",         () => document.body.classList.toggle("mdui-theme-layout-dark") ?             (localStorage.darkTheme = true) :             (delete localStorage.darkTheme)     ); </script><script type="text/javascript" src="https://s9.cnzz.com/z_stat.php?id=1279812358&web_id=1279812358"></script></a>               	</li>             </ul>   		</div> 	</div> 	
	<script src="./js/jquery.min.js"></script>
	<script type="text/javascript" charset="utf-8">
	  $(window).scroll(function(){
	    var scrollTop = $(window).scrollTop();
	   if (scrollTop < 100) {
	      $(".mdui-APPbar").removeClass("mdui-color-theme");
          $(".mdui-APPbar").addClass("mdui-text-color-black");
          $(".mdui-APPbar").removeClass("mdui-text-color-white")
	   } else {
	      $(".mdui-APPbar").addClass("mdui-text-color-white");
	      $(".mdui-APPbar").addClass("mdui-color-theme");
	      $(".mdui-APPbar").removeClass("mdui-text-color-black");
	   }
	  });
	</script>
  </head>
 
<h1>
<?php
ini_set("error_reporting","E_ALL & ~E_NOTICE");


       $filename='pl.txt';
      $ex=file_exists($filename);//检测文件存在与否
    

 
    if($_GET['txt']=='')
	{
		echo '<br>请填写完整';
	}
	else
	{





 $ex=file_exists($filename);//检测文件存在与否
    

   
    {
     if($ex!=1)
{
echo"词库创建成功!";
}
else {
    echo"<br>词库编辑成功";
}

$myfile = fopen($filename, "w") or die("Unable to open file!");//创建名字
fwrite($myfile, $_GET['txt']."");//写入词库内容


}
}
?>
<a href="/ckdiy.php"<div class="mdui-center" style="width: 200px">点此返回批量管理管理页面</div></a>