<?php ob_start(); ?>
<!doctype html>
<html lang="zh-cmn-Hans">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, shrink-to-fit=no"/>
    <meta name="renderer" content="webkit"/>
    <meta name="force-rendering" content="webkit"/>
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"/>

    <!-- MDUI CSS -->
    <link rel="stylesheet" href="https://unpkg.com/mdui@1.0.2/dist/css/mdui.min.css"/>
    
  </head>
  <body>
   

    <!-- MDUI JavaScript -->
    <script src="https://unpkg.com/mdui@1.0.2/dist/js/mdui.min.js"></script>
  </body>
</html>
<br>
<a href="/s.php">
<div class="mdui-chip">
  <span class="mdui-chip-icon"><i class="mdui-icon material-icons">refresh</i></span>
  <span class="mdui-chip-title">下一页</span>
</div>
</a>
<a href="/s.php?i=1">
<div class="mdui-chip">
  <span class="mdui-chip-icon"><i class="mdui-icon material-icons">refresh</i></span>
  <span class="mdui-chip-title">双击本按钮回到第一页</span>


</div></a>
<?php
error_reporting(0);
if($_GET["i"]!=null)
{
setrawcookie("wl","0",time()+3600 * 24 * 365);
ob_end_flush();
}
$j=$_COOKIE["wl"];
if($j==null){$j=0;}


  if($_COOKIE["ekey"]==null)

  {
Header("Location: /login.php");
ob_end_flush();
  }

$pl=file_get_contents("http://floor.huluxia.com/post/create/list/ANDROID/2.0?platform=2&gkey=000000&app_version=4.0.1.9.1&versioncode=309&market_id=tool_tencent&_key=".$_COOKIE["ekey"]."&device_code=%5Bw%5D02%3A00%3A00%3A00%3A00%3A00%5Bd%5De2f734cc-549b-4349-a311-244c64fcc71e&start=".$j."&count=20&user_id=".$_COOKIE["uid"]);

$jsonStr = $pl;

$arr = json_decode($pl,true);

$s=$arr["start"];

setcookie("wl",$s,time()+3600 * 24 * 365);
ob_end_flush();



echo "<br>当前页面的start值为:".$j;
echo "<br>下一页的start值为:".$s=$arr["start"];
echo"<br>当前页面内容预览";
for($i=0;$i<20;$i++)
{
//超级获取术
$pid=$arr["posts"][$i]["postID"];//postID
$bt=$arr["posts"][$i]["title"];//标题
$jj=$arr["posts"][$i]["detail"];//简介
$name=$arr["posts"][$i]["user"]["nick"];//昵称
$urlck='/post.php?pid='.$pid.'&page=1';//查看话题API
echo
<<<EOF
<html>
 <head> 
  <title>帖子列表-JnAPI</title> 
  <meta charset="utf-8"> 
  <!--响应式--> 
  <button type="button" class="btn btn-clear ih5-rel-button" style="border-radius: 25px; box-shadow: rgb(0, 0, 0) 3px 3px 5px; position: relative; cursor: inherit; flex-shrink: 0; background-color: rgb(255, 255, 255); transform-origin: 0% 0% 0px; width: 90%; font-size: 26px; color: rgb(0, 0, 0);"><div class="btn-content"><div style="overflow: inherit; position: relative;"><span>
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no"> 
  <script src="js/jq.js"></script> 
 </head> 
 <body id="v1"> 
  <p>$name</p>
  <br>
  <h3 id="v2">$bt</h3> 
  </br>
  <br>
  <h5>$jj</h5>
  
   <a href=$urlck style='color: gray; text-align: right;'".">查看话题</a>

  
 </span></div></div></button> 
 </body>
</html>
EOF;
}
?>