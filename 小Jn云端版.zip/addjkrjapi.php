<?php

$ip_long = array(
       array('607649792', '608174079'), //36.56.0.0-36.63.255.255
       array('1038614528', '1039007743'), //61.232.0.0-61.237.255.255
       array('1783627776', '1784676351'), //106.80.0.0-106.95.255.255
       array('2035023872', '2035154943'), //121.76.0.0-121.77.255.255
       array('2078801920', '2079064063'), //123.232.0.0-123.235.255.255
       array('-1950089216', '-1948778497'), //139.196.0.0-139.215.255.255
       array('-1425539072', '-1425014785'), //171.8.0.0-171.15.255.255
       array('-1236271104', '-1235419137'), //182.80.0.0-182.92.255.255
       array('-770113536', '-768606209'), //210.25.0.0-210.47.255.255
       array('-569376768', '-564133889'), //222.16.0.0-222.95.255.255
   );   $rand_key = mt_rand(0, 9);
   $ip= long2ip(mt_rand($ip_long[$rand_key][0], $ip_long[$rand_key][1]));
$filename= "vip/".$uid.".txt"; 
 $f2=str_replace("\n","",file_get_contents($filename));
 $zero1=strtotime (date("y-m-d")); //当前时间  ,注意H 是24小时 h是12小时 
$zero2=strtotime ($f2);  //到期时间，不能写2014-1-21 24:00:00  这样不对 
$guonian=ceil(($zero2-$zero1)/86400); //60s*60min*24h   
if($guonian>0){
$jn=100;   
}
else{
    $guonian=-$guonian;
    $jn=3; }

    

       $filename='jk/'.$uid.'.txt';
      $ex=file_exists($filename);//检测文件存在与否
    
  
   


if($ex==1)
{
    
    if($_POST['name']==null)
	{
		echo '请填写完整';
	}
	else
	{  $filename='jk/'.$uid.'.txt';
$myfilert2 = fopen($filename, "r") or die("Unable to open file!");
$f2 = fread($myfilert2,filesize($filename));
fclose($myfilert2);
$b=file($filename);
$c=count($b)/1;
}}


if ($c<$jn) {
    // code...

if(strpos($_POST["name"],"http") !== false){
    
if(strpos($f2,$_POST["name"]) == false){
    if($ex==1)
{
      $filename='jk/'.$uid.'.txt';
$myfile = fopen($filename, "w") or die("Unable to open file!");//创建名字
fwrite($myfile, $f2."\n");//写入旧内容
fwrite($myfile, $_POST['name']."&key=".$_POST['key']."&jkkey=".$_POST['jkkey']."&id=".$_POST['id']."&hz=".$_POST['hz']);//写入网址
fclose($myfile);
echo"新建监控成功";
}

else
{
if($ex==0)
{
      $filename='jk/'.$uid.'.txt';
$myfile = fopen($filename, "w") or die("Unable to open file!");//创建名字
fwrite($myfile, $_POST['name']."&key=".$_POST['key']."&jkkey=".$_POST['jkkey']."&id=".$_POST['id']."&hz=".$_POST['hz']);//写入网址
fclose($myfile);
echo '监控创建成功';
}
}

}}else
{
    echo"格式错误，请填写带http的监控地址！";
    
}
}else{echo"超出计划限制";}
?>