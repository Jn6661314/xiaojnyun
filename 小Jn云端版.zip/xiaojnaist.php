<title>小Jn自动水帖API</title>
<?php
$phoneNumber=$_GET["phone"];
$password=md5($_GET["key"]);
$result=file_get_contents("http://floor.huluxia.com/account/login/ANDROID/4.0?device_code=1&account=".$phoneNumber."&login_type=2&password=".$password);
$returnJson=json_decode($result,true);
$msg=$returnJson["msg"];
$key=$returnJson["_key"];
$uid=$returnJson["user"]["userID"];
if($msg!=null)
{echo"账号或密码错误";}else{
 $filename='stxz/'.$uid.'.txt';
      $ex=file_exists($filename);//检测文件存在与否
    
  
   


if($ex!=1)
{


$myfile = fopen($filename, "w") or die("Unable to open file!");//创建名字
fwrite($myfile, "1");//写入次数

fclose($myfile);
echo '<br>限制器创建成功';
    
	}
	else
	{
$myfilert2 = fopen($filename, "r") or die("Unable to open file!");
echo$f2 = fread($myfilert2,filesize($filename));
fclose($myfilert2);
$myfile = fopen($filename, "w") or die("Unable to open file!");//创建名字
fwrite($myfile, $f2+1);//写入次数

fclose($myfile);
echo '<br>限制器记录';

}

   if ($f2<6) {
       // code...
  
$a='wz.txt';
$b=file($a);
$c=count($b);
$d=rand(0,$c);
$e=trim($b[$d],"\n");

$gs='wz.txt';
$f=file($gs);
$h=count($f);
$z=rand(0,$h);
$o=trim($f[$z],"\n");
$gs='bt.txt';
$f=file($gs);
$h=count($f);
$z=rand(0,$h);
$titlex=trim($f[$z],"\n");

//获取一言
$file = file("tz.txt");

//随机读取一行
$arr  = mt_rand( 0, count( $file ) - 1 );
echo$content  = trim($file[$arr],"\n");

//获取评论图片轮换
$file2 = file("tp.txt");
//随机读取一行
$arr2  = mt_rand( 0, count( $file2 ) - 1 );

echo$tp  = trim($file2[$arr2],"\n");
//$tps=file_get_contents("http://api.lq520.club/api/hlxacg2.php?type=text");
//echo $tp=str_replace("http://cdn.u1.huluxia.com/","",$tps);

$t = $titlex;
$k = $key;
$w = "%0A".$e."[玫瑰]"."%0A".$o."%0A".$content."";
$p =$tp;



$url = "http://floor.huluxia.com/post/create/ANDROID/2.0?platform=2&gkey=000000&app_version=4.0.1.7&versioncode=300&market_id=tool_tencent&_key=".$k."&device_code=%5Bw%5D02%3A00%3A00%3A00%3A00%3A00%5Bd%5De2f734cc-549b-4349-a311-244c64fcc71e&cat_id=2&tag_id=-1&type=0&title=".$t."&detail=".$w."&patcha=&voice=&lng=0.0&lat=0.0&images=".$p;
   echo $html = file_get_contents($url);

}
else {
    echo"超过限制，不允许调用水帖";
}
}
?>
