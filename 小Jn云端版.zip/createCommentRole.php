<?php
if(mb_strlen($_GET["detail"])<5)
{
echo <<<EOF
<script>
confirm("内容不能少于5个字！");
var fromUrl=document.referrer;
window.location.href=fromUrl;
</script>
EOF;
}
else
{
$createCommentUrl="http://floor.huluxia.com/comment/create/ANDROID/2.0?platform=2&gkey=000000&app_version=4.0.0.7&versioncode=20141436&market_id=floor_huluxia&_key=".$_COOKIE["ekey"]."&device_code=%5Bw%5D02%3A00%3A00%3A00%3A00%3A00-%5Bi%5D866934037372573-%5Bs%5D89861119147385482175&post_id=".$_GET["pid"]."&comment_id=".$_GET["cid"]."&text=".$_GET["detail"]."&patcha=&images=&remindUsers=";
file_get_contents($createCommentUrl);
Header("Location: /post.php?pid=".$_GET["pid"]."&page=1");
}
?>