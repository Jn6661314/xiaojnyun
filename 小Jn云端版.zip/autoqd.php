<?php ob_start(); ?>
<!doctype html>
<html lang="zh-cmn-Hans">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, shrink-to-fit=no"/>
    <meta name="renderer" content="webkit"/>
    <meta name="force-rendering" content="webkit"/>
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"/>

    <!-- MDUI CSS -->
    <link rel="stylesheet" href="https://unpkg.com/mdui@1.0.2/dist/css/mdui.min.css"/>
    
  </head>
  <body>
   

    <!-- MDUI JavaScript -->
    <script src="https://unpkg.com/mdui@1.0.2/dist/js/mdui.min.js"></script>
  </body>
</html>
<div class="mdui-typo-display-2"><div class="mdui-center" style="width: 200px">
<?php
error_reporting(0);

$curl = curl_init();


$ip_long = array(
       array('607649792', '608174079'), //36.56.0.0-36.63.255.255
       array('1038614528', '1039007743'), //61.232.0.0-61.237.255.255
       array('1783627776', '1784676351'), //106.80.0.0-106.95.255.255
       array('2035023872', '2035154943'), //121.76.0.0-121.77.255.255
       array('2078801920', '2079064063'), //123.232.0.0-123.235.255.255
       array('-1950089216', '-1948778497'), //139.196.0.0-139.215.255.255
       array('-1425539072', '-1425014785'), //171.8.0.0-171.15.255.255
       array('-1236271104', '-1235419137'), //182.80.0.0-182.92.255.255
       array('-770113536', '-768606209'), //210.25.0.0-210.47.255.255
       array('-569376768', '-564133889'), //222.16.0.0-222.95.255.255
   );
   $rand_key = mt_rand(0, 9);
   $ip= long2ip(mt_rand($ip_long[$rand_key][0], $ip_long[$rand_key][1]));
$header = array("Connection: Keep-Alive","Accept: text/html, application/xhtml+xml, */*", "Pragma: no-cache", "Accept-Language: zh-Hans-CN,zh-Hans;q=0.8,en-US;q=0.5,en;q=0.3","User-Agent: okhttp/3.8.1");

	curl_setopt($curl,CURLOPT_URL,'http://floor.huluxia.com/account/login/ANDROID/4.0?platform=2&gkey=000000&app_version=4.1.1.6.2&versioncode=335&market_id=tool_tencent&_key=&phone_brand_type=UN&device_code=[d]16485814-230d-424c-8af1-fda8f42d1e25&password='.md5($_GET["key"]).'&login_type=2&account='.$_GET["phone"]."%0A");
	curl_setopt($curl,CURLOPT_RETURNTRANSFER,1);
	curl_setopt($curl,CURLOPT_CONNECTTIMEOUT,10);
	curl_setopt($curl,CURLOPT_FOLLOWLOCATION,1);
	curl_setopt($curl, CURLOPT_HTTPHEADER, $header);
	//curl_setopt($curl,CURLOPT_HTTPHEADER,['X-FORWARDED-FOR:164.89.81.12','CLIENT-IP:164.89.81.12']);
	curl_setopt($curl,CURLOPT_REFERER,'');
	curl_setopt($curl,CURLOPT_USERAGENT,'okhttp/3.8.1');
	$post= curl_exec($curl);
	curl_close($curl);
	$arr = json_decode($post, true);
// Access values from the associative array

$jnsb=$arr["_key"];
if($jnsb!=null){
//{echo'{"key":'.$arr["_key"].', "uid":'.$arr["user"]["userID"].'}';
echo"good";
$userMsg=file_get_contents("http://floor.huluxia.com/user/info/ANDROID/2.1?_key=".$jnsb."&user_id=".$arr["user"]["userID"]);
$user=json_decode($userMsg,true);
$name=$user["nick"];
$returnJson=json_decode($post,true);
echo $msg=$returnJson["msg"];
$key=$returnJson["_key"];
$uid=$returnJson["user"]["userID"];




}else{echo"登录失败";}


$getCatJson=file_get_contents("http://floor.huluxia.com/category/list/ANDROID/2.0?platform=2&gkey=000000&app_version=4.2.0.4.2&versioncode=20141472&market_id=floor_web&_key="."&phone_brand_type=OP&is_hidden=1");

$catArray=json_decode($getCatJson,true);
$cats=$catArray["categories"];
$cats[count($cats)+1]["categoryID"] = 15;	//葫芦山
$cats[count($cats)+1]["categoryID"] = 34;	//审核部
$cats[count($cats)+1]["categoryID"] = 94;	//三楼活动
$cats[count($cats)+1]["categoryID"] = 84;	//三楼精选
$cats[count($cats)+1]["categoryID"] = 69;	//优秀资源
$cats[count($cats)+1]["categoryID"] = 67;	//MC帖子
$cats[count($cats)+1]["categoryID"] = 68;	//资源审核


//读取
echo$qd=file_get_contents("qd/".$uid.'.txt');
if($qd==null)
{
$catOid=0;
//写入
   $filename = "qd/".$uid.'.txt';
 
   $fp= fopen($filename, "w");
 
   $len = fwrite($fp, $catOid);
 
   fclose($fp);
   
echo'<div class="mdui-spinner mdui-spinner-colorful"></div>';
 echo"正在高仿人类速度以随机速度签到<br>已签到:".$catOid."个<br>共:".count($cats)."个";
 $wl=100*$catOid/count($cats);
 $cid=$cats[$catOid]["categoryID"];
$t=(int)(microtime(true)*1000);
 $txt="cat_id".$cid."time".$t."fa1c28a5b62e79c3e63d9030b6142e4b";
//写入
   $filename = "sign/".$uid.'.txt';
 
   $fp= fopen($filename, "w");
 
   $len = fwrite($fp, $txt);
 
   fclose($fp);
//读取
$myfile = fopen("sign/".$uid.'.txt', "r") or die("Unable to open file!");
$sign=fread($myfile,filesize("sign/".$uid.'.txt'));
fclose($myfile);
$sign = md5($sign);

function send_post($url, $post_data) {
 
  $postdata = http_build_query($post_data);
  $options = array(
    'http' => array(
        "Host"=>"floor.huluxia.com",
      'method' => 'POST',
      'Content-type' => 'application/x-www-form-urlencoded',
      'content' => $postdata,
      "User-Agent"=>'okhttp/3.8.1',
      "Accept-Encoding"=>"identity",
      "Content-Length"=>'37',
      'timeout' => 1 * 5 // 超时时间（单位:s）
    )
  );
  $context = stream_context_create($options);
  $result = file_get_contents($url, false, $context);
  
$arr = json_decode($result, true);
// Access values from the associative array
  
 	$arr = json_decode($result, true);
 	 $msg=$arr["status"];
 	  $msg2=$arr["msg"];
 	 if($msg=="1"){echo"<br>当前板块签到成功";}else{echo$msg2;}
 
  return $result;
  $cid=$cats[$catOid]["categoryID"];
$t=(int)(microtime(true)*1000);
 $txt="cat_id".$cid."time".$t."fa1c28a5b62e79c3e63d9030b6142e4b";
//写入
   $filename = "sign/".$uid.'.txt';
 
   $fp= fopen($filename, "w");
 
   $len = fwrite($fp, $txt);
 
   fclose($fp);
//读取
$myfile = fopen("sign/".$uid.'.txt', "r") or die("Unable to open file!");
$sign=fread($myfile,filesize("sign/".$uid.'.txt'));
fclose($myfile);
$sign = md5($sign);

function send_post($url, $post_data) {
 
  $postdata = http_build_query($post_data);
  $options = array(
    'http' => array(
        "Host"=>"floor.huluxia.com",
      'method' => 'POST',
      'Content-type' => 'application/x-www-form-urlencoded',
      'content' => $postdata,
      "User-Agent"=>'okhttp/3.8.1',
      "Accept-Encoding"=>"identity",
      "Content-Length"=>'37',
      'timeout' => 1 * 5 // 超时时间（单位:s）
    )
  );
  $context = stream_context_create($options);
  $result = file_get_contents($url, false, $context);
  
$arr = json_decode($result, true);
// Access values from the associative array
  
 	$arr = json_decode($result, true);
 	 $msg=$arr["status"];
 	  $msg2=$arr["msg"];
 	 if($msg=="1"){echo"<br>当前板块签到成功";}else{echo$msg2;}
 
  return $result;
  $post_data = array(
"sign"=>$sign
);

send_post("http://floor.huluxia.com/user/signin/ANDROID/4.1.8?platform=2&gkey=000000&app_version=4.2.0.5&versioncode=20141475&market_id=floor_web&_key=".$key."&phone_brand_type=OP&cat_id=".$cid."&time=".$t,$post_data);
}
//Header("Location:/autosign.php?jn=0");ob_end_flush();
}}else{
    if($qd<count($cats))
    {
    $catOid=$qd+1;
   // $cd=0.1*rand(5,12);
// echo'<meta http-equiv="refresh" content="'.$cd.';url=/autosign.php?jn='.$catOid.' "> ';
//写入
   $filename = "qd/".$uid.'.txt';
 
   $fp= fopen($filename, "w");
 
   $len = fwrite($fp, $catOid);
 
   fclose($fp);
   
echo'<div class="mdui-spinner mdui-spinner-colorful"></div>';
 echo"正在高仿人类速度以随机速度签到<br>已签到:".$catOid."个<br>共:".count($cats)."个";
 $wl=100*$catOid/count($cats);
 echo <<<EOF
<div class="mdui-progress">
  <div class="mdui-progress-determinate" style="width:  $wl%;"></div>
</div>
EOF;
}else{
echo <<<EOF
<i class="mdui-icon material-icons">&#xe5ca;</i>
EOF;
echo"已全部签到完成<br>请不要理我后面那个破玩意说什么参数不能为空→";}
{
$cid=$cats[$catOid]["categoryID"];
$t=(int)(microtime(true)*1000);
 $txt="cat_id".$cid."time".$t."fa1c28a5b62e79c3e63d9030b6142e4b";
//写入
   $filename = "sign/".$uid.'.txt';
 
   $fp= fopen($filename, "w");
 
   $len = fwrite($fp, $txt);
 
   fclose($fp);
//读取
$myfile = fopen("sign/".$uid.'.txt', "r") or die("Unable to open file!");
$sign=fread($myfile,filesize("sign/".$uid.'.txt'));
fclose($myfile);
$sign = md5($sign);

function send_post($url, $post_data) {
 
  $postdata = http_build_query($post_data);
  $options = array(
    'http' => array(
        "Host"=>"floor.huluxia.com",
      'method' => 'POST',
      'Content-type' => 'application/x-www-form-urlencoded',
      'content' => $postdata,
      "User-Agent"=>'okhttp/3.8.1',
      "Accept-Encoding"=>"identity",
      "Content-Length"=>'37',
      'timeout' => 1 * 5 // 超时时间（单位:s）
    )
  );
  $context = stream_context_create($options);
  $result = file_get_contents($url, false, $context);
  
$arr = json_decode($result, true);
// Access values from the associative array
  
 	$arr = json_decode($result, true);
 	 $msg=$arr["status"];
 	  $msg2=$arr["msg"];
 	 if($msg=="1"){echo"<br>当前板块签到成功";}else{echo$msg2;}
 
  return $result;
}
 
//使用方法：GET本JnAPI接口两参数就完事了，分别是phone和key
$post_data = array(
"sign"=>$sign
);

send_post("http://floor.huluxia.com/user/signin/ANDROID/4.1.8?platform=2&gkey=000000&app_version=4.2.0.5&versioncode=20141475&market_id=floor_web&_key=".$key."&phone_brand_type=OP&cat_id=".$cid."&time=".$t,$post_data);


}
}
?>
