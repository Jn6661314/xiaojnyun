

<!doctype html>
<html lang="zh-cmn-Hans">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, shrink-to-fit=no"/>
    <meta name="renderer" content="webkit"/>
    <meta name="force-rendering" content="webkit"/>
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"/>

<!-- MDUI CSS -->
    <link
      rel="stylesheet"
      href="https://unpkg.com/mdui@1.0.2/dist/css/mdui.min.css"

    />
  </head>
  <body>
    

<!-- MDUI JavaScript -->
    <script
      src="https://unpkg.com/mdui@1.0.2/dist/js/mdui.min.js"

    ></script>
  </body>
</html>
<meta charset="utf-8" name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=0.5, maximum-scale=2.0, user-scalable=yes"/>
<style>
.center
{
text-align: center;
margin: auto;
}
input
{
width:80%;
height:30px;
}
button
{
width: 80%;
height: 30px;
}
</style>
</head>
<body>
<div class="center">
<p>乞讨间隔(单位:秒)</p>
<form action="/jnqthl.php" method="get">
<input type="text" name="t" placeholder="输入间隔" /><br>
间隔最好在十秒或以上<br>

<button class="mdui-btn mdui-btn-raised" type="submit">开始回复</button>
</form>
<p>请不要退出该页面，退出则停止乞讨</p>


