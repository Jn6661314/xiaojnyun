<?php
error_reporting(0);
$postJson=file_get_contents("http://floor.huluxia.com/post/detail/ANDROID/2.3?post_id=".$_GET["pid"]);
$postArray=json_decode($postJson,true);
?>

<!doctype html>
<html>
<head>
<title><?php echo $postArray["post"]["title"]; ?> - 葫芦侠三楼</title>
<meta charset="utf-8" name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=0.5, maximum-scale=2.0, user-scalable=yes"/>

<script>
function message()
{
window.location.href="message.php";
}
function back()
{
var fromUrl=document.referrer;
window.location.href=fromUrl;
}
</script>

<style>
a{text-decoration:none;color:rgb(14,188,224);}
hr{border:none;border-bottom:1px solid #DaDaDa; height:1px;-webkit-transform: scaleY(0.5);-webkit-transform-origin:0 0;}
p{font-size:13px;}
.top
{
z-index: 1;
background: rgb(81,215,48);
width: 100%;
height: 8%;
position: fixed;
top: 0;
left: 0;
right: 0;
border-bottom: 1px solid #4ECF2F;
}
.top h3
{
font-weight: lighter;
color: white;
font-size: 15px;
text-align: center;
}

.top #msg
{
position: fixed;
top: 0;
width: 100%;
}
.top #return
{
position: fixed;
top: 0;
width: 100%;
}
.top #msg button
{
border: none;
background-color: rgb(81,215,48);
float: right;
outline: none;
}
.top #msg img
{
width: 50%;
}

.top #return button
{
border: none;
background-color: rgb(81,215,48);
float: left;
outline: none;
}
.top #return img
{
width: 50%;
}



</style>
</head>
<body>


<div class="top">







<h3>帖子</h3>

<div id="msg">
<br>
<button onclick="message()">
<img src="/create/images/message.png"/>
</button>
</div>

<br>
<div id="return">

<br>
<button onclick="back()">
<img src="/create/images/back.png"/>
</button>


</div>
</div>

<br><br><br>

<?php
$title=$postArray["post"]["title"];
$detail=nl2br($postArray["post"]["detail"]);
$detail=str_replace(array(",","<image>","</image>"),array("?","<img src='","' style='width:100%;'/>"),$detail);
$images=$postArray["post"]["images"];

$uid=$postArray["post"]["user"]["userID"];
$nick=$postArray["post"]["user"]["nick"];
$avatar=$postArray["post"]["user"]["avatar"];

$createPostCommentUrl="createPostComment.php?pid=".$_GET["pid"]."&cid=0&page=".$_GET["page"];


$userUrl="user.php?uid=".$uid;
echo <<<EOF
<h4>$title</h4><hr>
<a href= $userUrl ><img src= $avatar style="width:10%" referrerPolicy="no-referrer" referrerPolicy="no-referrer"/><span>$nick</span><span></a><hr>
<p>$detail</p>
EOF;

if(!empty($images))
{
for($imgOid=0;$imgOid<count($images);$imgOid++)
{
if($imgOid==2||$imgOid==5)
{
echo "<img style='width:105px;height:105px;' src=".$images[$imgOid].' referrerPolicy="no-referrer" />&nbsp;<br>';
}
else
{
echo "<img style='width:105px;height:105px;' src=".$images[$imgOid].' referrerPolicy="no-referrer"/>&nbsp;';
}
}

echo "<br><a href='".$createPostCommentUrl."' style='color: gray; text-align: right;'".">回复</a>";

}
else
{

echo "<br><a href='".$createPostCommentUrl."' style='color: gray; text-align: right;'".">回复</a>";

}

//评论区....
$commentJson=file_get_contents("http://floor.huluxia.com/post/detail/ANDROID/2.3?post_id=".$_GET["pid"]."&page_no=".$_GET["page"]."&page_size=20");
$commentArray=json_decode($commentJson,true);
$comments=$commentArray["comments"];
$pageCommentNum=count($comments);
$commentNum=$postArray["post"]["commentCount"];

echo "<hr>评论".$commentNum."<hr>";


for($commentOid=0;$commentOid<$pageCommentNum;$commentOid++)
{
  $commentID=$comments[$commentOid]["commentID"];
  $commentText=nl2br($comments[$commentOid]["text"]);
  $commentImg=$comments[$commentOid]["images"];
  
  $commentUserNick=$comments[$commentOid]["user"]["nick"];
  $commentUserID=$comments[$commentOid]["user"]["userID"];
  $commentUserAvatar=$comments[$commentOid]["user"]["avatar"];
  
  $commentUserUrl="user.php?uid=".$commentUserID;
  
  $createCommentUrl="create/createComment.php?pid=".$_GET["pid"]."&cid=".$commentID."&page=".$_GET["page"];
  
  echo <<<EOF
  <a href= $commentUserUrl ><img src= $commentUserAvatar style="width:8%" referrerPolicy="no-referrer"/><span style="font-size:13px;">$commentUserNick</span></a>
  &nbsp;&nbsp;&nbsp;&nbsp;
  <p>$commentText</p>
EOF;
if(!empty($commentImg))
{
for($commentImgOid=0;$commentImgOid<count($commentImg);$commentImgOid++)
{
if($commentImgOid==2||$commentImgOid==5)
{
echo <<<EOF
<img style='width:105px;height:105px;' src=$commentImg[$commentImgOid] referrerPolicy="no-referrer" referrerPolicy="no-referrer"/>&nbsp;<br>
EOF;

echo "<br><a href='".$createCommentUrl."' style='color: gray; text-align: right;'".">回复</a>";

}
else
{
echo <<<EOF
<img style='width:105px;height:105px;' src=$commentImg[$commentImgOid] referrerPolicy="no-referrer"/>&nbsp
EOF;

echo "<br><a href='".$createCommentUrl."' style='color: gray; text-align: right;'".">回复</a>";

}
}
}
else
{

echo "<a href='".$createCommentUrl."' style='color: gray; text-align: right;'".">回复</a>";

}
echo "<hr>";
}

echo "<br><br>";

if(!($_GET["page"]==1))
{
$previousPage=$_GET["page"]-1;
$previousPageUrl="post.php?pid=".$_GET["pid"]."&page=".$previousPage;
echo <<<EOF
<div style="text-align: center;"><a href= $previousPageUrl style="background-color: #CCCCCC;border-radius: 2px;color: white;">上一页</a>
EOF;
}
else
{
echo "<div style='text-align: center;'>";
}

echo "  第 ".$_GET["page"]." 页  ";

$nextPage=$_GET["page"]+1;
$issetNextPageJson=file_get_contents("http://floor.huluxia.com/post/detail/ANDROID/2.3?post_id=".$_GET["pid"]."&page_no=".$nextPage."&page_size=20");
$issetNextPageArray=json_decode($issetNextPageJson,true);
$issetNextPage=$issetNextPageArray["comments"];
if($issetNextPage!=null)
{
$nextPageUrl="post.php?pid=".$_GET["pid"]."&page=".$nextPage;
echo <<<EOF
<a href= $nextPageUrl style="background-color: #CCCCCC;border-radius: 2px;color: white;">下一页</a></div>
EOF;
}
else
{
echo "</div>";
}



?>

</body>
</html>

<!--$_GET["pid"]帖子id
$postArray["post"]["title"]//["detail"]//["images"]-->






<!--回帖提示消息区-->

<?php

?>