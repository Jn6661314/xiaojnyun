<!doctype html>
<html>
    <head>
        <title>发布帖子 - 葫芦侠三楼</title>
        <meta charset="utf-8" name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=0.5, maximum-scale=2.0, user-scalable=yes" />
        <style>
            hr{border:none;border-bottom:1px solid #DaDaDa; height:1px;-webkit-transform: scaleY(0.5);-webkit-transform-origin:0 0;}
            .top
            {
            z-index: 1;
            background: rgb(81,215,48);
            width: 100%;
            height: 8%;
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            border-bottom: 1px solid #4ECF2F;
            }
            .top h3
            {
            font-weight: lighter;
            color: white;
            font-size: 15px;
            text-align: center;
            }

            .top #msg
            {
            position: fixed;
            top: 0;
            width: 100%;
            }
            .top #return
            {
            position: fixed;
            top: 0;
            width: 100%;
            }
            .top #msg button
            {
            border: none;
            background-color: rgb(81,215,48);
            float: right;
            outline: none;
            }
            .top #msg img
            {
            width: 50%;
            }

            .top #return button
            {
            border: none;
            background-color: rgb(81,215,48);
            float: left;
            outline: none;
            }
            .top #return img
            {
            width: 50%;
            }
            
            .postmsg
            {
            height: 90%;
            width: 100%;
            text-align: center;
            }
            
            form input
            {
            width: 100%;
            outline: none;
            border: none;
            height: 30px;
            }
            form textarea
            {
            width: 100%;
            outline: none;
            border: none;
            height: 400px;
            }
            form button
            {
            height: 40px;
            width: 95%;
            border: none;
            border-radius: 5px;
            background-color: #0099FF;
            outline: none;
            }
            form select
            {
            height: 20px;
            width: 25%;
            border: none;
            border-radius: 1px;
            float: right;
            outline: none;
            }
        </style>
        <script>
            
        </script>
    </head>
    <body>
    
   <!--判断是否登陆-->
<?php
error_reporting(0);
if($_COOKIE["ekey"]==null)

  {
    Header("Location: /login.php");
  }
?>
        <div class="top">

        <h3>发帖</h3>

        <div id="msg">
            <br>
            <button onclick="message()">
                <img src="/create/images/message.png"/>
            </button>
        </div>

        <br>
        <div id="return">

            <br>
            <button onclick="back()">
                <img src="/create/images/back.png"/>
            </button>

        </div>
        
        </div>
        <br><br><br>
        
        <div class="postmsg">
            <form action="createPostRole.php" method="get">
                <input type="text" minlength="5" maxlength="32" placeholder="请输入标题，5~32个字符" name="title" />
                <hr>
                <textarea minlength="5" maxlength="2000" placeholder="请输入内容，5~2000个字符" name="detail"></textarea>
                <?php
                
                $category=file_get_contents("http://floor.huluxia.com/post/list/ANDROID/2.1?start=0&count=0&cat_id=".$_GET["cid"]."&sort_by=0");
                $category=json_decode($category,true);
                $tag=$category["category"]["tags"];
                
                if($tag!=null)
                {
                
                
                echo "<select name='tid'>";
                
                for($i=0;$i<count($tag);$i++)
                {
                 $tid=$tag[$i]["ID"];
                 $tagName=$tag[$i]["name"];
                    echo <<<EOF
                    <option value=$tid>$tagName</option>
EOF;
                    
                    }
                echo "</select>";
                }
                ?>
                <input type="text" name="cid" value=<?php echo $_GET["cid"]; ?> style="display:none;"/>
                <input type="text" name="oid" value=<?php echo $_GET["oid"]; ?> style="display:none;"/>
                 <br><br>
                <button type="submit">发布</button>
            </form>
        </div>
    </body>
</html>
<?php
if(!$_GET["c"]=="")
{
echo '<script>window.alert("'.$_GET["c"].'");</script>';
}
?>