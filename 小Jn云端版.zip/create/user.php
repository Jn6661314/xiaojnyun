<?php
error_reporting(0);
  if($_COOKIE["ekey"]==null)

  {
    Header("Location: /login.php");
  }
  ?><!doctype html>
<html>



<?php
$userMsg=file_get_contents("http://floor.huluxia.com/user/info/ANDROID/4.1.8?_key=".$_COOKIE["ekey"]."&user_id=".$_GET["uid"]);
$user=json_decode($userMsg,true);

$nick=$user["nick"];
$avatar=$user["avatar"];
$age=$user["age"];
$credits=$user["credits"];
$integral=$user["integral"];
$integralNick=$user["integralNick"];
$identityTitle=$user["identityTitle"];
$level=$user["level"];
$exp=$user["exp"];
$follow=$user["followingCount"];
$fans=$user["followerCount"];
$post=$user["postCount"];
$comment=$user["commentCount"];
$favorite=$user["favoriteCount"];
$medal=$user["medalList"];
$photo=$user["photos"];
$background=$user["space"]["imgurl"];
$signature=$user["signature"];
$school=$user["schoolInfo"]["school_name"];
$tag=$user["tags"];
$location=$user["beenLocations"];
$urltz="/tzck.php?uid=".$_GET["uid"];
?>




<head>
<title>用户信息 - 葫芦侠三楼</title>
<meta charset="utf-8" name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=0.5, maximum-scale=2.0, user-scalable=yes"/>

<script>
function message()
{
window.location.href="message.php";
}
function back()
{
window.location.href="index.php";
}
</script>

<style>

hr{border:none;border-bottom:1px solid #DaDaDa; height:1px;-webkit-transform: scaleY(0.5);-webkit-transform-origin:0 0;}

body
{
background-image: url(<?php echo '"'.$background.'"'; ?>);
background-repeat: no-repeat;
background-size: 100%;
background-attachment:fixed;
background-position: 0% -8%;
}

a{text-decoration:none;color:rgb(14,188,224);}
hr{border:none;border-bottom:1px solid #DaDaDa; height:1px;-webkit-transform: scaleY(0.5);-webkit-transform-origin:0 0;}
p{font-size:13px;}
.top
{
z-index: 1;
background: rgb(81,215,48);
width: 100%;
height: 8%;
position: fixed;
top: 0;
left: 0;
right: 0;
border-bottom: 1px solid #4ECF2F;
}
.top h3
{
font-weight: lighter;
color: white;
font-size: 15px;
text-align: center;
}

.top #msg
{
position: fixed;
top: 0;
width: 100%;
}
.top #return
{
position: fixed;
top: 0;
width: 100%;
}
.top #msg button
{
border: none;
background-color: rgb(81,215,48);
float: right;
outline: none;
}
.top #msg img
{
width: 50%;
}

.top #return button
{
border: none;
background-color: rgb(81,215,48);
float: left;
outline: none;
}
.top #return img
{
width: 50%;
}

.user
{
width: 100%;
background-color: rgba(255,255,255,0.5);
padding-top: 10px;
margin: auto;
border-radius: 3px;
margin-top: 30px;
}
.user #avatar
{
width: 12%;
border-radius: 5px;
}
.value
{
color: gray;
}

.user #msg button
{
border: none;
background-color: rgba(255,255,255,0.0);
width: 20%;
outline: none;
}

.medal
{
width: 100%;
background-color: rgba(255,255,255,0.5);
margin: auto;
border-radius: 3px;
margin-top: 5px;
padding-top: 10px;
}
.medal img
{
width: 10%;
}
.photo
{
width: 100%;
background-color: rgba(255,255,255,0.5);
margin: auto;
border-radius: 3px;
margin-top: 5px;
padding-top: 10px;
}
.photo img
{
width: 80px;
height: 80px;
border-radius: 3px;
}

.self
{
width: 100%;
background-color: rgba(255,255,255,0.5);
margin: auto;
border-radius: 3px;
margin-top: 5px;
padding-top: 10px;
}
.self div
{
border-radius: 5px;
background-color: rgb(81,215,48);
width: 20%;
display: inline;
}

</style>
</head>
<body>





<br><br><br>

<?php
if($_COOKIE["ekey"]==null)
{
    Header("Location: login.php");
  }


?>

<div class="back">

</div>


<div class="user">

<?php
echo <<<EOF
&nbsp;&nbsp;<img src= $avatar id="avatar" referrerPolicy="no-referrer"/>
<span>$nick</span><br>
<p>&nbsp;&nbsp; $integral($integralNick)<font class="value"> 贡献值</font>&nbsp;&nbsp;&nbsp;&nbsp;$credits <font class="value">葫芦</font></p>
EOF;
?>

<hr>

<div id="msg">
<?php
echo <<<EOF
<button>
<a href=$urltz>
$post
<br>
帖子
</button></a><button>
$comment
<br>
评论
</button><button>
$follow
<br>
关注
</button><button>
$fans
<br>
粉丝
</button><button>
$favorite
<br>
收藏
</button>
EOF;
?>
<br><br>
</div>



</div>



<div class="medal">

<b>&nbsp;&nbsp;勋章</b>
<br>
<?php
if(!empty($medal))
{
for($medalF=0;$medalF<count($medal);$medalF++)
{
$medalImg=$medal[$medalF]["url"];
echo <<<EOF
<img src= $medalImg referrerPolicy="no-referrer"/>
EOF;
}
}

?>

</div>


<div class="photo">

<b>&nbsp;&nbsp照片</b>
<br>
<?php
if(!empty($photo))
{
for($photoF=0;$photoF<count($photo);$photoF++)
{
$photoImg=$photo[$photoF]["url"];
if($photoF==3)
{
echo <<<EOF
<img src= $photoImg referrerPolicy="no-referrer"/><br>
EOF;
}
else
{
echo <<<EOF
<img src= $photoImg referrerPolicy="no-referrer"/>&nbsp;
EOF;
}
}
}
?>


</div>


<div class="self">


<b>&nbsp;&nbsp个人信息</b>
<br>
<?php
echo <<<EOF
<p>&nbsp;&nbsp签名 <font class="value"> $signature</font></p>
<p>&nbsp;&nbsp学校 <font class="value"> $school</font></p>
EOF;
?>
<br>
<b>&nbsp;&nbsp去过的地方</b>
<br>
<?php
if(!empty($location))
{
for($locationF=0;$locationF<count($location);$locationF++)
{
$locationName=$location[$locationF];
echo <<<EOF
<div>$locationName</div>&nbsp;
EOF;
}
}
?>
<br><br>
<b>&nbsp;&nbsp标签</b>
<br>

<?php
if(!empty($tag))
{
for($tagF=0;$tagF<count($tag);$tagF++)
{
$tagName=$tag[$tagF]["title"];
echo <<<EOF
<div>$tagName</div>&nbsp;
EOF;
}
}
?>

</div>








</body>

</html>