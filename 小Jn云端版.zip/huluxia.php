<!doctype html>
<html lang="zh-cmn-Hans">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, shrink-to-fit=no"/>
    <meta name="renderer" content="webkit"/>
    <meta name="force-rendering" content="webkit"/>
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"/>

    <!-- MDUI CSS -->
    <link rel="stylesheet" href="https://unpkg.com/mdui@1.0.2/dist/css/mdui.min.css"/>
    
  </head>
  <body>
   

    <!-- MDUI JavaScript -->
    <script src="https://unpkg.com/mdui@1.0.2/dist/js/mdui.min.js"></script>
  </body>
</html>
<!--
Author:姬香文文酱
Email:690777645@qq.com
QQ:690777645

Copyright © 文文. All Rights Reserved.
文文 版权所有
-->

<!doctype html>
<html>
<head>
	<meta charset="UTF-8">
	<title>葫芦侠ID获取工具</title>
	<style>
body {
		text-align:center;
	}
	input {
		width:90%;
		height:40px;
		outline:none;
		border:none;
		border-bottom:1px solid black;
	}
	button {
		width:90%;
		height:40px;
		color:white;
		border:none;
		background-color:#4169E1;
		border-radius:5px;
	}
	.avatar img {
		height:60px;
		border-radius:50%;
	}
	table {
		width: 100%;
		border: 1px solid gray;
		border-collapse: collapse;
	}
	table td {
		border: 1px solid dimgray;
	}
	table thead {
		background-color: #dcdcdc;
	}
	table thead td {
		height:30px;
	}
	</style>
</head>
<body>
	<form action="" method="get">
		<input type="text"  placeholder="请输入需要查询的用户ID"name="gzuid"value="<?=$_COOKIE['uid']?>" ><br><br>
		<button type="submit" >查询关注前100</button><br><br>
	</form>
	<form action="" method="get">
		<input type="text"  placeholder="请输入需要查询的用户ID"name="fsuid"value="<?=$_COOKIE['uid']?>" ><br><br>
		<button type="submit"  >查询粉丝前100</button><br><br>
	</form>
	<?php
	if($_COOKIE["uid"] != null) {
	?>
	<h2>查询结果: </h2>
	<table>
	<thead>
	<tr>
		<td><b>用户头像</b></td>
		<td><b>昵称</b></td>
		<td><b>UID</b></td>
	</tr>
</thead>
	<?php
		$follow = file_get_contents("http://floor.huluxia.com/friendship/following/list/ANDROID/4.1.8?user_id={$_COOKIE['uid']}&count=100&start=0");
		$follow = json_decode($follow,true);
		echo $follow["msg"];
		for($i = 0;$i < count($follow["friendships"]);$i ++) {
	?>
	<tr>
		<td class="avatar"><img src="<?=$follow['friendships'][$i]['user']['avatar']?>" referrerPolicy="no-referrer"/></td>
		<td class="nick"><?=$follow['friendships'][$i]['user']['nick']?></td>
		<td class="uid"><?=$follow['friendships'][$i]['user']['userID']?></td>
	</tr>
	<?php
		}
	}
	?>
	<?php
    	if($_COOKIE["uid"] != null) {
    	?>
    	<table>
    	<thead>
    	<tr>
		<td><b>用户头像</b></td>
		<td><b>昵称</b></td>
		<td><b>UID</b></td>
    	</tr>
    </thead>
    	<?php
    		$follow = file_get_contents("http://floor.huluxia.com/friendship/follower/list/ANDROID/4.1.8?user_id={$_COOKIE['uid']}&count=100&start=0");
    		$follow = json_decode($follow,true);
    		echo $follow["msg"];
    		for($i = 0;$i < count($follow["friendships"]);$i ++) {
    	?>
    	<tr>
    		<td class="avatar"><img src="<?=$follow['friendships'][$i]['user']['avatar']?>" referrerPolicy="no-referrer"/></td>
    		<td class="nick"><?=$follow['friendships'][$i]['user']['nick']?></td>
    		<td class="uid"><?=$follow['friendships'][$i]['user']['userID']?></td>
    	</tr>
    	<?php
    		}
    	}
    	?>
	</table>
	</body>
    </html>