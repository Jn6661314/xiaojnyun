【【
 <?php
header("Expires: Mon, 26 Jul 1997 05:00:00 GMT");//内容过期时间 强制浏览器去服务器去获取数据 而不是从缓存中读取数据
header("Last-Modified: " . gmdate("D, d M Y H:i:s") . " GMT");//标记内容最后修改时间
header("Cache-Control: no-store, no-cache, must-revalidate");//强制不缓存
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");//禁止本页被缓存
header("Access-Control-Allow-Origin: *"); // Support CORS

$dqdz=$_SERVER['HTTP_HOST'];
ini_set("error_reporting","E_ALL & ~E_NOTICE");
if($_COOKIE["phone"]!=null)
{
$phoneNumber=$_COOKIE["phone"];
$password=$_COOKIE["key"];
$r=$_COOKIE["key"];
$result=file_get_contents("http://floor.huluxia.com/account/login/ANDROID/4.0?device_code=1&account=".$phoneNumber."&login_type=2&password=".$password);
$returnJson=json_decode($result,true);
$msg=$returnJson["msg"];
$key=$returnJson["_key"];
$uid=$returnJson["user"]["userID"];
    
     $filename2='jk3/'.$uid.'.txt';

$jnx=file($filename2);

 $filename='jk3/'.$uid.'.txt';
 $ex=file_exists($filename);//检测文件存在与否
if($ex==1)
{
$b=file($filename);
$c=count($b)/1;
$d=$c;
$myfilert = fopen("og3.txt", "r") or die("Unable to open file!");
$f = fread($myfilert,filesize("key.txt"));
fclose($myfilert);
for($i=0;$i<$c;$i++)
{
    
$name=$b[1*$i];
  $name=str_replace("\n","",$name);
  echo <<<EOF
  
-$name+$f# 


EOF;

}
}
else {
   echo
   <<<EOF
- 大佬，你还一个监控+都没有呢#
EOF;
    
    
}}


?>
】
