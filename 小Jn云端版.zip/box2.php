
<?php
ini_set("error_reporting","E_ALL & ~E_NOTICE");

$getCatJson=file_get_contents("http://floor.huluxia.com/user/info/ANDROID/4.1.8?platform=2&gkey=000000&app_version=4.2.0.4.2&versioncode=20141472&market_id=floor_web&_key=".$_COOKIE["ekey"]."&device_code=%5Bd%5D16485814-230d-424c-8af1-fda8f42d1e25&phone_brand_type=UN&user_id=".$_COOKIE["uid"]);
$catArray=json_decode($getCatJson,true);
$cats=$catArray["msg"];
if($cats==null){

$uid=$_COOKIE["uid"];
    
 $filename='xiaojnroobots/'.$uid.'.txt';

$b=file($filename);
$c=count($b)/4;
$d=$c;
$i=$_GET["id"];

$name=$b[4*$i];
$phone=$b[1+$i*4];
$keyj=$b[4*$i+2];
$gn=$b[4*$i+3];


}
?>
<div class="mdui-card">

  <!-- 卡片头部，包含头像、标题、副标题 -->
  <div class="mdui-card-header">
    <img class="mdui-card-header-avatar" src="static/picture/hill.jpg"/>
    <div class="mdui-card-header-title"><?php echo$name; ?></div>
    <div class="mdui-card-header-subtitle"><?php echo $phone;?></div>
  </div>

  <!-- 卡片的媒体内容，可以包含图片、视频等媒体内容，以及标题、副标题 -->
  <div class="mdui-card-media">
    <img src="card.webp"/>

    <!-- 卡片中可以包含一个或多个菜单按钮 -->
    <div class="mdui-card-menu">
    
    </div>
  </div>

  <!-- 卡片的标题和副标题 -->
  <div class="mdui-card-primary">
    <div class="mdui-card-primary-title"><?php echo $name; ?></div>
    <div class="mdui-card-primary-subtitle"><?php echo$phone; ?></div>
  </div>

  <!-- 卡片的内容 -->
  <div class="mdui-card-content">「    
  
  

<?php
//获
$file = file("wz.txt");
 
//随机读取一行
$arr  = mt_rand( 0, count( $file ) - 1 );
echo$content  = $file[$arr];
 

?>
」</div>

  <!-- 卡片的按钮 -->
  <div class="mdui-card-actions">

  </div>

</div>

<!DOCTYPE html>
<html lang="zh">
<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"> 
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>小Jn——工具箱</title>
	<!doctype html>
<html lang="zh-cmn-Hans">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, shrink-to-fit=no"/>
    <meta name="renderer" content="webkit"/>
    <meta name="force-rendering" content="webkit"/>
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"/>

<!-- MDUI CSS -->
    <link
      rel="stylesheet"
      href="https://unpkg.com/mdui@1.0.2/dist/css/mdui.min.css"

    />
    <body class="mdui-appbar-with-toolbar">
  <div class="mdui-appbar mdui-appbar-fixed mdui-appbar-scroll-hide">
    <div class="mdui-toolbar mdui-color-theme">
  <a href="javascript:;" mdui-drawer="{target: '#left-drawer'}"class="mdui-btn mdui-btn-icon"><i class="mdui-icon material-icons">menu</i></a>
  <span class="mdui-typo-title">小Jn-批量管理前端</span>
  <div class="mdui-toolbar-spacer"></div>
  
  

 
  <a href="javascript:;" onClick="narn('success')" class="mdui-btn mdui-btn-icon"><i class="mdui-icon material-icons">more_vert</i></a>
</div>
</div>
  </head>

<div class="mdui-ripple">

<ul class="mdui-list">
  
   <a href="/xiaojn666.php?u=<?php echo$_GET["u"]; ?>&id=<?php echo$_GET["id"]; ?>">
  <li class="mdui-list-item mdui-ripple">
    <i class="mdui-list-item-avatar mdui-icon material-icons">assistant_photo</i>
    <div class="mdui-list-item-content">傻瓜式一键运行</div>
  </li>
<a href="/jqrqd.php?id=<?php echo$_GET["id"]; ?>">
  <li class="mdui-list-item mdui-ripple">
    <i class="mdui-list-item-avatar mdui-icon material-icons">assistant_photo</i>
    <div class="mdui-list-item-content">高级版自定义运行</div>
  </li>
</ul>

</div>
    
<script>
  var tab = new mdui.Tab('#example4-tab');
  document.getElementById('example-4').addEventListener('open.mdui.dialog', function () {
    tab.handleUpdate();
  });
</script>
   



</body>

<!-- MDUI JavaScript -->
    <script
      src="https://unpkg.com/mdui@1.0.2/dist/js/mdui.min.js"

    ></script>
  
	<!--可无视-->
	<link rel="stylesheet" type="text/css" href="css/bootstrap-grid.min.css" /><!--CSS RESET-->

	
	<!--必要样式-->
	<link rel="stylesheet" href="css/naranja.min.css">
</head>
<body>
	
	<div class="container">
		<div class="row" style="padding:2em 0">
			<div class="col-md-2">
		
<div style="margin: 0 auto; width: 0%; position: fixed; bottom: 5px; height: 100％; font-size: 0; line-height: 0; z-index: 100; text-align: left;">

	
		</div></div>
	</div>


<script>
  var tab = new mdui.Tab('#example4-tab');
  document.getElementById('example-4').addEventListener('open.mdui.dialog', function () {
    tab.handleUpdate();
  });
</script>
	
	<script type="text/javascript" src="js/naranja.js"></script>
	<script type="text/javascript">
		function narn (type) {
		    naranja()[type]({
		      title: '你好',
		      text: '我们的小Jn控制面板正在内测',
		      timeout: 'keep',
		      buttons: [{
		        text: '知道了',
		        click: function (e) {
		          naranja().success({
		            title: '通知',
		            text: '知道了就好'
		          })
		        }
		      },{
		        text: '取消',
		        click: function (e) {
		          e.closeNotification()
		        }
		      }]
		    })
		  }
		  	function narn2 (type) {
		    naranja()[type]({
		      title: 'API使用教程',
		      text: '更改中文字段，挂上监控即可自动运行',
		      timeout: 'keep',
		      buttons: [{
		        text: '知道了',
		        click: function (e) {
		          naranja().success({
		            title: '来自小Jn的通知:',
		            text: '希望你学会了，改个文字对你来说应该问题不大!'
		          })
		        }
		      },{
		        text: '取消',
		        click: function (e) {
		          e.closeNotification()
		        }
		      }]
		    })
		  }
	</script>
</body>
</html>