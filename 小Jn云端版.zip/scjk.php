<?php
header("Location:/jkcz.php");
ini_set("error_reporting","E_ALL & ~E_NOTICE");

$getCatJson=file_get_contents("http://floor.huluxia.com/user/info/ANDROID/4.1.8?platform=2&gkey=000000&app_version=4.2.0.4.2&versioncode=20141472&market_id=floor_web&_key=".$_COOKIE["ekey"]."&device_code=%5Bd%5D16485814-230d-424c-8af1-fda8f42d1e25&phone_brand_type=UN&user_id=".$_COOKIE["uid"]);
$catArray=json_decode($getCatJson,true);
$cats=$catArray["msg"];
if($cats==null){

$uid=$_COOKIE["uid"];
    
 $filename='jk/'.$uid.'.txt';
unlink($filename);

}