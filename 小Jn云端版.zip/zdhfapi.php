
<?php
ini_set("display_errors","off");
//name
if($_GET["name"]=null)
{
$name2="小Jn";
}
else{
    $name2=substr($_GET["name"],0,strlen($_GET["name"])-1);
    }

//评论获取
$pl2=file_get_contents("http://floor.huluxia.com/message/new/list/ANDROID/4.0?platform=2&gkey=000000&app_version=4.0.1.9.1&versioncode=309&market_id=tool_tencent&_key=".$_COOKIE["ekey"]."&device_code=%5Bw%5D02%3A00%3A00%3A00%3A00%3A00%5Bd%5De2f734cc-549b-4349-a311-244c64fcc71e&type_id=2&start=0&count=2");
$arr2 = json_decode($pl2,true);
//超级获取术
echo"他人评论内容：".$a=$arr2["datas"][0]["content"]["text"];//评论内容
echo";该评论人ID:".$user=$arr2["datas"][0]["content"]["user"]["userID"];//用户ID
$tx=$arr2["datas"][0]["content"]["user"]["avatar"];//头像
echo";该评论人昵称:".$name=$arr2["datas"][0]["content"]["user"]["nick"];//昵称

$ys=$arr2["datas"][0]["content"]["seq"];//楼层
echo";评论ID:".$plid=$arr2["datas"][0]["content"]["commentID"];//评论ID
//tzid获取
$get = "http://floor.huluxia.com/message/new/list/ANDROID/4.0?platform=2&gkey=000000&app_version=4.0.1.7&versioncode=300&market_id=tool_tencent&_key=".$_COOKIE["ekey"]."&device_code=%5Bw%5D02%3A00%3A00%3A00%3A00%3A00%5Bd%5De2f734cc-549b-4349-a311-244c64fcc71e&type_id=2&start=0&count=1";
   $pl = file_get_contents($get);
    $pl_begin = mb_strpos($pl,',"title":"') + mb_strlen(',"title":"');//提取的开始位置
$pl_end = mb_strpos($pl,'","ext":null,"detail":null,"') - $pl_begin;//提取的结束位置
$plw = mb_substr($pl,$pl_begin,$pl_end);
$h = $plw;
$id = file_get_contents($get);
    $id_begin = mb_strpos($id,'{"postID":') + mb_strlen('{"postID":');//提取的开始位置
$id_end = mb_strpos($id,',"title":"'.$h) - $id_begin;//提取的结束位置
$tzid = mb_substr($id,$id_begin,$id_end);



//读取记录
$myfilert2 = fopen("1.txt", "r") or die("Unable to open file!");
$f2 = fread($myfilert2,filesize("1.txt"));
fclose($myfilert2);

//判断评论
if(strpos($a,'我要关注') !== false)
{
//执行关注
    $gzdf = "http://floor.huluxia.com/friendship/follow/ANDROID/2.0?user_id=".$user."&platform=2&gkey=000000&app_version=4.0.1.7&versioncode=300&market_id=tool_tencent&_key=".$_COOKIE["ekey"]."&device_code=%5Bw%5D02%3A00%3A00%3A00%3A00%3A00%5Bd%5De2f734cc-549b-4349-a311-244c64fcc71e";
   echo "关注返回信息".$gzgzgz = file_get_contents($gzdf);
   
$url3 = "http://floor.huluxia.com/comment/create/ANDROID/2.0?platform=2&gkey=000000&app_version=4.0.1.7&versioncode=300&market_id=tool_tencent&_key=".$_COOKIE["ekey"]."&device_code=%5Bw%5D02%3A00%3A00%3A00%3A00%3A00%5Bd%5De2f734cc-549b-4349-a311-244c64fcc71e&post_id=".$tzid."&comment_id=".$plid."&text=关注你了！互关吗？".$str;
     $zt = file_get_contents($url3);
     $jsonStr = $zt;

$arr2 = json_decode($zt,true);
     echo";处理状态：" .$plw=$arr2["msg"]; 
 
}

if(eregi($plid,$f2))
{echo"包含";}else{

//处理评论
$url2 = "http://". $_SERVER['HTTP_HOST']."/jnjqrapi.php?name=".$name2."&q=".$a;
   echo";批量管理回复内容：" .$html = file_get_contents($url2)."[滑稽][玫瑰]".$str;
  }
  //API异常
    if($html=="[滑稽][玫瑰]")
   {$html="小Jn召唤成功!".$str;}  
   //回复
$url3 = "http://floor.huluxia.com/comment/create/ANDROID/2.0?platform=2&gkey=000000&app_version=4.0.1.7&versioncode=300&market_id=tool_tencent&_key=".$_COOKIE["ekey"]."&device_code=%5Bw%5D02%3A00%3A00%3A00%3A00%3A00%5Bd%5De2f734cc-549b-4349-a311-244c64fcc71e&post_id=".$tzid."&comment_id=".$plid."&text=".$html;
     $zt = file_get_contents($url3);
     $jsonStr = $zt;
$arr2 = json_decode($zt,true);
     echo";处理状态：" .$plw=$arr2["msg"]; 
setrawcookie("Texttotry",$plid,time()+360);
 

//记录

    $myfile2 = fopen("1.txt", "w") or die("Unable to open file!");
$txt2 = $f2.$plid."\n";
fwrite($myfile2, $txt2);
fclose($myfile2);
?>
