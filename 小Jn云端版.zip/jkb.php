<?php
$wz=$_SERVER['HTTP_HOST'];
$a=file_get_contents("http://".$wz."/jkapi2.php");
  $myfile = fopen("jk2.txt", "w") or die("Unable to open file!");

fwrite($myfile,$a);
fclose($myfile);
//读取记录

$f=file("jk2.txt");

		echo$c=count($f);

for($i=0;$i<$c;$i++)
{
    echo $f[$i];

     file_get_contents($f[$i]);}
 