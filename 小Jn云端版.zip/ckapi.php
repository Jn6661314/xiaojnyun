<?php
ini_set("display_errors", "off");
$uid=$_GET["uid"];
//获取请求
@$q = $_GET['q'];
//判断参数

//获取仓ck.txt数据
$ck = file_get_contents("ck/".$uid.'.txt');
$ck = json_decode($ck);
foreach($ck as $key=>$value){
  if($q==$key){
    echo 
    <<<EOF
    $value
EOF;
 
  }
}



?>