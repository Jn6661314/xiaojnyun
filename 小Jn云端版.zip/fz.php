<!doctype html>
<html lang="zh-cmn-Hans">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, shrink-to-fit=no"/>
    <meta name="renderer" content="webkit"/>
    <meta name="force-rendering" content="webkit"/>
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"/>

    <!-- MDUI CSS -->
    <link
      rel="stylesheet"
      href="https://unpkg.com/mdui@1.0.2/dist/css/mdui.min.css"

    />
    <title>小Jn发展史</title>
  </head>
  <body>
        <body class="mdui-appbar-with-toolbar">
  <div class="mdui-appbar mdui-appbar-fixed mdui-appbar-scroll-hide">
    <div class="mdui-toolbar mdui-color-theme">
  <a href="javascript:window.history.back();" class="mdui-btn mdui-btn-icon"><i class="mdui-icon material-icons">keyboard_arrow_left</i></a>
  <span class="mdui-typo-title">小Jn</span>
  <div class="mdui-toolbar-spacer"></div>
  
  

  <a href="javascript:location.reload();" class="mdui-btn mdui-btn-icon"><i class="mdui-icon material-icons">refresh</i></a>
<button class="mdui-btn mdui-btn-icon" mdui-menu="{target:'#main-menu'}"><i class="mdui-icon material-icons">more_vert</i></button>

<ul class="mdui-menu" id="main-menu">

              	<li class="mdui-menu-item" >
                	<a href="/tool.php" class="mdui-ripple">首页</a>
              	</li>
              	<li class="mdui-menu-item" >
                	<a href="/jqrcz.php" class="mdui-ripple">批量管理</a>
              	</li>
              	<li class="mdui-menu-item" >
                	<a href="/box.php" class="mdui-ripple">工具箱</a>
              	</li>
              	<li class="mdui-menu-item" >
                	<a href="/site.php" class="mdui-ripple">分站</a>
              	</li>
            </ul>
  		</div>
	</div>
		<script src="./js/mdui.min.js"></script> 	  <script>     if(localStorage.darkTheme)         document.body.classList.add("mdui-theme-layout-dark");      document.getElementById("switch-theme").addEventListener(         "click",         () => document.body.classList.toggle("mdui-theme-layout-dark") ?             (localStorage.darkTheme = true) :             (delete localStorage.darkTheme)     );  </script><p id="switch-theme">>点此切换黑白</p> <script>      if(localStorage.darkTheme)         document.body.classList.add("mdui-theme-layout-dark");           document.getElementById("switch-theme").addEventListener(         "click",         () => document.body.classList.toggle("mdui-theme-layout-dark") ?             (localStorage.darkTheme = true) :             (delete localStorage.darkTheme)     ); </script><script type="text/javascript" src="https://s9.cnzz.com/z_stat.php?id=1279812358&web_id=1279812358"></script></a>               	</li>             </ul>   		</div> 	</div> 	
	<script src="./js/jquery.min.js"></script>
	<script type="text/javascript" charset="utf-8">
	  $(window).scroll(function(){
	    var scrollTop = $(window).scrollTop();
	   if (scrollTop < 100) {
	      $(".mdui-APPbar").removeClass("mdui-color-theme");
          $(".mdui-APPbar").addClass("mdui-text-color-black");
          $(".mdui-APPbar").removeClass("mdui-text-color-white")
	   } else {
	      $(".mdui-APPbar").addClass("mdui-text-color-white");
	      $(".mdui-APPbar").addClass("mdui-color-theme");
	      $(".mdui-APPbar").removeClass("mdui-text-color-black");
	   }
	  });
	</script>
<div class="mdui-grid-tile">
    <div class="mdui-ripple">
  <img src="card.webp"/>
  <div class="mdui-grid-tile-actions mdui-grid-tile-actions-transparent">
    <div class="mdui-grid-tile-text">
      <div class="mdui-grid-tile-title">Xiao Jn Days</div>
    </div>
  </div>
</div>
</div>
<div class="mdui-chip">
  <span class="mdui-chip-icon mdui-color-blue"><i class="mdui-icon material-icons">face</i></span>
  <span class="mdui-chip-title">唯一开发者:滑稽MC</span>
</div>
<ul class="mdui-list">
  <li class="mdui-list-item mdui-ripple">很高兴能在这里见到大家</li>
  <li class="mdui-list-item mdui-ripple">我是开发者滑稽MC</li>
  <li class="mdui-list-item mdui-ripple">一只普通但又不普通的狗∪･ω･∪</li>
</ul>
<ul class="mdui-list">
  <li class="mdui-list-item mdui-ripple">
    <i class="mdui-list-item-avatar mdui-icon material-icons">add_alert</i>
    <div class="mdui-list-item-content">2021年1月23日 19:45
    <br>滑稽MC，也就是我，发布了小滑稽开发群的第一个群公告:
    <br>全新项目!!!小滑稽更名小Jn
    <br>在已有功能基础上进行优化
    <br>计划实现用户自定义更多功能，更多框架，支持对接自己的AI等!</div>
  </li>
  <li class="mdui-list-item mdui-ripple">
    <i class="mdui-list-item-avatar mdui-icon material-icons">adb</i>
    <div class="mdui-list-item-content">2021年2月5日 21:06
    <br>小Jn迎来了第一次系统更新
    <br>小Jn不停站更新完成!!!
<br>本次优化了一个重大bug
<br>1.修复了前端框架无法乞讨的问题
<br>2.解决了前端框架xiaojnkey经常失效的问题
<br>3.还是没有解决电脑端的优化问题
<br>开发者表示我不会，并大言不惭的说能用就行
    </div>
  </li>
  <li class="mdui-list-item mdui-ripple">
    <i class="mdui-list-item-avatar mdui-icon material-icons">all_inclusive</i>
    <div class="mdui-list-item-content"> 2021年2月6日 16:19
    <br>小Jn不停站更新完成!!!
<br>本次优化了加载速度
<br>1.实现了全站Jn框架CDN加载，影响代码981行，优化问题341个
<br>2.解决了工具箱未登录不会跳转登录的问题</div>
<li class="mdui-list-item mdui-ripple">
    <i class="mdui-list-item-avatar mdui-icon material-icons">apps</i>
    <div class="mdui-list-item-content">
        2021年2月6日 17:11
        <br>小Jn重大更新完成!!!
<br>本次优化了全站
<br>1.优化了全站流畅度
<br>2.升级了批量管理前端控制面板(重磅)
<br>实现多号管理的初步实现
<br>3.修复了没有批量管理也显示操作面板的问题
        </div>
        
<li class="mdui-list-item mdui-ripple">
    <i class="mdui-list-item-avatar mdui-icon material-icons">assessment</i>
    <div class="mdui-list-item-content">
        2021年2月8日 20:44
        <br>小Jn重大更新
<br>1.批量管理批量管理自动回复实现
<br>2.批量管理批量管理批量管理功能自定义开启关闭实现
<br>3.优化了批量管理无法全部显示的bug
        </div>
        
<li class="mdui-list-item mdui-ripple">
    <i class="mdui-list-item-avatar mdui-icon material-icons">backup</i>
    <div class="mdui-list-item-content">
       2021年2月9日 07:59
       <br>小Jn更新
<br>1.启动了后端运行
<br>2.优化了前端UI显示</div>

<li class="mdui-list-item mdui-ripple">
    <i class="mdui-list-item-avatar mdui-icon material-icons">camera_rear</i>
    <div class="mdui-list-item-content">
       2021年2月9日 11:55
       <br>小Jn更新啦
<br>1.正式开放后端运行监控接口
<br>2.优化前端监控地址显示错误的bug
<br>3.优化前端框架运行流畅度</div>

<li class="mdui-list-item mdui-ripple">
    <i class="mdui-list-item-avatar mdui-icon material-icons">chrome_reader_mode</i>
    <div class="mdui-list-item-content">
        2021年2月10日 07:04
        <br>小Jn更新啦!!!
<br>1.修复了批量管理回复只会回复帖子不回复人的问题
<br>2.修复了批量管理名字没有自动获取的问题
<br>3.修复了批量管理前端框架点击刷新按钮会跳转到普通工具箱的问题
<br>4.优化了批量管理前后端重复回复机制检测
<br>5.优化了批量管理前端工具箱显示
<br>感谢大家的支持!</div>
  </li>
 <li class="mdui-list-item mdui-ripple">
    <i class="mdui-list-item-avatar mdui-icon material-icons">aspect_ratio</i>
    <div class="mdui-list-item-content">
        2021年2月10日 11:51
<br>小Jn更新
<br>1.优化了批量管理操作面板随机语录显示
<br>2.新增功能转移葫芦
<br>3.提示语更新
<br>4.更改Q群显示</div>
  </li>
   <li class="mdui-list-item mdui-ripple">
    <i class="mdui-list-item-avatar mdui-icon material-icons">adjust</i>
    <div class="mdui-list-item-content">
    2021年2月10日 22:46
<br>小Jn更新
<br>1.在线帖子ID获取器上线，转移葫芦更方便!
<br>2.消息中心即将正式上线，敬请期待!</div>
  </li>
   <li class="mdui-list-item mdui-ripple">
    <i class="mdui-list-item-avatar mdui-icon material-icons">announcement</i>
    <div class="mdui-list-item-content">
        2021年2月11日 08:27
<br>小Jn更新
<br>1.消息中心正式上线</div>
  </li>
  <li class="mdui-list-item mdui-ripple">
    <i class="mdui-list-item-avatar mdui-icon material-icons">attach_money</i>
    <div class="mdui-list-item-content">
        2021年2月12日 08:16
<br>小Jn更新
<br>1.转移葫芦功能葫芦总数可以控制!</div>
  </li>
  <li class="mdui-list-item mdui-ripple">
    <i class="mdui-list-item-avatar mdui-icon material-icons">money_off</i>
    <div class="mdui-list-item-content">
        2021年2月12日 12:46
<br>小Jn更新
<br>1.要广告费功能上线</div>
  </li>
  <li class="mdui-list-item mdui-ripple">
    <i class="mdui-list-item-avatar mdui-icon material-icons">add_to_photos</i>
      <div class="mdui-list-item-content">
        2021年2月12日 14:42
<br>小Jn更新
<br>1.优化了前端后端框架显示不全的问题
<br>2.开放了更多后端网址监控接口</div>
  </li>
  <li class="mdui-list-item mdui-ripple">
    <i class="mdui-list-item-avatar mdui-icon material-icons">art_track</i>
      <div class="mdui-list-item-content">
   2021年2月12日 20:40
<br>小Jn品质更新
<br>1.优化了乞讨图片的美观度和清晰度
<br>2.优化了自动水帖排版不美观问题</div>
  </li>
  <li class="mdui-list-item mdui-ripple">
    <i class="mdui-list-item-avatar mdui-icon material-icons">art_track</i>
      <div class="mdui-list-item-content">
 2021年2月15日 16:46
<br>小Jn更新
<br>1.添加批量管理功能选择优化
<br>2.弹窗内容优化
<br>3.添加批量管理返回信息更新显示
<br>4.修复了后端运行接口前端UI显示异常的问题
<br>5.修复了重复回复的问题
<br>6.修复了自动回复会与我要关注等功能冲突的问题<br>7.优化了侧滑栏显示
<br>8.修复了我要关注/取关只回复不操作的问题</div>
  </li>
  <li class="mdui-list-item mdui-ripple">
    <i class="mdui-list-item-avatar mdui-icon material-icons">art_track</i>
      <div class="mdui-list-item-content">
   2021年2月16日 17:15
<br>小Jn更新
<br>1.批量管理前端框架更新
<br>2.优化工具箱显示图标</div>
  </li>
  <li class="mdui-list-item mdui-ripple">
    <i class="mdui-list-item-avatar mdui-icon material-icons">border_bottom</i>
      <div class="mdui-list-item-content">
   2021年2月27日 11:03
<br>小Jn更新
<br>1.修复一言，批量管理名字会有下划线跟在后面的问题
<br>2.优化批量管理删除按钮
<br>3.优化批量管理为空显示</div>
  </li>
  <li class="mdui-list-item mdui-ripple">
    <i class="mdui-list-item-avatar mdui-icon material-icons">border_style</i>
      <div class="mdui-list-item-content">
   2021年2月27日 17:55
<br>小Jn更新
<br>1.某些页面性能优化，404优化
<br>2.删除优化
<br>3.后端运行弹窗显示优化</div>
  </li>
  <li class="mdui-list-item mdui-ripple">
    <i class="mdui-list-item-avatar mdui-icon material-icons">assistant</i>
      <div class="mdui-list-item-content">
   2021年2月16日 17:15
<br>小Jn公测开启
<br>使用小Jn自助一键搭建一个和小Jn一模一样的网站!
<br>但是网站的名字QQ群等全部可以自定义
<br>域名/admin是后台
<br>目前还打算更新的功能有收葫芦等
<br>欢迎提意见
<br>更新内容:
<br>1.网站自助代建系统正式上线
<br>2.优化页面跳转
<br>3.更新全体网站后台，可自定义前端代码
</div>
  </li>
</ul>
<li class="mdui-list-item mdui-ripple">
    <i class="mdui-list-item-avatar mdui-icon material-icons">trending_up</i>
      <div class="mdui-list-item-content">
   2021年03-13 10:04
<br>小Jn更新
<br>1.升级AI，影响代码8000多行，影响功能乞讨葫芦，自动水帖，自动回复等
<br>2.修复了批量管理名字后面会带一个下划线的问题
<br>3.一键部署网站收葫芦功能正式竣工，水帖推出帖子克隆功能
<br>4.部署网站默认模板优化，收录率提高
<br>5.优化一键部署效果
</div>
  </li>
</ul>
<li class="mdui-list-item mdui-ripple">
    <i class="mdui-list-item-avatar mdui-icon material-icons">thumbs_up_down</i>
      <div class="mdui-list-item-content">
   2021年03-13 22:17
<br>小Jn更新
<br>1.AI彻底升级完成
<br>2.部署站点后台全部升级完成
<br>3.推出全新互关功能，优化检测机制，检测前20条关注，实现不遗漏不错判!
</div>
  </li>
</ul>
<li class="mdui-list-item mdui-ripple">
    <i class="mdui-list-item-avatar mdui-icon material-icons">settings_backup_restore</i>
      <div class="mdui-list-item-content">
   2021年 03-18 13:02
<br>小Jn优化
<br>检测关注列表为20→100个
<br>也就是我要互关功能增强
<br>修复了没有付费用户和收益，不显示的问题。
<br>后台将显示付费用户数量
<br>并且显示收益。
<br>帖子克隆修复
</div>
  </li>
</ul>
<li class="mdui-list-item mdui-ripple">
    <i class="mdui-list-item-avatar mdui-icon material-icons">settings_backup_restore</i>
      <div class="mdui-list-item-content">
   2021年 03-20 14：31
<br>小Jn更新
<br>1.修复Jn工具/水帖/贴子复制功能
<br>
<br>2.准备推出工具:帖子复制
<br>
<br>3.优化分站数据储存机制
<br>
<br>4.修复数据遗留问题
<br>
<br>5.补了一下发展页面
<br>
<br>6.我要点赞功能
<br>
<br>7.优化了前端图片美观以及优化了后端代码
<br>
<br>8.修复乞讨图片问题，紧急优化乞讨一言机制
<br>
<br>9.推出切换账号功能
<br>
<br>10.优化签到效果
</div>
  </li>
   <li class="mdui-list-item mdui-ripple">
    <i class="mdui-list-item-avatar mdui-icon material-icons">add_circle_outline</i>
      <div class="mdui-list-item-content">
   2021年3月28日 07:44
<br>小Jn更新
<br>1.修复批量管理监控无法使用问题
<br>2.推出卖关注功能
<br>3.优化工具箱一键签到过渡动画，签到更加流畅自然
<br>4.修复批量管理删除问题
<br>5.优化API弹窗无法滚动问题
<br>6.修复一言水帖"一帖多机"问题
<br>7.正式上线切换账号功能
<br>8.优化站点编辑，优化分站后台显示
<br>9.推出前端统计数据，优化前端加载</div>
  </li>
</ul>
<li class="mdui-list-item mdui-ripple">
    <i class="mdui-list-item-avatar mdui-icon material-icons">border_style</i>
      <div class="mdui-list-item-content">
   2021年4月3日 17:55
<br>小Jn更新
<br>1.批量管理管理，网站管理页面优化，404优化
<br>2.推出自定义标签功能
<br>3.分站更新"模板2"，优化后台管理面板
<br>4.新增站点统计
<br>5.优化部分提示语，正式发布批量管理后缀自定义</div>
  </li>





    <!-- MDUI JavaScript -->
    <script
      src="https://unpkg.com/mdui@1.0.2/dist/js/mdui.min.js"

    ></script>
  </body>
</html>