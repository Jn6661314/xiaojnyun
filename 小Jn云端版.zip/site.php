<?php ob_start(); ?><?php
error_reporting(0);
    
$getCatJson=file_get_contents("http://floor.huluxia.com/user/info/ANDROID/4.1.8?platform=2&gkey=000000&app_version=4.2.0.4.2&versioncode=20141472&market_id=floor_web&_key=".$_COOKIE["ekey"]."&device_code=%5Bd%5D16485814-230d-424c-8af1-fda8f42d1e25&phone_brand_type=UN&user_id=".$_COOKIE["uid"]);
$catArray=json_decode($getCatJson,true);
$cats=$catArray["msg"];
if($cats!=null){


Header("Location: /login.php");
ob_end_flush();}
?>

<!DOCTYPE html>
<html lang="zh">
<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"> 
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>小Jn——网站管理</title>
	<!doctype html>
<html lang="zh-cmn-Hans">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, shrink-to-fit=no"/>
    <meta name="renderer" content="webkit"/>
    <meta name="force-rendering" content="webkit"/>
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"/>

<!-- MDUI CSS -->
    <link
      rel="stylesheet"
      href="https://unpkg.com/mdui@1.0.2/dist/css/mdui.min.css"

    />
        <body class="mdui-appbar-with-toolbar">
  <div class="mdui-appbar mdui-appbar-fixed mdui-appbar-scroll-hide">
    <div class="mdui-toolbar mdui-color-theme">
  <a href="javascript:window.history.back();" class="mdui-btn mdui-btn-icon"><i class="mdui-icon material-icons">keyboard_arrow_left</i></a>
  <span class="mdui-typo-title">小Jn</span>
  <div class="mdui-toolbar-spacer"></div>
  
  

  <a href="javascript:location.reload();" class="mdui-btn mdui-btn-icon"><i class="mdui-icon material-icons">refresh</i></a>
<button class="mdui-btn mdui-btn-icon" mdui-menu="{target:'#main-menu'}"><i class="mdui-icon material-icons">more_vert</i></button>

<ul class="mdui-menu" id="main-menu">

              	<li class="mdui-menu-item" >
                	<a href="/tool.php" class="mdui-ripple">首页</a>
              	</li>
              	<li class="mdui-menu-item" >
                	<a href="/jqrcz.php" class="mdui-ripple">批量管理</a>
              	</li>
              	<li class="mdui-menu-item" >
                	<a href="/box.php" class="mdui-ripple">工具箱</a>
              	</li>
              	<li class="mdui-menu-item" >
                	<a href="/site.php" class="mdui-ripple">分站</a>
              	</li>
            </ul>
  		</div>
	</div>
		<script src="./js/mdui.min.js"></script> 	  <script>     if(localStorage.darkTheme)         document.body.classList.add("mdui-theme-layout-dark");      document.getElementById("switch-theme").addEventListener(         "click",         () => document.body.classList.toggle("mdui-theme-layout-dark") ?             (localStorage.darkTheme = true) :             (delete localStorage.darkTheme)     );  </script><p id="switch-theme">>点此切换黑白</p> <script>      if(localStorage.darkTheme)         document.body.classList.add("mdui-theme-layout-dark");           document.getElementById("switch-theme").addEventListener(         "click",         () => document.body.classList.toggle("mdui-theme-layout-dark") ?             (localStorage.darkTheme = true) :             (delete localStorage.darkTheme)     ); </script><script type="text/javascript" src="https://s9.cnzz.com/z_stat.php?id=1279812358&web_id=1279812358"></script></a>               	</li>             </ul>   		</div> 	</div> 	
	<script src="./js/jquery.min.js"></script>
	<script type="text/javascript" charset="utf-8">
	  $(window).scroll(function(){
	    var scrollTop = $(window).scrollTop();
	   if (scrollTop < 100) {
	      $(".mdui-APPbar").removeClass("mdui-color-theme");
          $(".mdui-APPbar").addClass("mdui-text-color-black");
          $(".mdui-APPbar").removeClass("mdui-text-color-white")
	   } else {
	      $(".mdui-APPbar").addClass("mdui-text-color-white");
	      $(".mdui-APPbar").addClass("mdui-color-theme");
	      $(".mdui-APPbar").removeClass("mdui-text-color-black");
	   }
	  });
	</script>
  </head><div class="mdui-ripple">
<div class="mdui-card">
  <div class="mdui-card-media">
    <img src="/card.webp"/>
    <div class="mdui-card-media-covered">
      <div class="mdui-card-primary">
        <div class="mdui-card-primary-title">欢迎回家</div>
        <div class="mdui-card-primary-subtitle"><?php  $userMsg=file_get_contents("http://floor.huluxia.com/user/info/ANDROID/2.1?_key=".$_COOKIE["ekey"]."&user_id=".$_COOKIE["uid"]);
$user=json_decode($userMsg,true);

$namejn=$user["nick"];echo$namejn ;?></div>
      </div>
      <div class="mdui-card-actions">
        <button class="mdui-btn mdui-ripple mdui-ripple-white">不能添加/编辑网站</button>
           <button class="mdui-btn mdui-ripple mdui-ripple-white">你家本地开分站有啥用？</button>
      </div>
    </div>
  </div>
</div>
</div>





</body>

<!-- MDUI JavaScript -->
    <script
      src="https://unpkg.com/mdui@1.0.2/dist/js/mdui.min.js"

    ></script>
  
	<!--可无视-->
	<link rel="stylesheet" type="text/css" href="css/bootstrap-grid.min.css" /><!--CSS RESET-->

	
	<!--必要样式-->
	<link rel="stylesheet" href="css/naranja.min.css">
</head>
<body>
	
	<div class="container">
		<div class="row" style="padding:2em 0">
			<div class="col-md-2">
		
<div style="margin: 0 auto; width: 0%; position: fixed; bottom: 5px; height: 100％; font-size: 0; line-height: 0; z-index: 100; text-align: left;">

	
		</div></div>


 <?php
 

   echo
   <<<EOF
   <div class="mdui-card">
  <div class="mdui-card-media">
    <img src="xiaogz.jpg"/>
    <div class="mdui-card-media-covered mdui-card-media-covered-transparent">
      <div class="mdui-card-primary">
        <div class="mdui-card-primary-title"></div>
        <div class="mdui-card-primary-subtitle"></div>
      </div>
    </div>
  </div>
  <div class="mdui-center" style="width: 200px">大佬，你还一个网站都没有呢</div>
EOF;
    
    

?>

  
    
  </div>
</div>




    
	</div>




</body>
</html>
