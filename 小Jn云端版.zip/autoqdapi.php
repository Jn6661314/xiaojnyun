
<?php
header("Expires: Mon, 26 Jul 1997 05:00:00 GMT");//内容过期时间 强制浏览器去服务器去获取数据 而不是从缓存中读取数据
header("Last-Modified: " . gmdate("D, d M Y H:i:s") . " GMT");//标记内容最后修改时间
header("Cache-Control: no-store, no-cache, must-revalidate");//强制不缓存
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");//禁止本页被缓存
header("Access-Control-Allow-Origin: *"); // Support CORS

$account=$_GET["ekey"];

if($account==null)
{
echo"登录过期或未登录！！！";
}

$getCatJson=file_get_contents("http://floor.huluxia.com/category/list/ANDROID/2.0");
$catArray=json_decode($getCatJson,true);
$cats=$catArray["categories"];

for($catOid=0;$catOid<count($cats);$catOid++)
{
$cid=$cats[$catOid]["categoryID"];



$result=file_get_contents("http://floor.huluxia.com/user/signin/ANDROID/4.0?platform=2&gkey=000000&app_version=4.0.0.7&versioncode=20141436&market_id=floor_huluxia&_key=".$_GET["ekey"]."&device_code=%5Bw%5D02%3A00%3A00%3A00%3A00%3A00-%5Bi%5D866934037372573-%5Bs%5D89861119147385482175&cat_id=".$cid);


$returnJson=json_decode($result,true);
$msg=$returnJson["msg"];
if($msg==null)
{
echo"\n签到成功，经验+5";

}

sleep(0.3);

}




 

?>
