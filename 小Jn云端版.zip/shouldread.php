<!doctype html>
<html lang="zh-cmn-Hans">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, shrink-to-fit=no"/>
    <meta name="renderer" content="webkit"/>
    <meta name="force-rendering" content="webkit"/>
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"/>

<!-- MDUI CSS -->
    <link rel="stylesheet" href="https://unpkg.com/mdui@1.0.2/dist/css/mdui.min.css"/>

    <!-- MDUI JavaScript -->
    <script src="https://unpkg.com/mdui@1.0.2/dist/js/mdui.min.js"></script>
    <title>小Jn批量管理使用条款</title>
  </head>
  <body>
          <body class="mdui-appbar-with-toolbar">
  <div class="mdui-appbar mdui-appbar-fixed mdui-appbar-scroll-hide">
    <div class="mdui-toolbar mdui-color-theme">
  <a href="javascript:window.history.back();" class="mdui-btn mdui-btn-icon"><i class="mdui-icon material-icons">keyboard_arrow_left</i></a>
  <span class="mdui-typo-title">小Jn使用条款</span>
  <div class="mdui-toolbar-spacer"></div>
  
  

  <a href="javascript:location.reload();" class="mdui-btn mdui-btn-icon"><i class="mdui-icon material-icons">refresh</i></a>
<button class="mdui-btn mdui-btn-icon" mdui-menu="{target:'#main-menu'}"><i class="mdui-icon material-icons">more_vert</i></button>

<ul class="mdui-menu" id="main-menu">

              	<li class="mdui-menu-item" >
                	<a href="/tool.php" class="mdui-ripple">首页</a>
              	</li>
              	<li class="mdui-menu-item" >
                	<a href="/jqrcz.php" class="mdui-ripple">批量管理</a>
              	</li>
              	<li class="mdui-menu-item" >
                	<a href="/box.php" class="mdui-ripple">工具箱</a>
              	</li>
              	<li class="mdui-menu-item" >
                	<a href="/site.php" class="mdui-ripple">分站</a>
              	</li>
            </ul>
  		</div>
	</div>
		<script src="./js/mdui.min.js"></script> 	  <script>     if(localStorage.darkTheme)         document.body.classList.add("mdui-theme-layout-dark");      document.getElementById("switch-theme").addEventListener(         "click",         () => document.body.classList.toggle("mdui-theme-layout-dark") ?             (localStorage.darkTheme = true) :             (delete localStorage.darkTheme)     );  </script><p id="switch-theme">>点此切换黑白</p> <script>      if(localStorage.darkTheme)         document.body.classList.add("mdui-theme-layout-dark");           document.getElementById("switch-theme").addEventListener(         "click",         () => document.body.classList.toggle("mdui-theme-layout-dark") ?             (localStorage.darkTheme = true) :             (delete localStorage.darkTheme)     ); </script><script type="text/javascript" src="https://s9.cnzz.com/z_stat.php?id=1279812358&web_id=1279812358"></script></a>               	</li>             </ul>   		</div> 	</div> 	
	<script src="./js/jquery.min.js"></script>
	<script type="text/javascript" charset="utf-8">
	  $(window).scroll(function(){
	    var scrollTop = $(window).scrollTop();
	   if (scrollTop < 100) {
	      $(".mdui-APPbar").removeClass("mdui-color-theme");
          $(".mdui-APPbar").addClass("mdui-text-color-black");
          $(".mdui-APPbar").removeClass("mdui-text-color-white")
	   } else {
	      $(".mdui-APPbar").addClass("mdui-text-color-white");
	      $(".mdui-APPbar").addClass("mdui-color-theme");
	      $(".mdui-APPbar").removeClass("mdui-text-color-black");
	   }
	  });
	</script>

<div class="mdui-panel" mdui-panel>
  <div class="mdui-panel-item">
    <div class="mdui-panel-item-header">
      <div class="mdui-panel-item-title">免责声明</div>
      <div class="mdui-panel-item-summary">点击查看</div>
      
      <i class="mdui-panel-item-arrow mdui-icon material-icons">keyboard_arrow_down</i>
    </div>
    <div class="mdui-panel-item-body">
<div class="mdui-center" style="width: 200px">
     <h1>小Jn免责声明</h1>
<br>
<br><br>欢迎加入测试，我是小Jn开发，仅此一个
<br><br>我致力于给大家提供免费的葫芦侠批量管理
<br><br>我为大家提供全自动卖关注，全自动签到，全自动水帖，全自动乞讨葫芦等先进功能，让您葫芦，贡献值，经验通通拥有！
<br><br>所有操作一个网页搞定，假如不会的话，自己在首页点击教程文档去视频教程看看!
<br><br>小Jn免责声明
<br><br>1.小Jn是一个免费提供服务的批量管理，由各路大佬合作完成（如提供主机域名源码，仅限并不限于此），仅做短暂演示，学习交流使用，<br>无任何商业盈利用途。
<br><br>2.小Jn网站中并没有出现任何与葫芦侠商标有冲突的信息，所有的葫芦侠有关文字皆作描述性使用，并不假冒，冒充，代表葫芦侠官方。
<br><br>3.使用小Jn源码二改，二售，搭建的网站的内容与本站无关。
<br><br>4.利用/非法使用小Jn源码，利用bug等进行大量水回复等违规操作与小Jn官方无关。
<br><br>5.请遵守葫芦侠社区规范，避免大量人机回复，水贴等（包括但不限于此），对社区造成的秩序影响所带来的后果我们概不负责。
<br><br>最终解释权归各路参与小Jn项目的技术大佬所有
<br>
<div class="mdui-float-right"><br>———小Jn开发团队</div>
    
      </div>
    </div>
  </div>
<div class="mdui-panel-item">
    <div class="mdui-panel-item-header">
      <div class="mdui-panel-item-title">用户条款</div>
      <i class="mdui-panel-item-arrow mdui-icon material-icons">keyboard_arrow_down</i>
    </div>
    <div class="mdui-panel-item-body">
      <p>请在使用此网站之前仔细阅读使用条款（“条款”）。
      <p>您对小Jn葫芦侠批量管理运营团队（“小Jn葫芦侠批量管理”）网站的访问和使用表明您认可并同意遵守以下使用条款。如果您不同意这些条款，请不要使用小Jn葫芦侠批量管理网站或下载任何材料。

<h3>条款范围</h3>
<br>这些条款适用于小Jn葫芦侠批量管理所有网站，不论该网站是由第三方供应商管理的，还是由第三方网站主办的资助网站（以下均称为“网站”）。这些条款同样适用于通过小Jn葫芦侠批量管理网站提供的所有资源和工具，包括，但不限于，开发人员工具、下载区域、研究区域、社区论坛、聊天室、博客、共享网站和产品信息等。这些条款适用于当前和将来的所有小Jn葫芦侠批量管理网站。由这些条款涵盖的所有材料在以下均称为“材料”。<br>
<br>
<br>小Jn葫芦侠批量管理可能会提供针对具体活动或项目的服务条款；例如，小Jn葫芦侠批量管理会提供交互性材料和/或启用用户生成的材料。在此类情况下，如果这些条款与针对项目的具体服务条款不相冲突，则此处的条款保持完整有效。

<h3>安全和隐私</h3>
个人信息：通过网站上的表格向小Jn葫芦侠批量管理提交的信息或材料均受小Jn葫芦侠批量管理隐私条款的保护。
<br>
成员帐户，密码和安全：小Jn葫芦侠批量管理会不时主办一个针对具体项目或活动的网站；而该网站可能会要求您提供帐户和/或网站密码。在这种情况下，您将对保持自己密码和帐户的机密性负全部责任。此外，您对在您的帐户下的所有活动负全部责任。您同意在发现您账户未经许可被使用或安全性遭到任何破坏的情况下立即通知小Jn葫芦侠批量管理。小Jn葫芦侠批量管理对因您的密码或帐户在您知情或不知情的情况下被他人使用而可能对您造成的任何损失不负任何责任。但是，您会被要求对因他人使用您的帐户或密码而对小Jn葫芦侠批量管理或第三方造成的损失承担负责。您不得未经帐户持有者准许的情况下在任何时候使用任何他人的帐户。
<br>
<h3>使用条款</h3>
<br>个人非商业用途：此网站专用于个人和非商业用途。除非在条款中提及或指定，您不得对从材料中获得的信息、软件、产品或服务进行修改、复制、发布、传输、展示、播放、翻制、出版、授权、从其创建衍生产品、转让或出售。
<br>
<br>您不得使用或促成使用本网站或关于小Jn葫芦侠批量管理® 产品的任何侵权分析相关的任何材料。您使用本网站或任何材料，即表明您同意就此后起草的包括本网站所披露的主题的任何专利诉讼授予小Jn葫芦侠批量管理非排他性的，免版税的许可。
<br>
<br>不可用于非法或被禁止的用途：您同意不将此网站或材料用于非法的或者本条款禁止的用途。您不可以：
<br>
<br>上传、张贴、电邮、传输或以其它方式提供任何非法的、有害的、具威胁性的、侮辱性的、骚扰性的、折磨性的、污蔑性的、粗俗的、下流的、诽谤性的、侵犯他人隐私的、仇恨的或对种族和民族有害的内容；
使用网站、材料、服务或活动“跟踪”，或骚扰或伤害他人；
<br>假冒他人或团体，包括，但不限于，小Jn葫芦侠批量管理负责人、论坛坛主、导游或主持人；或者谎称或假称您与某个人或组织的关系；或者收集或存储有关其他用户的个人数据用于被禁止的行为或活动;
伪造标题或以其他方式篡改识别资料，以混淆通过网站或材料传达的原内容；
上传、张贴、电邮、传输或以其它方式提供任何依照现有法律或任何合同或托管关系您无权提供的内容（如因雇佣关系或保密协议知晓或了解到的内部信息、专有和机密信息等）；
上传、张贴、电邮、传输或以其它方式提供任何对任何一方的任何专利、商标、商业机密、著作权或其他专有权利（权利）构成侵犯的内容；
上传、张贴、电邮、传输或以其它方式提供任何未经要求或未经许可的广告、促销材料、“垃圾邮件”、“连环信”、“金字塔式传销”、或任何其他形式的招揽材料；
上传、张贴、电邮、传输或以其它方式提供任何包含任何旨在扰乱、破坏或限制任何计算机软件或硬件或电子通信器材的病毒或其他任何电脑代码、文件或程序的材料;
<br>
您不得以可能会损坏或禁用小Jn葫芦侠批量管理服务器或网络连接、或加重其负担、影响其功能的任何形式使用网站或材料；不得违反连接到网站或材料的网络的任何要求、程序、策略或规定；不得干扰其他任何一方对网站或材料的使用或享用；
您不得试图通过黑客活动、密码挖掘或其他任何手段未经许可访问网站或材料、或访问与任何小Jn葫芦侠批量管理服务器或材料连接的其他帐户、计算机系统或网络；不得通过网站或材料无意提供的方法获取或试图获取任何材料或信息;
<h3>概述</h3>
<br>用户对此网站的访问受所有适用的联邦、州和本地法律的制约。网站上可用的所有信息受美国出口控制法律的制约；并可能同时受您居住国法律的制约。
<br><br>
小Jn葫芦侠批量管理不承诺网站上的材料对其他地区适用或可用；并且禁止在其内容被认为是非法的地区对其访问。从其他区域访问此网站的人士均为自愿所为，并对遵守本地法律负全部责任。
<br><br>
这些条款是您和小Jn葫芦侠批量管理公司之间的完整协议，并制约您对此网站的使用。每个用户在使用相关服务、第三方内容或第三方软件时可能会受其他相应的条款和条件的制约。您和小Jn葫芦侠批量管理之间的条款和关系应受美国特拉华州法律的管辖，而不考虑其法律条文的冲突；各方应服从该州法院的个人和专有审批权。如果这些条款被有效的管辖区的法庭认定为无效，各方仍然同意法庭应该考虑各方在规则中反映的本意，而条款的其余规则将仍然有效并可实施。
<br><br>
如果出现对这些规则和规定的违反行为，小Jn葫芦侠批量管理保留针对该违反行为采取法律所能提供的所有补救手段的权利。
<br><br>
小Jn葫芦侠批量管理能随时通过更新此张贴对这些条款进行修改。您应该经常查看当前最新的使用条款，因为您受这些条款的制约。这些使用条款中的某些规则可由位于特定网站或材料中明确指定的法律通知或条款取代。
<br>
<br>
<div class="mdui-float-right"><br>
版权所有 © 小Jn葫芦侠批量管理。保留所有权利</p></div>
      
      
      
  </div></div>
  
  <div class="mdui-panel-item">
    <div class="mdui-panel-item-header">
      <div class="mdui-panel-item-title">小Jn怎么运营</div>
      <i class="mdui-panel-item-arrow mdui-icon material-icons">keyboard_arrow_down</i>
    </div>
    <div class="mdui-panel-item-body">
      <p>小Jn是亏钱的，一直</p>
      <p>因为所有功能都是免费的</p>
      <p>源码是公益开发写的</p>
      <p>域名，服务器，技术支持都是大佬们免费提供的</p>
      <p>必须要感谢删工具箱策划（QQ：2805484997）为我们提供的大量删除建议，让我们的软件更加精简</p>
      <p>虽然知道结局如何，但希望能一直做下去</p>
      <p>希望大家多多赞助吧，感谢理解支持</p>
     
      </div>
    </div>
  </div>



  </body>
</html>