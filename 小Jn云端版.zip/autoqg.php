<!doctype html>
<html lang="zh-cmn-Hans">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, shrink-to-fit=no"/>
    <meta name="renderer" content="webkit"/>
    <meta name="force-rendering" content="webkit"/>
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"/>

    <!-- MDUI CSS -->
    <link rel="stylesheet" href="https://unpkg.com/mdui@1.0.2/dist/css/mdui.min.css"/>
    
  </head>
  <body>
   

    <!-- MDUI JavaScript -->
    <script src="https://unpkg.com/mdui@1.0.2/dist/js/mdui.min.js"></script>
  </body>
</html><div class="mdui-typo-display-5">
<?php
error_reporting(0);
    
$getCatJson=file_get_contents("http://floor.huluxia.com/user/info/ANDROID/4.1.8?platform=2&gkey=000000&app_version=4.2.0.4.2&versioncode=20141472&market_id=floor_web&_key=".$_COOKIE["ekey"]."&device_code=%5Bd%5D16485814-230d-424c-8af1-fda8f42d1e25&phone_brand_type=UN&user_id=".$_COOKIE["uid"]);
$catArray=json_decode($getCatJson,true);
$cats=$catArray["msg"];
if($cats!=null){

 
Header("Location: /login.php");
ob_end_flush();
  

}    


$key=$_COOKIE["ekey"];
$uid=$_COOKIE["uid"];



$id=$uid;
echo "<h1 id='qg'>取关中。。。请耐心等待</h1>";

$url="http://floor.huluxia.com/friendship/following/list/ANDROID/2.0?platform=2&gkey=000000&app_version=4.1.1.4&versioncode=324&market_id=tool_web&_key=$key&device_code=%5Bd%5D8034ce2a-678d-4ad8-b731-f5db1d5c353f&phone_brand_type=UN&start=0&count=99999&user_id=$uid";
$a=file_get_contents($url);
$b=json_decode($a,true);
$rr=count($b["friendships"]);
$szz=array();
for($i=0;$i<=$rr;$i++){
  array_push($szz,$b["friendships"][$i]["user"]["userID"]);
}
$url="http://floor.huluxia.com/friendship/follower/list/ANDROID/2.0?platform=2&gkey=000000&app_version=4.1.1.4&versioncode=324&market_id=tool_web&_key=$key&device_code=%5Bd%5D8034ce2a-678d-4ad8-b731-f5db1d5c353f&phone_brand_type=UN&start=0&count=999999&user_id=$id&compare_id=$uid";
$rr=file_get_contents($url);
$r=json_decode($rr,true);
$rr=count($r["friendships"]);
$sz=array();
for($i=0;$i<=$rr;$i++){
  array_push($sz,$r["friendships"][$i]["user"]["userID"]);
}
$sb=array_diff($szz,$sz);
sort($sb);
$lj=count($sb);
for ($i=0;$i<=$lj;$i++){
    $ssb=$sb[$i];
    $url="http://floor.huluxia.com/friendship/unfollow/ANDROID/2.0?platform=2&gkey=000000&app_version=4.1.1.4&versioncode=324&market_id=tool_web&_key=$key&device_code=%5Bd%5D8034ce2a-678d-4ad8-b731-f5db1d5c353f&phone_brand_type=UN&user_id=$ssb";
    $r=file_get_contents($url);
}
echo "<script>document.getElementById('qg').innerHTML='';</script>";
echo "(有 $lj 个傻逼取关了你\n)";
echo "已经取消关注所有傻逼";
?>