<?php setcookie("gxzb");
    Header("Location:/tool.php")   ?>