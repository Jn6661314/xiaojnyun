<?php
$title=$_GET["title"];
$detail=$_GET["detail"];
$cid=$_GET["cid"];
$oid=$_GET["oid"];

if($_GET["tid"]=="")
{
$tid=-1;
}
else if($_GET["tid"]==0)
{
Header("Location: createPost.php?cid=".$cid."&c=请选择分区！");
}
else
{
$tid=$_GET["tid"];
}


$result=file_get_contents("http://floor.huluxia.com/post/create/ANDROID/2.1?_key=".$_COOKIE["ekey"]."&cat_id=".$cid."&tag_id=".$tid."&type=0&title=".$title."&detail=".$detail."&patcha=&voice=&lng=0.0&lat=0.0&images=&user_ids=&recommendTopics=&is_app_link=3");
$result=json_decode($result,true);
$msg=$result["msg"];
Header("Location: /category.php?oid=".$oid."&cid=".$cid."&start=0&c=".$msg);
?>