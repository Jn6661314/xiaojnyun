<?php
//登录
$key=$_GET["ekey"];




//获取一言
$file = file("yy.txt");
 if($key==null){echo "未登录";}else {
//随机读取一行
$arr  = mt_rand( 0, count( $file ) - 1 );
echo"回复内容:";
echo$content  = trim($file[$arr],"\n");

//发送
  $url="http://floor.huluxia.com/post/list/ANDROID/2.1?platform=2&gkey=000000&app_version=4.0.0.7&versioncode=20141436&market_id=floor_huluxia&_key=".$key."&device_code=%5Bw%5D02%3A00%3A00%3A00%3A00%3A00-%5Bi%5D866934037372573-%5Bs%5D89861119147385482175&start=0&count=20&cat_id=2&tag_id=0&sort_by=1";
 $post=file_get_contents($url);
  $post=json_decode($post,true);
 echo"回复了ID为". $pid=$post["posts"][0]["postID"];//最新帖子ID
 //执行点赞
$key=$returnJson["_key"];

    $gzdf = "http://floor.huluxia.com/post/praise/ANDROID/2.1?platform=2&gkey=000000&app_version=4.1.1.2.2&versioncode=318&market_id=tool_tencent&_key=".$key."&device_code=%5Bw%5D02%3A00%3A00%3A00%3A00%3A00%5Bd%5De2f734cc-549b-4349-a311-244c64fcc71e&post_id=
".$pid;
   echo "返回信息".$gzgzgz4 = file_get_contents($gzdf);
   
echo"的帖子";  
$postJson=file_get_contents("http://floor.huluxia.com/post/detail/ANDROID/2.3?post_id=".$pid);
$postArray=json_decode($postJson,true);
$title=$postArray["post"]["title"];
$url2 = "http://". $_SERVER['HTTP_HOST']."/jnjqrapi.php?name=小Jn&q=".$title;
  echo $html = file_get_contents($url2)."[滑稽][玫瑰]";
  if($pid==file_get_contents("pid2.txt"))
  {
    echo "，PS:已回复，所以过滤了，评论可能在审核中";
  }
  else
  {
    $hulu=$post["posts"][0]["user"]["credits"];//葫芦数
    $url2="http://floor.huluxia.com/comment/create/ANDROID/2.0?platform=2&gkey=000000&app_version=4.0.0.7&versioncode=20141436&market_id=floor_huluxia&_key=".$key."&device_code=%5Bw%5D02%3A00%3A00%3A00%3A00%3A00-%5Bi%5D866934037372573-%5Bs%5D89861119147385482175&post_id=".$pid."&comment_id=0&text=".$html."，%0A顺便送你一句一言:%0A".$content."&patcha=&images=&remindUsers=";
  echo  file_get_contents($url2);
    file_put_contents("pid2.txt",$pid);
  }}