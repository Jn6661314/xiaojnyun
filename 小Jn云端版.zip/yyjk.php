<title>小JnAPI</title><?php
//登录
error_reporting(0);
$curl = curl_init();


$ip_long = array(
       array('607649792', '608174079'), //36.56.0.0-36.63.255.255
       array('1038614528', '1039007743'), //61.232.0.0-61.237.255.255
       array('1783627776', '1784676351'), //106.80.0.0-106.95.255.255
       array('2035023872', '2035154943'), //121.76.0.0-121.77.255.255
       array('2078801920', '2079064063'), //123.232.0.0-123.235.255.255
       array('-1950089216', '-1948778497'), //139.196.0.0-139.215.255.255
       array('-1425539072', '-1425014785'), //171.8.0.0-171.15.255.255
       array('-1236271104', '-1235419137'), //182.80.0.0-182.92.255.255
       array('-770113536', '-768606209'), //210.25.0.0-210.47.255.255
       array('-569376768', '-564133889'), //222.16.0.0-222.95.255.255
   );
   $rand_key = mt_rand(0, 9);
   $ip= long2ip(mt_rand($ip_long[$rand_key][0], $ip_long[$rand_key][1]));
$header = array("Connection: Keep-Alive","Accept: text/html, application/xhtml+xml, */*", "Pragma: no-cache", "Accept-Language: zh-Hans-CN,zh-Hans;q=0.8,en-US;q=0.5,en;q=0.3","User-Agent: okhttp/3.8.1");

	curl_setopt($curl,CURLOPT_URL,'http://floor.huluxia.com/account/login/ANDROID/4.0?platform=2&gkey=000000&app_version=4.1.1.6.2&versioncode=335&market_id=tool_tencent&_key=&phone_brand_type=UN&device_code=[d]16485814-230d-424c-8af1-fda8f42d1e25&password='.md5($_GET["key"]).'&login_type=2&account='.$_GET["phone"]."%0A");
	curl_setopt($curl,CURLOPT_RETURNTRANSFER,1);
	curl_setopt($curl,CURLOPT_CONNECTTIMEOUT,10);
	curl_setopt($curl,CURLOPT_FOLLOWLOCATION,1);
	curl_setopt($curl, CURLOPT_HTTPHEADER, $header);
	//curl_setopt($curl,CURLOPT_HTTPHEADER,['X-FORWARDED-FOR:164.89.81.12','CLIENT-IP:164.89.81.12']);
	curl_setopt($curl,CURLOPT_REFERER,'');
	curl_setopt($curl,CURLOPT_USERAGENT,'okhttp/3.8.1');
	$post= curl_exec($curl);
	curl_close($curl);
	$arr = json_decode($post, true);
// Access values from the associative array

$jnsb=$arr["_key"];
if($jnsb!=null){
//{echo'{"key":'.$arr["_key"].', "uid":'.$arr["user"]["userID"].'}';
//echo"good";
$userMsg=file_get_contents("http://floor.huluxia.com/user/info/ANDROID/2.1?_key=".$jnsb."&user_id=".$arr["user"]["userID"]);
$user=json_decode($userMsg,true);
$name=$user["nick"];
$returnJson=json_decode($post,true);
$msg=$returnJson["msg"];
$key=$returnJson["_key"];
$uid=$returnJson["user"]["userID"];
}else{echo("登录失败");}


//获取后缀
$file = file("jnhz.txt");
 if($key==null){echo "未登录";}else {
//随机读取一行
$arr  = mt_rand( 0, count( $file ) - 1 );
echo"<br>回复内容:";
echo$content  = trim($file[$arr],"\n");

//获取
  $url="http://floor.huluxia.com/post/list/ANDROID/2.1?platform=2&gkey=000000&app_version=4.0.0.7&versioncode=20141436&market_id=floor_huluxia&_key=".$key."&device_code=%5Bw%5D02%3A00%3A00%3A00%3A00%3A00-%5Bi%5D866934037372573-%5Bs%5D89861119147385482175&start=0&count=20&cat_id=2&tag_id=0&sort_by=1";
 $post=file_get_contents($url);
  $post=json_decode($post,true);
 echo"回复了ID为". $pid=$post["posts"][0]["postID"];//最新帖子ID
 //执行点赞
$key=$returnJson["_key"];

    $gzdf = "http://floor.huluxia.com/post/praise/ANDROID/2.1?platform=2&gkey=000000&app_version=4.1.1.2.2&versioncode=318&market_id=tool_tencent&_key=".$key."&device_code=%5Bw%5D02%3A00%3A00%3A00%3A00%3A00%5Bd%5De2f734cc-549b-4349-a311-244c64fcc71e&post_id=
".$pid;
   echo "返回信息".$gzgzgz4 = file_get_contents($gzdf);
   
echo"的帖子";  
$postJson=file_get_contents("http://floor.huluxia.com/post/detail/ANDROID/2.3?post_id=".$pid);

    
 $userMsg=file_get_contents("http://floor.huluxia.com/user/info/ANDROID/2.1?_key=".$key."&user_id=".$uid);
$user=json_decode($userMsg,true);
$name=$user["nick"];

$postArray=json_decode($postJson,true);
$title=$postArray["post"]["title"];
//$url2 = "http://". $_SERVER['HTTP_HOST']."/jnjqrapi.php?name=".$jnname."&q=".$title."&name=".$name;
  //echo $html = file_get_contents($url2)."";
  if($pid==file_get_contents("pid2.txt"))
  {
    echo "，PS:已回复，所以过滤了，评论可能在审核中";
  }
  else
  {
    $hulu=$post["posts"][0]["user"]["credits"];//葫芦数
    $url2="http://floor.huluxia.com/comment/create/ANDROID/2.0?platform=2&gkey=000000&app_version=4.0.0.7&versioncode=20141436&market_id=floor_huluxia&_key=".$key."&device_code=%5Bw%5D02%3A00%3A00%3A00%3A00%3A00-%5Bi%5D866934037372573-%5Bs%5D89861119147385482175&post_id=".$pid."&comment_id=0&text="."送你一句一言".$content."&patcha=&images=&remindUsers=";
  echo  file_get_contents($url2);
    file_put_contents("pid2.txt",$pid);
  }}