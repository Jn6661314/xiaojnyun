<?php

setrawcookie("u",$_GET["u"],time()+9999*9999);

$key=$_COOKIE["key"];


setrawcookie("hulu",$_COOKIE["hulu"]+$_GET["hls"],time()+9999*9999);
echo"已送葫芦:".$h=$_COOKIE["hulu"]+$_GET["hls"];
echo"目标葫芦:".$z=$_GET["hulu"];
if($_GET["hulu"]>$_COOKIE["hulu"]+$_GET["hls"]){
$jg=$_GET["jgs"];
echo <<<EOF
状态:正在送葫芦，系统返回:
<meta http-equiv="refresh" content="$jg">

EOF;

}
else
{
    echo <<<EOF
    状态:本次赠送完成，系统返回:
EOF;

}
?>
<?php
//随机原因
$file = file("hlyy.txt");
//随机读取一行
$arr  = mt_rand( 0, count( $file ) - 1 );
echo"随机原因:";
echo$sjyy  = trim($file[$arr],"\n");


$id=$_GET["id"];//楼层，为空则为主帖

$pid=$_GET["pid"];//帖子id

if($key!=null)
{
  if($pid!=null)
  {
  $post=file_get_contents("http://floor.huluxia.com/post/detail/ANDROID/2.3?post_id=".$pid."&platform=2&gkey=000000&app_version=4.1.1.8.2&versioncode=344&market_id=tool_tencent&_key=".$key."&device_code=%5Bd%5D19e64e24-e8ae-4e97-9f4a-7983c918a962&phone_brand_type=HW&post_id=50208380&page_no=".$nb."&page_size=20&doc=1");
    $post=json_decode($post,true);
    $nb=count($post["comments"])/20;
  $nb=intval($nb);
  
    $post=file_get_contents("http://floor.huluxia.com/post/detail/ANDROID/2.3?post_id=".$pid."&platform=2&gkey=000000&app_version=4.1.1.8.2&versioncode=344&market_id=tool_tencent&_key=".$key."&device_code=%5Bd%5D19e64e24-e8ae-4e97-9f4a-7983c918a962&phone_brand_type=HW&post_id=".$pid."&page_no=".$nb."&page_size=20&doc=1");
    $post=json_decode($post,true);
    if($floor==null)
    {
    //赠送
      $cid=$post["comments"][$floor-1]["commentID"];
     echo file_get_contents("http://floor.huluxia.com/credits/transfer/ANDROID/2.0?_key=".$key."&post_id=".$id."&type_id=2&isadmin=0&score=".$_GET["hls"]."&score_txt=".$sjyy);
     
    sleep(1);
    //删评论
    if($_GET["sp"]=="是"){
      $post=file_get_contents("http://floor.huluxia.com/comment/create/list/ANDROID/2.0?user_id=".$_GET["u"]."&start=0&count=20&platform=2&gkey=000000&app_version=4.1.1.8.2&versioncode=344&market_id=tool_tencent&_key=".$key."&device_code=%5Bd%5D19e64e24-e8ae-4e97-9f4a-7983c918a962&phone_brand_type=HW");
    $post=json_decode($post,true);


        echo $my_cid=$post["comments"][0]["commentID"];
        file_get_contents("http://floor.huluxia.com/comment/destroy/ANDROID/2.0?_key=".$key."&comment_id=".$my_cid);
     }
  }
  else
  {
    echo "帖子ID不能为空！";
  }
}}
else
{
  echo "key不能为空！";
}
?>