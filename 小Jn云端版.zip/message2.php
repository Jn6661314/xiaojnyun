<!doctype html>
<html lang="zh-cmn-Hans">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, shrink-to-fit=no"/>
    <meta name="renderer" content="webkit"/>
    <meta name="force-rendering" content="webkit"/>
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"/>

    <!-- MDUI CSS -->
    <link
      rel="stylesheet"
      href="https://unpkg.com/mdui@1.0.2/dist/css/mdui.min.css"

    />
    <title>小Jn消息中心</title>
  </head>
  <body>
        <body class="mdui-appbar-with-toolbar">
  <div class="mdui-appbar mdui-appbar-fixed mdui-appbar-scroll-hide">
    <div class="mdui-toolbar mdui-color-theme">
  <a href="javascript:window.history.back();" class="mdui-btn mdui-btn-icon"><i class="mdui-icon material-icons">keyboard_arrow_left</i></a>
  <span class="mdui-typo-title">小Jn</span>
  <div class="mdui-toolbar-spacer"></div>
  
  

  <a href="javascript:location.reload();" class="mdui-btn mdui-btn-icon"><i class="mdui-icon material-icons">refresh</i></a>
<button class="mdui-btn mdui-btn-icon" mdui-menu="{target:'#main-menu'}"><i class="mdui-icon material-icons">more_vert</i></button>

<ul class="mdui-menu" id="main-menu">

              	<li class="mdui-menu-item" >
                	<a href="/tool.php" class="mdui-ripple">首页</a>
              	</li>
              	<li class="mdui-menu-item" >
                	<a href="/jqrcz.php" class="mdui-ripple">批量管理</a>
              	</li>
              	<li class="mdui-menu-item" >
                	<a href="/box.php" class="mdui-ripple">工具箱</a>
              	</li>
              	<li class="mdui-menu-item" >
                	<a href="/site.php" class="mdui-ripple">分站</a>
              	</li>
            </ul>
  		</div>
	</div>
		<script src="./js/mdui.min.js"></script> 	  <script>     if(localStorage.darkTheme)         document.body.classList.add("mdui-theme-layout-dark");      document.getElementById("switch-theme").addEventListener(         "click",         () => document.body.classList.toggle("mdui-theme-layout-dark") ?             (localStorage.darkTheme = true) :             (delete localStorage.darkTheme)     );  </script><p id="switch-theme">>点此切换黑白</p> <script>      if(localStorage.darkTheme)         document.body.classList.add("mdui-theme-layout-dark");           document.getElementById("switch-theme").addEventListener(         "click",         () => document.body.classList.toggle("mdui-theme-layout-dark") ?             (localStorage.darkTheme = true) :             (delete localStorage.darkTheme)     ); </script><script type="text/javascript" src="https://s9.cnzz.com/z_stat.php?id=1279812358&web_id=1279812358"></script></a>               	</li>             </ul>   		</div> 	</div> 	
	<script src="./js/jquery.min.js"></script>
	<script type="text/javascript" charset="utf-8">
	  $(window).scroll(function(){
	    var scrollTop = $(window).scrollTop();
	   if (scrollTop < 100) {
	      $(".mdui-APPbar").removeClass("mdui-color-theme");
          $(".mdui-APPbar").addClass("mdui-text-color-black");
          $(".mdui-APPbar").removeClass("mdui-text-color-white")
	   } else {
	      $(".mdui-APPbar").addClass("mdui-text-color-white");
	      $(".mdui-APPbar").addClass("mdui-color-theme");
	      $(".mdui-APPbar").removeClass("mdui-text-color-black");
	   }
	  });
	</script>
  <div class="mdui-tab mdui-color-theme" mdui-tab>
    <a href="/message.php" class="mdui-ripple mdui-ripple-white">用户消息</a>
    <a href="" class="mdui-ripple mdui-ripple-white">系统消息</a>

  </div>
</div>


    <!-- MDUI JavaScript -->
    <script
      src="https://unpkg.com/mdui@1.0.2/dist/js/mdui.min.js"

    ></script>
  </body>
</html>






<?php
error_reporting(0);
    


$pl=file_get_contents("http://floor.huluxia.com/message/new/list/ANDROID/4.1.8?platform=2&gkey=000000&app_version=4.2.0.4.2&versioncode=309&market_id=tool_tencent&_key=".$_COOKIE["ekey"]."&device_code=%5Bw%5D02%3A00%3A00%3A00%3A00%3A00%5Bd%5De2f734cc-549b-4349-a311-244c64fcc71e&type_id=1&start=0&count=60");

$jsonStr = $pl;

$arr = json_decode($pl,true);


for($i=0;$i<48;$i++)
{
//超级获取术
$a=$arr["datas"][$i]["content"]["text"];//评论内容
$user=$arr["datas"][$i]["content"]["user"]["userID"];//用户ID
$tx=$arr["datas"][$i]["content"]["user"]["avatar"];//头像
$name=$arr["datas"][$i]["content"]["user"]["nick"];//昵称
$tzid=$arr["datas"][$i]["content"]["post"]["postID"];//帖子ID
$ys=$arr["datas"][$i]["content"]["seq"]/20+1;//页数
$plid=$arr["datas"][$i]["content"]["commentID"];//评论ID
$urlhf='/create/createComment.php?pid='.$tzid.'&page='.$ys.'&cid='.$plid.'"';//评论API
$urlck='/post.php?pid='.$tzid.'&page=1';//查看话题API
$urlgr='/user.php?uid='.$user."&cmid=".$plid;//查看个人主页API
$urlsc='/sc.php?cmid='.$plid;//删除回复API
echo <<<EOF
 



<html>
 <head> 
  <title>评论中心-JnAPI</title> 
  <meta charset="utf-8"> 
  <!--响应式--> <ul class="mdui-list">
 <body id="v1"> 
 <br><li class="mdui-list-item mdui-ripple">
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no"> 
  <script src="js/jq.js"></script> 
 </head> 
 <body id="v1"> 
 <br>
 <hr id="v2"><a href=$urlgr>
   <img src=$tx alt=$name id="v7" height="30" width="30" referrerPolicy="no-referrer">
   </a>
  </br>
  <br
  ><a href=$urlgr style='color: gray; text-align: left;'".">
  <p>$name</p></a>
  </br>
  <br>
  <h1 id="v2">$a</h1> 
  </br>
 
   <a href=$urlgr style='color: gray; text-align: right;'".">查看个人主页</a>

  </ul>
  
 </body>
</html>
EOF;

}
?>

<div class="mdui-panel" mdui-panel>

