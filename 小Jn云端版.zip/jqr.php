【【
 <?php
header("Expires: Mon, 26 Jul 1997 05:00:00 GMT");//内容过期时间 强制浏览器去服务器去获取数据 而不是从缓存中读取数据
header("Last-Modified: " . gmdate("D, d M Y H:i:s") . " GMT");//标记内容最后修改时间
header("Cache-Control: no-store, no-cache, must-revalidate");//强制不缓存
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");//禁止本页被缓存
header("Access-Control-Allow-Origin: *"); // Support CORS

$dqdz=$_SERVER['HTTP_HOST'];
ini_set("error_reporting","E_ALL & ~E_NOTICE");
if($_COOKIE["phone"]!=null)
{
$phoneNumber=$_COOKIE["phone"];
$password=$_COOKIE["key"];
$r=$_COOKIE["key"];
$result=file_get_contents("http://floor.huluxia.com/account/login/ANDROID/4.0?device_code=1&account=".$phoneNumber."&login_type=2&password=".$password);
$returnJson=json_decode($result,true);
$msg=$returnJson["msg"];
$key=$returnJson["_key"];
$uid=$returnJson["user"]["userID"];
    
     $filename2='xiaojnroobots/'.$uid.'.txt';

$jnx=file($filename2);

 $filename='xiaojnroobots/'.$uid.'.txt';
 $ex=file_exists($filename);//检测文件存在与否
if($ex==1)
{
$b=file($filename);
$c=count($b)/4;
$d=$c;
for($i=0;$i<$c;$i++)
{
    $jkkey=$jnx[0*$i];
$name=$b[4*$i];
$phone=$b[1+$i*4];
$n=substr($phone,0,strlen($phone)-1); 
$keyj=$b[4*$i+2];
$keyx = substr($keyj,0,strlen($keyj)-1); 
$gn=$b[4*$i+3];
 
  echo <<<EOF
  
-$name 功能：$gn+ 批量管理接口（请长按查看）
只有挂上监控了，批量管理才能后台自动运行!
当前批量管理后端监控接口为
    (也就是实现自动回复等功能的接口)
    http://$dqdz/xiaojnjk.php?u=$uid&id=$i&jkkey=$jkkey&hz=后缀
      其他监控接口
       自动签到http://$dqdz/autoqd.php?phone=$n&key=$keyx
       自动取关没互关的人http://$dqdz/autoqgapi.php?phone=$n&key=$keyx
        自动乞讨http://$dqdz/qthljn.php?phone=$n&key=$keyx
        自动删乞讨回复http://$dqdz/sthfs.php?phone=$n&key=$keyx
         自动顶帖接口http://$dqdz/yyjk.php?phone=$n&key=$keyx
          自动水帖接口http://$dqdz/xiaojnaist.php?phone=$n&key=$keyx
          自动卖关注接口http://$dqdz/mgz.php?phone=$n&key=$keyx
    挂上网址监控即可完成全自动化
     #


EOF;

}
}
else {
   echo
   <<<EOF
- 大佬，你还一个批量管理+都没有呢#
EOF;
    
    
}}


?>
】
