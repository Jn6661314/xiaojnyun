<?php

header("Content-type:text/html;charset=utf-8");

$hhh = $_GET['q'];
$n = $_GET['name'];
$q=str_replace("_","",$hhh);
if($hhh==null)
{
echo "我来顶帖啦!(σ′▽‵)′▽‵)σ[滑稽]";
}
else

{
       if (strpos($hhh,'Jn是什么') !== false) {
    echo"Jn是小Jn的好朋友";
    }
    else{
        
    if (strpos($hhh,'滑稽MC是什么') !== false) {
    echo"一个超级大水怪，还不承认的那种";
    }
    else{
$hhh = $q;
$q=str_replace(" ","","$hhh");
$url = "http://i.itpk.cn/api.php?api_secret=b9u1sfpgvgmw&api_key=febc8b2ad1c07f8a644b1e5298529f95&limit=8&question=".$q;
  $html = file_get_contents($url);
  $b=str_replace("小Jn",$n,"$html");
    $b=str_replace("小鸡恩",$n,"$b");
  $c=str_replace("[name]","你","$b");
$d=str_replace("你妈才炸了","我不希望你炸了，不然小Jn就不能继续和你玩了(๑• . •๑)","$c");
$e=str_replace("一个人也挺好","理论上我是你的，实际上我是小狗杂的","$d");
 $g=str_replace("色色","谢谢(*°∀°)=3","$e");
$h=str_replace("_","",$g);
echo str_replace("itpk.cn","baidu.com",$h);
}}}