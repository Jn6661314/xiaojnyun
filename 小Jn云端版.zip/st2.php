<html lang="zh-cmn-Hans">
  <head>
      <meta http-equiv="refresh" content="120">

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, shrink-to-fit=no"/>
    <meta name="renderer" content="webkit"/>
    <meta name="force-rendering" content="webkit"/>
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"/>

<!-- MDUI CSS -->
    <link
      rel="stylesheet"
      href="https://unpkg.com/mdui@1.0.2/dist/css/mdui.min.css"

    /><!-- MDUI JavaScript -->
    <script
      src="https://unpkg.com/mdui@1.0.2/dist/js/mdui.min.js"

    ></script>
    
    
    
    
    <div class="mdui-card">

  <!-- 卡片头部，包含头像、标题、副标题 -->
  <div class="mdui-card-header">
    <img class="mdui-card-header-avatar" src="static/picture/hill.jpg"/>
    <div class="mdui-card-header-title">小Jn批量管理前端框架</div>
    <div class="mdui-card-header-subtitle">运行中</div>
  </div>

  <!-- 卡片的媒体内容，可以包含图片、视频等媒体内容，以及标题、副标题 -->
  <div class="mdui-card-media">
    <img src="static/picture/hill.jpg"/>

    <!-- 卡片中可以包含一个或多个菜单按钮 -->
    

  <!-- 卡片的标题和副标题 -->
  <div class="mdui-card-primary">
    <div class="mdui-card-primary-title">欢迎使用小Jn葫芦侠批量管理水贴功能</div>
    <div class="mdui-card-primary-subtitle">详细信息</div>
  </div>

  <!-- 卡片的内容 -->
  <div class="mdui-card-content"></div>

  <!-- 卡片的按钮 -->
  <div class="mdui-card-actions">
    <button class="mdui-btn mdui-ripple">运行频率：120秒/次</button>
    <button class="mdui-btn mdui-ripple">帖子克隆</button>
 </div>

</div>

    <div class="mdui-panel-item mdui-panel-item-open">
    <div class="mdui-panel-item-header">运行日志</div>
    <div class="mdui-panel-item-body">
  





<?php

  $url="http://floor.huluxia.com/post/list/ANDROID/2.1?platform=2&gkey=000000&app_version=4.0.0.7&versioncode=20141436&market_id=floor_huluxia&_key=".$_COOKIE["ekey"]."&device_code=%5Bw%5D02%3A00%3A00%3A00%3A00%3A00-%5Bi%5D866934037372573-%5Bs%5D89861119147385482175&start=0&count=20&cat_id=2&tag_id=0&sort_by=1";
  $post=file_get_contents($url);
  $post=json_decode($post,true);
  $pid=$post["posts"][0]["postID"];//最新帖子ID
  
$postJson=file_get_contents("http://floor.huluxia.com/post/detail/ANDROID/2.3?post_id=".$pid);
$postArray=json_decode($postJson,true);
$title=$postArray["post"]["title"];
$detail=nl2br($postArray["post"]["detail"]);
$detail=str_replace(array(",","<image>","</image>"),array("?","<img src='","' style='width:100%;'/>"),$detail);
$postArray["post"]["images"];

echo"抓取ID为:".$pid."的帖子";


echo"抓取帖子标题：".$t = $title;
$k = $_COOKIE['ekey'];
echo"抓取帖子内容：".$w =str_replace("_","",str_replace("</br>","%OA",$detail));


{
    
$url3 = "http://floor.huluxia.com/post/create/ANDROID/2.0?platform=2&gkey=000000&app_version=4.0.1.7&versioncode=300&market_id=tool_tencent&_key=".$k."&device_code=%5Bw%5D02%3A00%3A00%3A00%3A00%3A00%5Bd%5De2f734cc-549b-4349-a311-244c64fcc71e&cat_id=2&tag_id=-1&type=0&title=".$t."&detail=".$w."&patcha=&voice=&lng=0.0&lat=0.0&images=";
echo file_get_contents($url3);
}


?>
