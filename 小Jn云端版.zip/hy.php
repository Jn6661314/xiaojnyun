<?php
error_reporting(0);
$phoneNumber=$_COOKIE["phone"];
$password=$_COOKIE["key"];
$r=$_COOKIE["key"];
$result=file_get_contents("http://floor.huluxia.com/account/login/ANDROID/4.0?device_code=1&account=".$phoneNumber."&login_type=2&password=".$password);
$returnJson=json_decode($result,true);

$uid=$returnJson["user"]["userID"];
$filename= "vip/".$uid.".txt"; 
 $f2=str_replace("\n","",file_get_contents($filename));
 $zero1=strtotime (date("y-m-d")); //当前时间  ,注意H 是24小时 h是12小时 
$zero2=strtotime ($f2);  //到期时间，不能写2014-1-21 24:00:00  这样不对 
$guonian=ceil(($zero2-$zero1)/86400); //60s*60min*24h   
if($guonian>0){
echo "到期时间: $f2";   
}
else{
    $guonian=-$guonian;
    echo"已过期或未开通"; }