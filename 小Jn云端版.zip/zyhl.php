<?php

//登录代码
//屏蔽错误
error_reporting(0);

//调用本地数据

 {
    


 $id=$_GET["id"];
 setrawcookie("hulu",$_COOKIE["hulu"]+5,time()+259200);
echo"已送葫芦:".$h=$_COOKIE["hulu"]+5;
echo"目标葫芦:".$z=$_GET["hulu"];
if($_GET["hulu"]>$_COOKIE["hulu"]+5){
echo <<<EOF
状态:正在送葫芦，系统返回:

EOF;

}
else
{
    echo <<<EOF
    状态:本次赠送完成，系统返回:
EOF;

}
 //自动刷新
  echo'<meta http-equiv="refresh" content="10;url=/zyhl.php?id='.$id.' "> ';




/**
 * 发送葫芦侠APP请求，PS：因为和本地完全一致，会顶登录
 * @葫芦侠最新版登录模块（Jn版权所有）
 */
function send_post($url, $post_data) {
 
  $postdata = http_build_query($post_data);
  $options = array(
    'http' => array(
        "Host"=>"floor.huluxia.com",
      'method' => 'POST',
      'content' => $postdata,
      'timeout' => 15 * 60 // 超时时间（单位:s）
    )
  );
  $context = stream_context_create($options);
  echo"正在转移葫芦，退出立即停止";
  echo $result = file_get_contents($url, false, $context);
 

 
  return $result;
    
 
}
 //随机原因
$file = file("hlyy.txt");
//随机读取一行
$arr  = mt_rand( 0, count( $file ) - 1 );
echo"随机原因:";
echo$sjyy  = trim($file[$arr],"\n");
//使用方法：GET本JnAPI接口两参数就完事了，分别是phone和key
$post_data = array(
  'post_id'=>$id,
  "type_id"=>"1",
   "isadmin"=>"0",
   "score"=>"5",
  "score_txt"=>$sjyy,
  "sign"=>"2671D4F14A420875FCC000C627982B3B"
 
);
send_post('http://floor.huluxia.com/credits/transfer/ANDROID/4.1.7?platform=2&gkey=000000&app_version=4.1.1.7.2&versioncode=340&market_id=tool_tencent&_key='.$_COOKIE["key"].'&device_code=%5Bd%5D19e64e24-e8ae-4e97-9f4a-7983c918a962&phone_brand_type=HW', $post_data);
sleep(1);
}