<?php
//屏蔽错误
ini_set("error_reporting","E_ALL & ~E_NOTICE");
//批量管理
$phoneNumber=$_COOKIE["phone"];
$password=$_COOKIE["key"];
$r=$_COOKIE["key"];
$result=file_get_contents("http://floor.huluxia.com/account/login/ANDROID/4.0?device_code=1&account=".$phoneNumber."&login_type=2&password=".$password);
$returnJson=json_decode($result,true);
$msg=$returnJson["msg"];
$key=$returnJson["_key"];
$uid=$returnJson["user"]["userID"];

switch($msg)
{
  case "账号或密码错误":
    echo '<script>window.alert("账号或密码错误！");</script>';
    break;
  case "参数不合法":
    echo '<script>window.alert("参数不合法！");</script>';
    break;
  case "账号不存在":
    echo '<script>window.alert("账号不存在");</script>';
    break;
  case "":
    
    

 $filename='xiaojnroobots/'.$uid.'.txt';
 $ex=file_exists($filename);//检测文件存在与否


if($ex==1)
{
$b=file($filename);
$c=count($b)/4;
$d=$c;

//关注
$i=$_GET["id"];
if ($i==null) {
    $i=1;
}
else {
    $yi=$_GET["id"]*10-10;
}
for ($yi = $yi; $yi < 10*$i; $yi++) {
     

$phone=$b[1+$yi*4];
$n=substr($phone,0,strlen($phone)-1); 
$keyj=$b[4*$yi+2];
$keyx = substr($keyj,0,strlen($keyj)-1); 
//关注代码
$phoneNumber=$n;
$password=md5($keyx);
$result=file_get_contents("http://floor.huluxia.com/account/login/ANDROID/4.0?device_code=1&account=".$phoneNumber."&login_type=2&password=".$password);
$returnJson=json_decode($result,true);
$msg=$returnJson["msg"];
$key2=$returnJson["_key"];

//关注代码
$phoneNumber=$n;
$password=md5($keyx);
$result=file_get_contents("http://floor.huluxia.com/account/login/ANDROID/4.0?device_code=1&account=".$phoneNumber."&login_type=2&password=".$password);
$returnJson=json_decode($result,true);
$msg=$returnJson["msg"];
$key2=$returnJson["_key"];

echo$q=file_get_contents("http://floor.huluxia.com/friendship/follow/ANDROID/2.0?user_id=".$_GET["bq"]."&platform=2&gkey=000000&app_version=4.1.1.2.2&versioncode=318&market_id=tool_tencent&_key=".$key2."&device_code=%5Bw%5D02%3A00%3A00%3A00%3A00%3A00%5Bd%5De2f734cc-549b-4349-a311-244c64fcc71e");
}
 {
    $i2=$i+1;
}
}
else {
    
}
    echo"<br>已操作:10*".$i."，个，共:".$c."个";
    $b=$i+1;
$urltz="plgz.php?id=".$b."&bq=".$_GET["bq"]."&b=".$i2;
if($i*10<$c){
echo
<<<EOF
<br><br>PS:请耐心等待，关注比较慢是为了防止掉粉!
<script type="text/javascript">

　　setTimeout("window.location.href='$urltz'",5);

</script>

EOF;
}else {
    echo"<br>关注完成，欢迎下次使用";
}
}