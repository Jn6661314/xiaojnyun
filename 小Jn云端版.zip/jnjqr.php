
<?php

//处理我要关注功能冲突
if($a!="我要关注[滑稽]"){
echo";帖子ID:".$tzid=$arr2["datas"][0]["content"]["post"]["postID"];//帖子ID
}
else{
 echo"与我要关注功能冲突，已屏蔽JnAI处理";   
}


//评论获取

$pl2=file_get_contents("http://floor.huluxia.com/message/new/list/ANDROID/4.0?platform=2&gkey=000000&app_version=4.0.1.9.1&versioncode=309&market_id=tool_tencent&_key=".$_COOKIE["key"]."&device_code=%5Bw%5D02%3A00%3A00%3A00%3A00%3A00%5Bd%5De2f734cc-549b-4349-a311-244c64fcc71e&type_id=2&start=0&count=2");
$arr2 = json_decode($pl2,true);
//tzid获取
$get = "http://floor.huluxia.com/message/new/list/ANDROID/4.0?platform=2&gkey=000000&app_version=4.0.1.7&versioncode=300&market_id=tool_tencent&_key=".$key."&device_code=%5Bw%5D02%3A00%3A00%3A00%3A00%3A00%5Bd%5De2f734cc-549b-4349-a311-244c64fcc71e&type_id=2&start=0&count=1";
   $pl = file_get_contents($get);
    $pl_begin = mb_strpos($pl,',"title":"') + mb_strlen(',"title":"');//提取的开始位置
$pl_end = mb_strpos($pl,'","ext":null,"detail":null,"') - $pl_begin;//提取的结束位置
$plw = mb_substr($pl,$pl_begin,$pl_end);
$h = $plw;
$id = file_get_contents($get);
    $id_begin = mb_strpos($id,'{"postID":') + mb_strlen('{"postID":');//提取的开始位置
$id_end = mb_strpos($id,',"title":"'.$h) - $id_begin;//提取的结束位置
$tzid = mb_substr($id,$id_begin,$id_end);


//超级获取术
echo"他人评论内容：".$a=$arr2["datas"][0]["content"]["text"];//评论内容
echo";该评论人ID:".$user=$arr2["datas"][0]["content"]["user"]["userID"];//用户ID
$tx=$arr2["datas"][0]["content"]["user"]["avatar"];//头像
echo";该评论人昵称:".$name=$arr2["datas"][0]["content"]["user"]["nick"];//昵称

$ys=$arr2["datas"][0]["content"]["seq"];//楼层
echo";评论ID:".$plid=$arr2["datas"][0]["content"]["commentID"];//评论ID
$urlhf='/create/createComment.php?pid='.$tzid.'&page='.$ys.'&cid='.$plid.'"';//评论API



//发送评论


if($plid!=$_COOKIE["Texttotry"])
{
   //处理评论
$url2 = "http://". $_SERVER['HTTP_HOST']."/jnjqrapi.php?name=".$name2."&q=".$a;
   echo";批量管理回复内容：" .$html = file_get_contents($url2)."[滑稽][玫瑰]";
   if($html==null)
   {$html="听不懂。。。.";}
   
$url3 = "http://floor.huluxia.com/comment/create/ANDROID/2.0?platform=2&gkey=000000&app_version=4.0.1.7&versioncode=300&market_id=tool_tencent&_key=".$_COOKIE["key"]."&device_code=%5Bw%5D02%3A00%3A00%3A00%3A00%3A00%5Bd%5De2f734cc-549b-4349-a311-244c64fcc71e&post_id=".$tzid."&comment_id=".$plid."&text=".$html;
     $zt = file_get_contents($url3);
     $jsonStr = $zt;

$arr2 = json_decode($zt,true);
     echo";处理状态：" .$plw=$arr2["msg"]; 
setrawcookie("Texttotry",$plid,time()+360);



 
}
else{echo"处理状态：重复回复，JnAI已过滤" ; 
    
    


}



//getname
$_COOKIE["key"];
$name2=substr($_GET["name"],0,strlen($_GET["name"])-1);
if($name2==null)
{
    $name="小Jn";
}
else
{
    $name=$_GET["name"];
}
//<!--判断是否登陆-->


//判断登录过期
//补充登录跳转    
 if(strpos($plw,"未登录") > 0){


 
    $urlx = "login.php";

Header("Location:$urlx"); 
 }



?>