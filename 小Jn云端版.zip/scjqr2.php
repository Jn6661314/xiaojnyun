<?php ob_start(); ?><!doctype html>
<html lang="zh-cmn-Hans">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, shrink-to-fit=no"/>
    <meta name="renderer" content="webkit"/>
    <meta name="force-rendering" content="webkit"/>
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"/>

    <!-- MDUI CSS -->
    <link rel="stylesheet" href="https://unpkg.com/mdui@1.0.2/dist/css/mdui.min.css"/>
    
  </head>
  <body>
   

    <!-- MDUI JavaScript -->
    <script src="https://unpkg.com/mdui@1.0.2/dist/js/mdui.min.js"></script>
  </body>
</html>
<?php


$getCatJson=file_get_contents("http://floor.huluxia.com/user/info/ANDROID/4.1.8?platform=2&gkey=000000&app_version=4.2.0.4.2&versioncode=20141472&market_id=floor_web&_key=".$_COOKIE["ekey"]."&device_code=%5Bd%5D16485814-230d-424c-8af1-fda8f42d1e25&phone_brand_type=UN&user_id=".$_COOKIE["uid"]);
$catArray=json_decode($getCatJson,true);
$cats=$catArray["msg"];
if($cats==null){
$uid=$_COOKIE["uid"];
 $filename='xiaojnroobots/'.$uid.'.txt';


if ($_COOKIE["hulu"]==null) {
setrawcookie("hulu",1,time()+259200);ob_end_flush();
    $i=1;
}else
{$i=$_COOKIE["hulu"];

}
$x=$_GET["id"];
if($x=="0"){$y="1";}else{$y=($x*4)+1;}

echo"<br>请稍后，正在执行";
$h=$i;
//echo"目标帖子:".$z=$_GET["pid"];
//$s=$_GET["s"];
if($h<=4){

// 打开需要操作的文件（此处为example.txt）
    $file = fopen($filename, "r");
    $output = "";
    $lineToDelete =$y ;  // 需要删除的行号
 
    // 读取文件内容并逐行进行处理
    while(!feof($file)) {
        $line = fgets($file);
        $count++;
        // 判断当前行是否为需要删除的行
        if ($count != $lineToDelete) {
            $output .= $line;  // 将不需要删除的行的内容保存
        }
    }
 
    fclose($file);
 
    // 将处理后的内容重新写入原文件中
    $file = fopen($filename, "w");
    fwrite($file, $output);
    fclose($file);

echo <<<EOF
<br><div class="mdui-spinner mdui-spinner-colorful"></div>
<br>状态:正在删除，切勿退出
<meta http-equiv="refresh" content="0.01">

EOF;
$wl=100*$h/4;
echo <<<EOF
<div class="mdui-progress">
  <div class="mdui-progress-determinate" style="width:  $wl%;"></div>
</div>
EOF;
setrawcookie("hulu",$i+1,time()+259200);ob_end_flush();

}
else
{
setrawcookie("hulu",1,time()+259200);
ob_end_flush();
    echo <<<EOF
    状态:本次删除完成
    <br><div class="mdui-progress">
  <div class="mdui-progress-determinate" style="width: 100%;"></div>
</div>
    <br><a href="/jqrcz.php"<div class="mdui-center" style="width: 200px">点此返回账号管理页面</div></a>
EOF;

}
}