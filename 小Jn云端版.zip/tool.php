<!DOCTYPE html>
<html lang="zh">
<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"> 
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>小Jn控制面板主页</title>
	<!doctype html>
<html lang="zh-cmn-Hans">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=-1, maximum-scale=-1, shrink-to-fit=yes"/>
    <meta name="renderer" content="webkit"/>
    <meta name="force-rendering" content="webkit"/>
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"/>

 <link rel="stylesheet" href="css/index.css" />
  </head>
  
  <div class="mdui-row">
  <div class="mdui-col-md-4"><h3 class="animate__animated animate__pulse animate__repeat-2">欢迎回家，<?php     
    error_reporting(0);
    if($_COOKIE["name"]==null)
 {$name="未登录";}
 
 else
 {$name=$_COOKIE["name"];}
 echo $name; ?></h3><?php if($_COOKIE["name"]==null)
 {echo
 <<<EOF
 <a href=/login.php >
 <style type="text/css">
     .zzidc{color: white;;width: 200px;height: 100px;}
</style>
</head>
<body>
<div class="zzidc"><ajn>点此登录</a></ajn></div>
EOF;
}
 ?><br>
  <div class="mdui-col-md-4 mdui-col-offset-md-4"></div>
</div>
<p id="switch-theme">>点此切换黑白</p> <script>      if(localStorage.darkTheme)         document.body.classList.add("mdui-theme-layout-dark");           document.getElementById("switch-theme").addEventListener(         "click",         () => document.body.classList.toggle("mdui-theme-layout-dark") ?             (localStorage.darkTheme = true) :             (delete localStorage.darkTheme)     ); </script>
<?php
//热更新检测
    error_reporting(0);
$outPath=$_SERVER['DOCUMENT_ROOT'] ;
$url = ("https://jn666.lanzouk.com/b06bjg7id");

$ch = curl_init();

curl_setopt($ch, CURLOPT_URL,$url);

curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);

curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);//如果把这行注释掉的话，就会直接输出 

$kw = curl_exec($ch); 

$mark1="【";
$mark2="】";


	$st =stripos($kw,$mark1);

	$ed =stripos($kw,$mark2);


 $gx=mb_substr($kw,($st-33),($ed-$st)-3
	,'UTF-8');
	
  if($gx!=file_get_contents("gx.txt")){
echo <<<EOF
---------发现新版本固件

<div class="mdui-chip">
  <span class="mdui-chip-icon"><i class="mdui-icon material-icons">system_update</i></span>
  <span class="mdui-chip-title">你可以去通知管理员热更新</span>
</div>
</div>

EOF;
}
?>
<a href="/jkcz.php">
<div class="mdui-chip">
  <span class="mdui-chip-icon"><i class="mdui-icon material-icons">videocam</i></span>
  <span class="mdui-chip-title">免费监控，无需注册，点击即用</span>
</div></a>
<a href="/gxzb.php">
<div class="mdui-chip">
  <span class="mdui-chip-icon"><i class="mdui-icon material-icons">bubble_chart</i></span>
  <span class="mdui-chip-title">个性装扮</span>
</div></a>
<a href="/ckdiy.php">
<div class="mdui-chip">
  <span class="mdui-chip-icon"><i class="mdui-icon material-icons">border_color</i></span>
  <span class="mdui-chip-title">词库自定义</span>
</div>
</div></a>
<a href="/jc.php">
<div class="mdui-chip">
  <span class="mdui-chip-icon"><i class="mdui-icon material-icons">videocam</i></span>
  <span class="mdui-chip-title">账号功能预教程</span>
</div>

</div></a>
<a href="javascript:location.reload();">
<div class="mdui-chip">
  <span class="mdui-chip-icon"><i class="mdui-icon material-icons">refresh</i></span>
  <span class="mdui-chip-title">刷新页面</span>
</div>

</div></a>
<br>小Jn提供的所有工具和服务均全部免费,如出现收费现象，请及时及时退款举报！

<?php
//获取一言
$file = file("xiaojnyy.txt");
//随机读取一行
$arr  = mt_rand( 0, count( $file ) - 1 );
echo"<br>---".$content  = trim($file[$arr],"\n");

if ($_COOKIE["uid"]!=null) {
   echo 
<<<EOF
  <div class="mdui-col-md-4"><ajn class="animate__animated animate__flash animate__repeat-2">UID:
EOF;
}
?>
<?php echo $user=$_COOKIE["uid"]; ?></ajn></div>
<?php
if($_COOKIE["name"]==null)
 {$name="未登录";}
 
 else
 {
echo <<<EOF
  <script src="https://cdn.bootcss.com/clipboard.js/1.7.1/clipboard.min.js"></script>
<script src="https://code.jquery.com/jquery-3.3.1.min.js"></script>
<div><span id="btn$user" data-clipboard-text="$user">点此一键复制uid</span></div>
<div id="show$user" style="display: none;">已复制</div>
<script>
	var btn=document.getElementById('btn$user');
	var clipboard=new Clipboard(btn$user);
	clipboard.on('success', function(e){
		$('#show$user').slideDown().delay(1500).slideUp(300);
		console.log(e);
	});
	clipboard.on('error', function(e){
		$('#show$user').slideDown().delay(1500).slideUp(300);
		console.log(e);
	});
</script>
EOF;
}
?>
  </ul>
  <?php
  if($_COOKIE["gxzb"]==null)
  {echo
<<<EOF


  
  
<link href="/单页/css/style.css" rel="stylesheet" type="text/css">


</div>
<!--以下网站都可以在百度查找到,请呵呵哒-->
<ul class="mainmenu">
	<li><a href="./jqrcz.php"><b><img src="/单页/images/mt.png"></b><span>批量管理</span></a></li>
	<li><a href="../box.php"><b><img src="/单页/images/t4.png"></b><span>工具箱</span></a></li>
	<li><a href="./site.php"><b><img src="/单页/images/t6.png"></b><span>分站</span></a></li>


	<li><a href="https://jq.qq.com/?_wv=1027&k=p5ZfcLhV"><b><img src="/单页/images/d6.png"></b><span>源码</span></a></li>
	<li class="animate__animated animate__flash animate__repeat-100"><a href="./jc.php"><b><img src="/单页/images/d4.png"></b><span>视频教程</span></a></li>     	 
	<li><a href="/fz.php"><b><img src="/单页/images/s5.png"></b><span>发展历史</span></a></li>

	
	<li><a href="/login.php"><b><img src="/单页/images/jt.png"></b><span>重新登录</span></a></li>
	<li><a href="/tcdl.php"><b><img src="/单页/images/t8.png"></b><span>退出登录</span></a></li>
	<li><a href="/ckdiy.php"><b><img src="/单页/images/t4.png"></b><span>词库自定义</span></a></li>
	
	
	<li><a href="https://afdian.net/group/8a3902f0e54e11eba4aa52540025c377"><b><img src="/单页/images/t10.png"></b><span>官方论坛</span></a></li>
	<li><a href="https://jq.qq.com/?_wv=1027&k=p5ZfcLhV"><b><img src="/单页/images/love.png"></b><span>官方Q群</span></a></li>
	<li><a href="/gx.php"><b><img src="/单页/images/gf.png"></b><span>强制更新</span></a></li>
   </div>  </div></ul>





EOF;
}

  else {
      
  echo
<<<EOF
  
<div class="mdui-center" style="width: 200px">
    
 <br>  <br> <a href="/jqrcz.php"><button class="mdui-btn mdui-btn-raised">批量管理</button></a>
   
  <a href="/box.php"><button class="mdui-btn mdui-btn-raised">工具箱</button></a>
  <br> <br> <a href="/site.php"><button class="mdui-btn mdui-btn-raised">分站</button></a>
   
  <a href="/download"><button class="mdui-btn mdui-btn-raised">源码</button></a>
  <br> <br> <a href="/jc.php"><button class="mdui-btn mdui-btn-raised">教程文档</button></a>
   
  <a href="/fz.php"><button class="mdui-btn mdui-btn-raised">发展历史</button></a>
  
  <br><br>  <a href="/login.php"><button class="mdui-btn mdui-btn-raised">重新登录</button></a>
   
  <a href="/tcdl.php"><button class="mdui-btn mdui-btn-raised">退出登录</button></a>
 <br>  <br> <a href="/ckdiy.php"><button class="mdui-btn mdui-btn-raised">词库自定义</button></a>
   
  <a href="https://afdian.net/group/8a3902f0e54e11eba4aa52540025c377"><button class="mdui-btn mdui-btn-raised">官方论坛</button></a>
<br>   <br> <a href="https://jq.qq.com/?_wv=1027&k=p5ZfcLhV"><button class="mdui-btn mdui-btn-raised">官方Q群</button></a>
   
  <a href="http://qm.qq.com/cgi-bin/qm/qr?_wv=1027&k=OCCZ1B9sDIHf2h1Wryi3B0ZRyf81eQxw&authKey=BZcdw75BLRjukoYP702qRu5t88z1EYZZx7kOYAAVnAOtX%2FeTb2yCNqxkqeKcdZu%2F&noverify=0&group_code=338109921"><button class="mdui-btn mdui-btn-raised">官方分群</button></a>
</div>
 </div>
EOF;
}
?></div>
 </div>
 <br><br><br><br>
 <iframe id="afdian_leaflet_{1}" src="https://afdian.net/leaflet?slug=xiaogz" width="100%" scrolling="no" height="200" frameborder="0"></iframe><script>document.body.clientWidth< 700 ? document.getElementById("afdian_leaflet_{1}").width = "100%" : document.getElementById("afdian_leaflet_{1}").width = "640"</script>

<br>

<div class="mdui-tab mdui-tab-full-width" id="example4-tab">
    <a href="#example4-tab1" class="mdui-ripple">最新公告</a>
   
     <a href="#example4-tab4" class="mdui-ripple">大佬列表</a>
  </div>
   <div id="example4-tab4" class="mdui-p-a-2">
    <p>大佬列表（点击可以关注/查看主页）</p>
    <ul class="mdui-list">
    删工具箱策划
        <a href="/gzapi.php?uid=7642103"
  <li class="mdui-list-item mdui-ripple">
    <div class="mdui-list-item-avatar"><img src="http://q2.qlogo.cn/headimg_dl?dst_uin=2805484997&spec=100"/></div>
    <div class="mdui-list-item-content">
      <div class="mdui-list-item-title">云沐ღ </div>
      <div class="mdui-list-item-text mdui-list-item-one-line"><span class="mdui-text-color-theme-text"></span>但愿日子清静，无时无刻白嫖！</div>
    </div>
    </a>
  </li> 
  闲杂人等
  <a href="/gzapi.php?uid=12132089"
  <li class="mdui-list-item mdui-ripple">
    <div class="mdui-list-item-avatar"><img src="avatar1.jpg"/></div>
    <div class="mdui-list-item-content">
      <div class="mdui-list-item-title">滑稽MC</div>
      <div class="mdui-list-item-text mdui-list-item-one-line"><span class="mdui-text-color-theme-text">MC,技术</span> - 葫芦侠在线版开发</div>
    </div>
    </a>
  </li> 
      <a href="https://b23.tv/IzQl7l9"

  <li class="mdui-list-item mdui-ripple">
    <div class="mdui-list-item-avatar"><img src="avatar3.jpg"/></div>
   <div class="mdui-list-item-content">
      <div class="mdui-list-item-title">Jn</div>
      <div class="mdui-list-item-text mdui-list-item-one-line"><span class="mdui-text-color-theme-text"></span>经常出一些保姆级技术教程!</div>
    </div>
  </li></a>
   
          <a href="/gzapi.php?uid=18925902"
  <li class="mdui-list-item mdui-ripple">
    <div class="mdui-list-item-avatar"><img src="hm.jpg"/></div>
    <div class="mdui-list-item-content">
      <div class="mdui-list-item-title">远方一抹晚霞</div>
      <div class="mdui-list-item-text mdui-list-item-one-line"><span class="mdui-text-color-theme-text"></span>我就是一名普普通通的白嫖怪呀！</div>
    </div>
    </a>
  </li> 
   <a href="/gzapi.php?uid=18821624"
  <li class="mdui-list-item mdui-ripple">
    <div class="mdui-list-item-avatar"><img src="mx.jpg"/></div>
    <div class="mdui-list-item-content">
      <div class="mdui-list-item-title">梦醒</div>
      <div class="mdui-list-item-text mdui-list-item-one-line"><span class="mdui-text-color-theme-text"></span>一只没有梦想的咸鱼</div>
    </div>
    </a>
  </li> 
      <a href="/gzapi.php?uid=128335"
  <li class="mdui-list-item mdui-ripple">
    <div class="mdui-list-item-avatar"><img src="ouh.jpg"/></div>
    <div class="mdui-list-item-content">
      <div class="mdui-list-item-title">欧皇</div>
      <div class="mdui-list-item-text mdui-list-item-one-line"><span class="mdui-text-color-theme-text"></span> - 我就是一歌手</div>
    </div>
    </a>
  </li> 
        <a href="/gzapi.php?uid=7183021"
  <li class="mdui-list-item mdui-ripple">
    <div class="mdui-list-item-avatar"><img src="mchj.jpg"/></div>
    <div class="mdui-list-item-content">
      <div class="mdui-list-item-title">MC滑稽</div>
      <div class="mdui-list-item-text mdui-list-item-one-line"><span class="mdui-text-color-theme-text">技术</span> - 我是MC滑稽</div>
    </div>
    </a>
  </li>
  
         <a href="/gzapi.php?uid=16189034"
  <li class="mdui-list-item mdui-ripple">
    <div class="mdui-list-item-avatar"><img src="qf.jpg"/></div>
    <div class="mdui-list-item-content">
      <div class="mdui-list-item-title">穷枫</div>
      <div class="mdui-list-item-text mdui-list-item-one-line"><span class="mdui-text-color-theme-text">破解</span> - 逆向小白 葫芦侠萌新</div>
    </div>
    </a> 


   
  
  <a href="/gzapi.php?uid=12699242"
  <li class="mdui-divider-inset mdui-m-y-0"></li>
  <li class="mdui-list-item mdui-ripple">
    <div class="mdui-list-item-avatar"><img src="avatar2.jpg"/></div>
    <div class="mdui-list-item-content">
      <div class="mdui-list-item-title">小滑稽</div>
      <div class="mdui-list-item-text mdui-list-item-one-line"><span class="mdui-text-color-theme-text">我是小滑稽呀</span> - 技术大佬</div>
    </div>
  </li>  <a href="/gzapi.php?uid=17835996"
  <li class="mdui-divider-inset mdui-m-y-0"></li>
  <li class="mdui-list-item mdui-ripple">
    <div class="mdui-list-item-avatar"><img src="avatar4.jpg"/></div>
   <div class="mdui-list-item-content">
      <div class="mdui-list-item-title">无语</div>
      <div class="mdui-list-item-text mdui-list-item-one-line"><span class="mdui-text-color-theme-text"></span>只摸鱼不干正事的老帅批</div>
    </div>
  </li></a>
   <a href="/gzapi.php?uid=5131563"
  <li class="mdui-divider-inset mdui-m-y-0"></li>
  <li class="mdui-list-item mdui-ripple">
    <div class="mdui-list-item-avatar"><img src="avatar5.jpg"/></div>
    <div class="mdui-list-item-content">
      <div class="mdui-list-item-title">萝卜</div>
      <div class="mdui-list-item-text mdui-list-item-one-line"><span class="mdui-text-color-theme-text">这是一种蔬菜</span></div>
    </div>
  </li> 
   <a href="/gzapi.php?uid=15675447"
  <li class="mdui-divider-inset mdui-m-y-0"></li>
  <li class="mdui-list-item mdui-ripple">
    <div class="mdui-list-item-avatar"><img src="avatar6.jpg"/></div>
    <div class="mdui-list-item-content">
      <div class="mdui-list-item-title">云猫</div>
      <div class="mdui-list-item-text mdui-list-item-one-line"><span class="mdui-text-color-theme-text">貌似可以白嫖，我能上嘛</span></span></div>
    </div>
  </li> 
  </a>
   <a href="/gzapi.php?uid=23436195"
  <li class="mdui-divider-inset mdui-m-y-0"></li>
  <li class="mdui-list-item mdui-ripple">
    <div class="mdui-list-item-avatar"><img src="avatar7.jpg"/></div>
    <div class="mdui-list-item-content">
      <div class="mdui-list-item-title">小猪猪520</div>
      <div class="mdui-list-item-text mdui-list-item-one-line"><span class="mdui-text-color-theme-text">我是一条咸猪，不要管我</span></div>
    </div>
  </li> </a>

  <a href="/gzapi.php?uid=22271284"
  <li class="mdui-divider-inset mdui-m-y-0"></li>
  <li class="mdui-list-item mdui-ripple">
    <div class="mdui-list-item-avatar"><img src="http://cdn.u1.huluxia.com/g3/M03/4C/5F/wKgBOV6ew4qAJxrzAAIotvt_WwA255.jpg"referrerPolicy="no-referrer"/></div>
   <div class="mdui-list-item-content">
      <div class="mdui-list-item-title">水(⊙o⊙)啊</div>
      <div class="mdui-list-item-text mdui-list-item-one-line"><span class="mdui-text-color-theme-text"></span>天若有情天亦老，人间正道是沧桑。</div>
    </div>
  </li></a>
  <a href="/gzapi.php?uid=1478397"
  <li class="mdui-list-item mdui-ripple">
    <div class="mdui-list-item-avatar"><img src="http://cdn.u1.huluxia.com/g4/M02/14/47/rBAAdmDyrdOAHGeyAAE3Ku3HLlQ462.jpg" referrerPolicy="no-referrer"/></div>
    <div class="mdui-list-item-content">
      <div class="mdui-list-item-title">猫</div>
      <div class="mdui-list-item-text mdui-list-item-one-line"><span class="mdui-text-color-theme-text"></span>人类的本质</div>
    </div>
    </a>
  </li> 
    </ul>
  </div>
  <div id="example4-tab1" class="mdui-p-a-2">
    新版首页上线！有点简陋望见谅！
    <br><br>欢迎大佬来给我们出谋划策！</p><h3>友链：</h3>
    <ul class="mdui-list">
          <a href="https://www.yhdzz.cn"
  <li class="mdui-list-item mdui-ripple">
    <div class="mdui-list-item-avatar"><img src="https://beijing.cdn.yhdzz.cn/studio.yhdzz.cn/2022/03/xiaoman1221s-blog-logo.png"/></div>
    <div class="mdui-list-item-content">
      <div class="mdui-list-item-title">小满1221的博客
</div>
      <div class="mdui-list-item-text mdui-list-item-one-line"><span class="mdui-text-color-theme-text"></span>芸芸众生的一个小白
</div>
    </div>
    </a>
  </li> 
    <a href="https://xding.top/"
  <li class="mdui-list-item mdui-ripple">
    <div class="mdui-list-item-avatar"><img src="https://xding.top/face.png"/></div>
    <div class="mdui-list-item-content">
      <div class="mdui-list-item-title">小丁的博客
</div>
      <div class="mdui-list-item-text mdui-list-item-one-line"><span class="mdui-text-color-theme-text"></span>一个神秘的大宝贝...
</div>
    </div>
    </a>
  </li> 
         <a href="http://jixiejidiguan.top/"
  <li class="mdui-list-item mdui-ripple">
    <div class="mdui-list-item-avatar"><img src="http://q1.qlogo.cn/g?b=qq&nk=3549518275&s=640"/></div>
    <div class="mdui-list-item-content">
      <div class="mdui-list-item-title">JIXIEJIDIGUAN

</div>
      <div class="mdui-list-item-text mdui-list-item-one-line"><span class="mdui-text-color-theme-text"></span>一个静态超多bog加载速度非常卡的网页！滑稽

</div>
    </div>
    </a>
  </li> 

  

      
  
  
  </ul>
  </div>
  
  
  
 
    </div>
  </div>
</div>
</div></div>
<div class="ori-footer mdui-col mdui-text-center mdui-list-item-content">
<div class="mdui-list-item-content">Copyright ©&nbsp;2021&nbsp;<ajn>滑稽MC</ajn>
<br><br>
<span class="my-face ftspan2" style="padding: 0px 0.8px 0px 0px;">(っ•̀ω•́)っ⁾⁾</span>
<span class="ftspan1" title="哈哈">策划QQ:2805484997</span>
</div>

<br>参与本网站短暂测试即同意我们的
 <br><a href="/shouldread.php" ><ajn>使用条款|免责声明</ajn></a><br>并遵守互联网网络规定，不滥用，不搞事，营造良好的网络环境，需要每个人的遵守!<br>   <script type="text/javascript">document.write(unescape("%3Cspan id='cnzz_stat_icon_1279812358'%3E%3C/span%3E%3Cscript src='https://s9.cnzz.com/z_stat.php%3Fid%3D1279812358%26online%3D1%26show%3Dline' type='text/javascript'%3E%3C/script%3E"));</script>


</body>
   </div>

  


<!-- MDUI CSS -->
    <link rel="stylesheet" href="https://unpkg.com/mdui@1.0.2/dist/css/mdui.min.css"/>

    <!-- MDUI JavaScript -->
    <script src="https://unpkg.com/mdui@1.0.2/dist/js/mdui.min.js"></script>
  
	<!--可无视-->

	
	<!--必要样式-->
	<link rel="stylesheet" href="css/naranja.min.css">
</head>
<body>
	
	<script>
  var tab = new mdui.Tab('#example4-tab');
  document.getElementById('example-4').addEventListener('open.mdui.dialog', function () {
    tab.handleUpdate();
  });
</script>
		</div></div>
	</div>





<style>


/*页脚信息*/
.foot-ellipsis {
    display: block;
    text-overflow: ellipsis;
    white-space: nowrap;
    overflow: hidden;
    line-height:20px;
    padding: 15px 0px 0px 0px;
	z-index:3;
}
.ori-footer .ftspan {
	background-size: auto auto;
	background-position: bottom right;
	background-image: linear-gradient(#7D7BFE, #7D7BFE);
}

.ori-footer .ftspan:hover {
	background-repeat: no-repeat;
	background-size: auto 0px;
	background-position: top right;
	color: #7D7BFE;
}

.ori-footer .ftspan1 {
	background-size: auto auto;
	background-position: top right;
	background-image: linear-gradient(#A3A1FF, #A3A1FF);
	transition: all 0.25s ease-out;
	margin-right: -4px;
}

.ori-footer .ftspan1:hover {
	background-repeat: no-repeat;
	background-position: bottom right;
	background-size: auto 2px;
	color: #7D7BFE;
}

.ori-footer .ftspan2 {
	color: #4240D4;
	font-size: 16px;
}

.ori-footer span {
    padding: 3px 6px;
    color: #fff;
    font-size: 12px;
}

.ori-footer a {
    text-decoration: none;
}

/*删除线变遮挡*/
s {
	text-decoration: none;
	color: rgba(0,0,0,0);
	background-color: #5755D9;
	transition: all 0.25s ease-in-out;
}
s:hover{
	background-color: rgba(0,0,0,0);
	color: #5755D9;
}


</style> 
</div>
