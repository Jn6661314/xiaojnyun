<?php
header("Location:/hdjqrcz.php");
ini_set("error_reporting","E_ALL & ~E_NOTICE");
if($_COOKIE["phone"]==null)
{
 echo '<script>window.alert("未登录！");</script>';
 }
$phoneNumber=$_COOKIE["phone"];
$password=$_COOKIE["key"];
$r=$_COOKIE["key"];
$result=file_get_contents("http://floor.huluxia.com/account/login/ANDROID/4.0?device_code=1&account=".$phoneNumber."&login_type=2&password=".$password);
$returnJson=json_decode($result,true);
$msg=$returnJson["msg"];
$key=$returnJson["_key"];
$uid=$returnJson["user"]["userID"];

switch($msg)
{
  case "账号或密码错误":
    echo '<script>window.alert("账号或密码错误！");</script>';
    break;
  case "参数不合法":
    echo '<script>window.alert("参数不合法！");</script>';
    break;
  case "账号不存在":
    echo '<script>window.alert("账号不存在");</script>';
    break;
  case "":
    
    
 $filename='hd/'.$uid.'.txt';
unlink($filename);


for($i2=0;$i2<4;$i2++)
{
    
$delline= $i2($_GET["id"]+1); //要删除的行数
$farray= file ( $filename ); //读取文件数据到数组中
for($i=0;$i < count ( $farray);$i ++ )

{

if (strcmp($i+ 1, $delline)==0) //判断删除的行,strc
{
continue ;
}
if (trim ( $farray[$i])<>"") //删除文件中的所有空行
{
$newfp .= Sfarray[$i]; // 重新整理后的数据}
}}
$fp = @fopen ( $filename," w" ); //以写的方式打开文件@ fputs ($fp，$newfp );

@fclose ($fp );
}
if($_GET["id"]==null)
{
unlink($filename);
}
}