需要监控sell执行，每天一次
rm -rf qd/*
需要监控访问地址（一分钟一次）
jkapi1.php
jkapi2.php
jkapi3.php
jka.php
jkb.php
jkc.php