<?php
$today = date( "F j, Y, g:i a ");
	$today2 = date( "H:i:s "); 
		  $myfile = fopen("og.txt", "w") or die("Unable to open file!");
$txt = "上次运行：".$today."具体时间：".$today2;
fwrite($myfile, $txt);
fclose($myfile);   
header('Content-Type: text/plain;charset=utf-8');
error_reporting(0);
$dir = './jk/'; //指定目录
if($handle = @opendir($dir)) {
	while(($file = readdir($handle)) !== false) {
		if(end(explode('.',$file)) === 'txt' && is_file($dir . $file)) {
			echo$jn=file_get_contents($dir . $file);
		
  
		 
		
			}
	}
} else {
	echo '目录无法打开！';
}




 