<?php ob_start(); ?>
<?php
$getCatJson=file_get_contents("http://floor.huluxia.com/user/info/ANDROID/4.1.8?platform=2&gkey=000000&app_version=4.2.0.4.2&versioncode=20141472&market_id=floor_web&_key=".$_COOKIE["ekey"]."&device_code=%5Bd%5D16485814-230d-424c-8af1-fda8f42d1e25&phone_brand_type=UN&user_id=".$_COOKIE["uid"]);
$catArray=json_decode($getCatJson,true);
$cats=$catArray["msg"];
if($cats!=null){

 
Header("Location: /login.php");
ob_end_flush();
  

}    


 ?>


<!DOCTYPE html>
<html lang="zh">
<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"> 
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>小Jn——批量管理管理</title>
	<!doctype html>
<html lang="zh-cmn-Hans">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, shrink-to-fit=no"/>
    <meta name="renderer" content="webkit"/>
    <meta name="force-rendering" content="webkit"/>
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"/>

<!-- MDUI CSS -->
    <link rel="stylesheet" href="https://unpkg.com/mdui@1.0.2/dist/css/mdui.min.css"/>
    

    <!-- MDUI JavaScript -->
    <script src="https://unpkg.com/mdui@1.0.2/dist/js/mdui.min.js"></script>
    <body class="mdui-appbar-with-toolbar">
  <div class="mdui-appbar mdui-appbar-fixed mdui-appbar-scroll-hide">
    <div class="mdui-toolbar mdui-color-theme">
  <a href="javascript:window.history.back();" class="mdui-btn mdui-btn-icon"><i class="mdui-icon material-icons">keyboard_arrow_left</i></a>
  <span class="mdui-typo-title">恢复部分功能</span>
  <div class="mdui-toolbar-spacer"></div>
  
  

  <a href="javascript:location.reload();" class="mdui-btn mdui-btn-icon"><i class="mdui-icon material-icons">refresh</i></a>
<button class="mdui-btn mdui-btn-icon" mdui-menu="{target:'#main-menu'}"><i class="mdui-icon material-icons">more_vert</i></button>

<ul class="mdui-menu" id="main-menu">

              	<li class="mdui-menu-item" >
                	<a href="/tool.php" class="mdui-ripple">首页</a>
              	</li>
              	<li class="mdui-menu-item" >
                	<a href="/jqrcz.php" class="mdui-ripple">批量管理</a>
              	</li>
              	<li class="mdui-menu-item" >
                	<a href="/box.php" class="mdui-ripple">工具箱</a>
              	</li>
              	<li class="mdui-menu-item" >
                	<a href="/site.php" class="mdui-ripple">分站</a>
              	</li>
            </ul>
  		</div>
	</div>
		<script src="./js/mdui.min.js"></script> 	  <script>     if(localStorage.darkTheme)         document.body.classList.add("mdui-theme-layout-dark");      document.getElementById("switch-theme").addEventListener(         "click",         () => document.body.classList.toggle("mdui-theme-layout-dark") ?             (localStorage.darkTheme = true) :             (delete localStorage.darkTheme)     );  </script><p id="switch-theme">>点此切换黑白</p> <script>      if(localStorage.darkTheme)         document.body.classList.add("mdui-theme-layout-dark");           document.getElementById("switch-theme").addEventListener(         "click",         () => document.body.classList.toggle("mdui-theme-layout-dark") ?             (localStorage.darkTheme = true) :             (delete localStorage.darkTheme)     ); </script><script type="text/javascript" src="https://s9.cnzz.com/z_stat.php?id=1279812358&web_id=1279812358"></script></a>               	</li>             </ul>   		</div> 	</div> 	
	<script src="./js/jquery.min.js"></script>
	<script type="text/javascript" charset="utf-8">
	  $(window).scroll(function(){
	    var scrollTop = $(window).scrollTop();
	   if (scrollTop < 100) {
	      $(".mdui-APPbar").removeClass("mdui-color-theme");
          $(".mdui-APPbar").addClass("mdui-text-color-black");
          $(".mdui-APPbar").removeClass("mdui-text-color-white")
	   } else {
	      $(".mdui-APPbar").addClass("mdui-text-color-white");
	      $(".mdui-APPbar").addClass("mdui-color-theme");
	      $(".mdui-APPbar").removeClass("mdui-text-color-black");
	   }
	  });
	</script>

</div>
  </head><div class="mdui-ripple">
<div class="mdui-card">
  <div class="mdui-card-media">
    <img src="/card.webp"/>
    <div class="mdui-card-media-covered">
      <div class="mdui-card-primary">
        <div class="mdui-card-primary-title">欢迎回家</div>
        <div class="mdui-card-primary-subtitle"><?php  $userMsg=file_get_contents("http://floor.huluxia.com/user/info/ANDROID/2.1?_key=".$_COOKIE["ekey"]."&user_id=".$_COOKIE["uid"]);
$user=json_decode($userMsg,true);

$namejn=$user["nick"];echo$namejn ;?></div>
      </div>
      <div class="mdui-card-actions">
        <a href="/add.php"<button class="mdui-btn mdui-ripple mdui-ripple-white">添加账号</button></a>
        <a href="/add2.php"<button class="mdui-btn mdui-ripple mdui-ripple-white">批量添加账号</button></a>
           <a href="/scjqr.php" <button class="mdui-btn mdui-ripple mdui-ripple-white">一键全删</button></a>
      </div>
    </div>
  </div>
</div>
</div>





</body>

  
	<!--可无视-->
	<link rel="stylesheet" type="text/css" href="css/bootstrap-grid.min.css" /><!--CSS RESET-->

	
	<!--必要样式-->
	<link rel="stylesheet" href="css/naranja.min.css">
</head>
<body>
	  <div class="mdui-tab mdui-tab-full-width" id="example4-tab">
    <a href="#example4-tab1" class="mdui-ripple">功能面板</a>
    <a href="#example4-tab2" class="mdui-ripple">回复自定义</a>
    <a href="#example4-tab3" class="mdui-ripple">常见问题</a>
  </div>
  <div id="example4-tab1" class="mdui-p-a-2">
 <ul class="mdui-list"> 
 <a href="/key.php">
<li class="mdui-list-item mdui-ripple">
   <i class="mdui-list-item-icon mdui-icon material-icons">data_usage</i>
    <div class="mdui-list-item-content">批量管理监控密码设置</div>
  </li>
     <a href="/plqd.php">
  <li class="mdui-list-item mdui-ripple">
    <i class="mdui-list-item-icon mdui-icon material-icons">note</i>
    <div class="mdui-list-item-content">批量签到</div>
  </li>
   <a href="/plgzgj.php">
  <li class="mdui-list-item mdui-ripple">
    <i class="mdui-list-item-icon mdui-icon material-icons">note</i>
    <div class="mdui-list-item-content">批量关注</div>
  </li>
<a href="/plqggj.php">
  <li class="mdui-list-item mdui-ripple">
    <i class="mdui-list-item-icon mdui-icon material-icons">note</i>
    <div class="mdui-list-item-content">批量取关</div>
  </li>
</a>
<a href="/pldzgj.php">
  <li class="mdui-list-item mdui-ripple">
    <i class="mdui-list-item-icon mdui-icon material-icons">note</i>
    <div class="mdui-list-item-content">批量点赞</div>
  </li>
</a>
<a href="/plhtxgj.php">
  <li class="mdui-list-item mdui-ripple">
    <i class="mdui-list-item-icon mdui-icon material-icons">note</i>
    <div class="mdui-list-item-content">批量换头像</div>
  </li>
</a>
<a href="/plshlgj.php">
  <li class="mdui-list-item mdui-ripple">
    <i class="mdui-list-item-icon mdui-icon material-icons">note</i>
    <div class="mdui-list-item-content">批量转移葫芦</div>
  </li>
</a>
<a href="/pldtgj.php">
  <li class="mdui-list-item mdui-ripple">
    <i class="mdui-list-item-icon mdui-icon material-icons">note</i>
    <div class="mdui-list-item-content">批量顶帖</div>
  </li>
 </ul>
  </div>
  <div id="example4-tab2" class="mdui-p-a-2">
    <ul class="mdui-list"><a href="/yourck.php">
  <li class="mdui-list-item mdui-ripple">
    <i class="mdui-list-item-icon mdui-icon material-icons">note</i>
    <div class="mdui-list-item-content">专属词库<p></p>（专属自定义回复，立即生效）</div>
  </li>
  <a href="/yourckd.php">
  <li class="mdui-list-item mdui-ripple">
    <i class="mdui-list-item-icon mdui-icon material-icons">note</i>
    <div class="mdui-list-item-content">专属词库设置<p></p></div>
  </li> <a href="https://www.wjx.top/vm/mLtandD.aspx">
<li class="mdui-list-item mdui-ripple">
   <i class="mdui-list-item-icon mdui-icon material-icons">data_usage</i>
    <div class="mdui-list-item-content">自定义批量管理回复</div>
  </li>
  </ul>
    </a>
  </div>
  <div id="example4-tab3" class="mdui-p-a-2">
    <p>下次也不一定写</p>
    
  </div>
</div>

<script>
  var tab = new mdui.Tab('#example4-tab');
  document.getElementById('example-4').addEventListener('open.mdui.dialog', function () {
    tab.handleUpdate();
  });
</script>
	<div class="container">
		<div class="row" style="padding:2em 0">
			<div class="col-md-2">
		
<div style="margin: 0 auto; width: 0%; position: fixed; bottom: 5px; height: 100％; font-size: 0; line-height: 0; z-index: 100; text-align: left;">

	
		</div></div>


 <?php
 
$getCatJson=file_get_contents("http://floor.huluxia.com/user/info/ANDROID/4.1.8?platform=2&gkey=000000&app_version=4.2.0.4.2&versioncode=20141472&market_id=floor_web&_key=".$_COOKIE["ekey"]."&device_code=%5Bd%5D16485814-230d-424c-8af1-fda8f42d1e25&phone_brand_type=UN&user_id=".$_COOKIE["uid"]);
$catArray=json_decode($getCatJson,true);
$cats=$catArray["msg"];
if($cats==null){
$uid=$_COOKIE["uid"];

$dqdz=$_SERVER['HTTP_HOST'];
ini_set("error_reporting","E_ALL & ~E_NOTICE");

     $filename2='jkkey/'.$_COOKIE["uid"].'.txt';

$jnx=file($filename2);

 $filename='xiaojnroobots/'.$uid.'.txt';
 $ex=file_exists($filename);//检测文件存在与否
if($ex==1)
{
$b=file($filename);
$c=count($b)/4;
$d=$c;
 echo"您当前有：".$c."个批量管理";
 if($c=="0"){$uid=$_COOKIE["uid"];
 $filename='xiaojnroobots/'.$uid.'.txt';
unlink($filename);

echo <<<EOF
<br><div class="mdui-spinner mdui-spinner-colorful"></div>
<br>状态:正在刷新，请稍候
<meta http-equiv="refresh" content="0.01">

EOF;
}
for($i=0;$i<$c;$i++)
{
    $jkkey=$jnx[0*$i];
$name=$b[4*$i];
$phone=$b[1+$i*4];
$n=substr($phone,0,strlen($phone)-1); 
$keyj=$b[4*$i+2];
$keyx = substr($keyj,0,strlen($keyj)-1); 
$gn=$b[4*$i+3];

  echo <<<EOF
  
<div class="mdui-card">

  
  <!-- 卡片的标题和副标题 -->
  <div class="mdui-card-primary">
    <div class="mdui-card-primary-title">批量管理$name</div>
    <div class="mdui-card-primary-subtitle">功能：$gn</div>
  </div>

  <!-- 卡片的内容 -->
  <div class="mdui-card-content">
  <p>1，聊天</p>
      <p>2，我要关注</p>
      <p>3，我要取关</p>
      <p>4，要广告费</p>
      <p>5，我要互关
      <p>6，我要点赞</div>

  <!-- 卡片的按钮 -->
 
  <div class="mdui-card-actions">
     <a href='box2.php?u=$uid&id=$i' class="mdui-btn mdui-ripple">前端运行</a>
    <button class="mdui-btn mdui-ripple"mdui-dialog="{target: '#example-4$i'}">后端运行</button>
    <a href="/qkzh.php?phone=$n&key=$keyx" <button class="mdui-btn mdui-ripple mdui-ripple-white">切换账号</button></a>
         <a href='/jczh.php?phone=$n&key=$keyx' class="mdui-btn mdui-ripple">检测账号</a>
    <a href='/scjqr2.php?id=$i' class="mdui-btn mdui-ripple">删除账号</a>
    
    <div class="mdui-dialog" id="example-4$i">
  <div class="mdui-tab mdui-tab-full-width" id="example4-tab$i">
    <a href="#example4-tab1$i" class="mdui-ripple">监控接口</a>
    <a href="#example4-tab2$i" class="mdui-ripple">更多接口/监控</a>
    <a href="#example4-tab3$i" class="mdui-ripple">温馨提示</a>
  </div>
  <div id="example4-tab1$i" class="mdui-p-a-2">
    <p>当前批量管理后端监控接口为
    <p>(也就是实现自动回复等功能的接口)</p>
    <p>http://$dqdz/xiaojnjk.php?u=$uid&id=$i&jkkey=$jkkey&hz=后缀</p>
      <p>其他监控接口</p>
       <p>自动签到http://$dqdz/autoqd.php?phone=$n&key=$keyx</p>
       <p>自动取关没互关的人http://$dqdz/autoqgapi.php?phone=$n&key=$keyx</p>
        <p>自动乞讨http://$dqdz/qthljn.php?phone=$n&key=$keyx</p>
        自动删乞讨回复http://$dqdz/sthfs.php?phone=$n&key=$keyx</p>
       
     
  </div>
  <div id="example4-tab2$i" class="mdui-p-a-2">
    <p>百度免费监控网，或者你直接用首页的也行</p>
    <a href="/jkcz.php">官方免费监控一键使用，无需注册</a>
      <br> 更多接口
       <p>自动顶帖接口http://$dqdz/yyjk.php?phone=$n&key=$keyx</p>
          <p>自动水帖接口http://$dqdz/xiaojnaist.php?phone=$n&key=$keyx</p>
          <p>自动卖关注接口http://$dqdz/mgz.php?phone=$n&key=$keyx</p>
    <p>挂上网址监控即可完成全自动化</p>
    <p>添加网址监控</p>
    <p>监控间隔即为回复间隔时间</p>

  </div>
  <div id="example4-tab3$i" class="mdui-p-a-2">
     <br>        各位大佬你们挂监控正常一点
<br>1.不要把多个网址粘到一个编辑框里去
<br>2.不要把监控间隔设置在30秒以内
<br>以下是我们的建议间隔
<br>1.自动回复最好30到60秒
<br>2.自动签到1分钟一次
<br>3.自动乞讨顶帖之类的，就跟自动回复差不多好了
<br>4.自动水帖，你至少设置个10分钟间隔吧，要不然频繁发不出去的
<br>5.自动卖关注和自动回复一样，起码要30到60秒
<br>谢谢合作!!!!!＼（〇_ｏ）／
    <p>官Q:1032050534</p>
     <p>欢迎⊙ω⊙</p>
      <p>。。。。。</p>
  </div>
</div>
<script>
  var tab = new mdui.Tab('#example4-tab$i');
  document.getElementById('example-4').addEventListener('open.mdui.dialog', function () {
    tab.handleUpdate();
  });
</script>
  <!-- 卡片头部，包含头像、标题、副标题 -->
  <div class="mdui-card-header">
    <img class="mdui-card-header-avatar" src="jqr2.png"/>
    <div class="mdui-card-header-title">$name</div>
    <div class="mdui-card-header-subtitle">$phone</div>
  </div>

 

    <!-- 卡片中可以包含一个或多个菜单按钮 -->
   
  </div>

EOF;

}
}
else {
   echo
   <<<EOF
   <div class="mdui-card">
  <div class="mdui-card-media">
    <img src="xiaogz.jpg"/>
    <div class="mdui-card-media-covered mdui-card-media-covered-transparent">
      <div class="mdui-card-primary">
        <div class="mdui-card-primary-title"></div>
        <div class="mdui-card-primary-subtitle"></div>
      </div>
    </div>
  </div>
  <div class="mdui-center" style="width: 200px">大佬，你还一个批量管理都没有呢</div>
EOF;
    
    
}

}
?>

    
  </div>
</div>




    
	</div>




</body>
</html>
