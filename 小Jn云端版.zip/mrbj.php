<?php setcookie("bj");
    Header("Location:/tool.php")   ?>