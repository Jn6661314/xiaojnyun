<?php 
error_reporting(0);
setcookie("key");
setcookie("uid");
setcookie("phone");
setcookie("name");
Header("Location:/tool.php")   ?>