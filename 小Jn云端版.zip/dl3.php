<?php
error_reporting(0);

 
/**
 * 发送葫芦侠APP请求，PS：因为和本地完全一致，会顶登录
 * @葫芦侠最新版登录模块（Jn版权所有）
 */
function send_post($url, $post_data) {
 
  $postdata = http_build_query($post_data);
  $options = array(
    'http' => array(
        "Host"=>"floor.huluxia.com",
      'method' => 'POST',
      'header' => 'Content-type:application/x-www-form-urlencoded',
      'content' => $postdata,
      "User-Agent"=>'okhttp/3.8.1',
      'timeout' => 15 * 60 // 超时时间（单位:s）
    )
  );
  $context = stream_context_create($options);
  $result = file_get_contents($url, false, $context);
  
$arr = json_decode($result, true);
// Access values from the associative array


//屏蔽错误
ini_set("error_reporting","E_ALL & ~E_NOTICE");
//批量管理



 $filename='my.txt';
 $ex=file_exists($filename);//检测文件存在与否
if($ex==1)
{
$b=file($filename);
$c=count($b)/1;
$d=$c;
 

$h=$b[$yi];
$number=$text=str_replace(array("/r", "/n", "/r/n"), "", $h);

//截取后部分

 $key = substr($number,strripos($number,"----")+4);

//截取前面部分

$phone = substr($text,0,strrpos($text,"----"));

    
   

 $filename='my.txt';
 $ex=file_exists($filename);//检测文件存在与否



//关注

$i=$_GET["id"];
if ($i==null)
 {
    $i=1;
}else{$i=$_GET["id"];}
     
$h=$b[$i];
$number=$text=str_replace(array("/r", "/n", "/r/n"), "", $h);

//截取后部分

 $key = substr($number,strripos($number,"----")+4);

//截取前面部分

 $phone = substr($text,0,strrpos($text,"----"));








    $i2=$i+1;
    "<br>已操作:".$i."，个，共:".$c."个";
     $b=$i+1;

}
 $jnsb=$arr["msg"];
 if($jnsb==null)
 {echo$arr["_key"];
 
 
 
 }
 else
 {echo $jnsb;}


 setrawcookie("uid",$uid,time()+2592000);
  return $result;
    
 
}
 
//使用方法：GET本JnAPI接口两参数就完事了，分别是phone和key
$post_data = array(
  'account' => $phone,
  'login_type' => '2',
  'password'=>md5($key)
);
send_post('http://floor.huluxia.com/account/login/ANDROID/4.0?platform=2&gkey=000000&app_version=4.1.1.6.2&versioncode=335&market_id=tool_tencent&_key=&device_code=%5Bd%5Df6ec92f3-e2e4-43bc-a7f6-53677fe4d1a9&phone_brand_type=HW', $post_data);


