<?php ob_start(); ?>
<?php
error_reporting(0);

if($_COOKIE["s"]!=null){
echo'<meta http-equiv="refresh" content="0.3;url=/"> ';
Header("Location: /tool.php");
ob_end_flush();
}
setrawcookie("s","huajimc",time()+3600 * 24 * 365);
?>
<link rel="stylesheet" href="css/index.css" />
	<!--可无视-->
	<link rel="stylesheet" type="text/css" href="css/bootstrap-grid.min.css" /><!--CSS RESET-->

	
	<!--必要样式-->
	<link rel="stylesheet" href="css/naranja.min.css">
	<?php

    echo
<<<EOF
<!DOCTYPE html>
<html lang="zh">
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<title>小Jn葫芦侠批量管理</title>
		<meta name="keywords"  content="小Jn,Jn,葫芦侠工具箱，葫芦侠批量管理"/>
        <meta name="description"  content="本站为小Jn官网、小Jn葫芦侠批量管理功能包括有葫芦侠自动回复，自动水帖，自动乞讨、自动签到、自动卖关注、转移葫芦、批量点赞、批量关注、发涩图，等"/>
      
		<link href="css/bootstrap.min.css" rel="stylesheet">
		<link href="css/font-awesome.min.css" rel="stylesheet">
		<link href="css/owl.carousel.min.css" rel="stylesheet">
		<link href="css/owl.theme.min.css" rel="stylesheet">
		<link rel="shortcut icon" href="images/promo-logo.png"> 
		<link href="css/style.css" rel="stylesheet">
		<link href="css/responsive.css" rel="stylesheet">

	</head>	
	
	<body data-spy="scroll" data-target=".nav-top">
		<header id="home" data-spy="scroll" data-target="#top-nav">
			<div class="navbar navbar-default navbar-fixed-top default-menu menu-4" role="navigation">
						<div class="container">
							<div class="navbar-header">
							
									<span class="sr-only">Jn</span>
									<span class="icon-bar"></span>
									<span class="icon-bar"></span>
									<span class="icon-bar"></span>
							
								<a class="navbar-brand default-logo scroll" href="#home"><img src="images/logo.png" alt="logo"> 小Jn</a>
							</div>

							
								
					
						</div>
					</div>		
		</header>
		<section id="intro" class="intro">
			<div class="container">
				<div class="row">
					<div class="col-md-6 col-sm-8 col-xs-12">
						<div class="intro-content">
							<h1>小Jn</h1>
							<p>一款强大免费的葫芦侠批量管理!与现有登录冲突，本地24h随时运行，不会因攻击掉线!</p>
							<h5><a href="/tool.php" role="button"><ajn>立即开始 <i class="lnr lnr-arrow-down"></i></a></ajn></h5>
						</div>
					</div>
					<!--<div class="col-md-6 col-sm-8 col-xs-12">
						<div><img src="images/intro-image.png" class="img-responsive" alt="intro-image"></div>
					</div>	-->
				</div>
			</div>
		</section>
		<section id="support" class="support">
			<div class="container">
				<div class="row">
					<div class="col-md-10 col-md-offset-1">
						<div class="row">
							<div class="col-md-4">
								<div class="media">
									<div class="media-left media-middle">
										<i class="fa fa-html5 fa-fw"></i>
									</div>
									<div class="media-body">
										<h3>1.操作环境</h3>
										<p>你需要一个ARM64的安卓设备，往后仅需一个浏览器即可</p>
									</div>
								</div>
							</div>							
							<div class="col-md-4">
								<div class="media">
									<div class="media-left media-middle">
										<i class="fa fa-chain-broken fa-fw"></i>
									</div>
									<div class="media-body">
										<h3>2.关于网站</h3>
										<p>您想要个自己的小Jn的网站？我们的项目是开源的!你可以在我们的群里等待源码公开！</p>
									</div>
								</div>
							</div>
                            <div class="col-md-4">
								<div class="media">
									<div class="media-left media-middle">
										<i class="fa fa-connectdevelop fa-fw"></i>
									</div>
									<div class="media-body">
										<h3>3.真正的公益项目</h3>
										<p>永久免费，登录即可立即使用!</p>
									</div>
								</div>
							</div>							
						</div>
					</div>
				</div>
			</div>	
		</section>
		
		
		<section id="service" class="service">
			<div class="container">
				<div class="row">
					<div class="col-md-8 col-md-offset-2 text-center">  
						<h1 class="section-title">我们的服务
						<p class="section-para">不忘初心，方得始终。从不敢对任何一位大佬小白的需求稍做懈怠，才能创造今天的成就</p>
					</h1></div>
				</div>   
				<div class="row">
					<div class="col-md-12">
						<div class="row">
							<div class="col-md-3 col-sm-6 col-xs-12">
								<div class="media">
									<div class="media-left">
										<i class="lnr lnr-screen"></i>
									</div>
									<div class="media-body">
										<h3 class="media-heading">公益方案</h3>
										<p>不收取一点手续费，不收取任何开始费用，直接免费使用永久！</p>
									</div>
								</div>
								
								<div class="media">
									<div class="media-left">
										<i class="lnr lnr-screen"></i>
									</div>
									<div class="media-body">
										<h3 class="media-heading">赞助永远自愿</h3>
										<p>真正的永久免费</p>
									</div>
								</div>
							</div>
							<div class="col-md-3 col-sm-6 col-xs-12">
								<div class="media">
									<div class="media-left">
										<i class="lnr lnr-laptop-phone"></i>
									</div>
									<div class="media-body">
										<h3 class="media-heading">自由度超高的批量管理</h3>
										<p>您可以DIY批量管理，批量管理的每一个功能都可以开启关闭，比如大号可以不开自动回复，只开您需要的功能，实现大号小号都能开批量管理!</p>
									</div>
								</div>
								<div class="media">
									<div class="media-left">
										<i class="lnr lnr-screen"></i>
									</div>
									<div class="media-body">
										<h3 class="media-heading">强大的Jn工具</h3>
										<p>为您实现UID获取，一键签到，自定义标签，转移葫芦，AI水帖，自动回复，自动一言，一键乞讨等强大功能!</p>
									</div>
								</div>
							</div>
							<div class="col-md-3 col-sm-6 col-xs-12">
								<div class="media">
									<div class="media-left">
										<i class="lnr lnr-tablet"></i>
									</div>
									<div class="media-body">
										<h3 class="media-heading">多维共存</h3>
										<p>批量管理支持前端和后端运行，与软件（指葫芦侠与葫芦侠我的世界）登录冲突，选择多样，服务周全!</p></p>
									</div>
								</div>
								<div class="media">
									<div class="media-left">
										<i class="lnr lnr-screen"></i>
									</div>
									<div class="media-body">
										<h3 class="media-heading">起源与开源</h3>
										<p>基于三个产品(Jn工具箱，葫芦侠在线版，Jn批量管理)的技术沉淀，小Jn于2021年1月23日发起项目搭建
										<p></p>项目正式发布成立</p>
									</div>
								</div>
							</div>
							<div class="col-md-3 col-sm-6 col-xs-12">
								<div class="media">
									<div class="media-left">
										<i class="lnr lnr-laptop"></i>
									</div>
									<div class="media-body">
										<h3 class="media-heading">仍有顾虑?</h3>
										<p>如果您仍抱有顾虑，欢迎加交流群了解!</p>
									</div>
								</div>
								<div class="media">
									<div class="media-left">
										<i class="lnr lnr-screen"></i>
									</div>
									<div class="media-body">
										<h3 class="media-heading">更多服务</h3>
										<p>代建啥的都行!详情<a href="https://jq.qq.com/?_wv=1027&k=gVswkJOl">联系我们</a>以询问</p>
									</div>
								</div>
							</div>
						</div>   
					</div>   
				</div>   
			</div>
		</section>
		<section class="about-us">
			<div class="container">
				<div class="row">
					<div class="col-md-5 col-xs-12">
						<div class="about-content">
							<h1 class="section-title">关于我们</h1>
							<p>小Jn批量管理项目成立于2021年2月！</p>
							<a class="btn btn-default" href="http://wpa.qq.com/msgrd?v=3&uin=1032050534&site=qq&menu=yes" role="button" target="blank">和我们一起讨论 <i class="lnr lnr-arrow-right"></i></a>
						</div> 
					</div>
					<div class="col-md-7 col-xs-12">
						<div class="about-img"><img class="img-responsive" src="images/about-us.png" alt="about us image"></div>
					</div>
				</div>
			</div>
		</section>
		
		
		<section id="portfolio" class="work">
			<div class="container">
				<div class="row">
					<div class="col-md-8 col-md-offset-2 text-center">  
						<h1 class="section-title">我们的特点
						<p class="section-para">不向复杂与臃肿妥协，不向低端与低劣低头，始终迎合大佬小白需求</p>
					</h1></div>
				</div>
				
				<div class="row">
					<div class="col-md-3">
						<div class="project-box">
							<div class="project-img">
								<a target="blank" href="jqrcz.php"><img src="jqr.png" alt class="img-responsive"></a>
							</div>
							<div class="project-text">
							<h3>小Jn葫芦侠AI</h3>
									<a target="blank" href="/tool.php"><img src="images/aog-1.jpg" alt class="img-responsive"></a>
								<p>小Jn葫芦侠自动回复，整合了自动卖关注，我要关注，自动水帖，自动乞讨等强大功能，葫芦粉丝升升升，成为最靓的那个仔!</p>
							</div>
						</div>
					</div>
				</div>
				<div class="row">
					<div class="col-md-3">
						<div class="project-box">
							<div class="project-img">
								<a target="blank" href="box.php"><img src="images/aog-2.jpg" alt class="img-responsive"></a>
							</div>
							<div class="project-text">
							<h3>Jn工具</h3>
									<a target="blank" href="/tool.php"></a>
								<p>葫芦侠一键签到，转移葫芦，自定义标签等</p>
							</div>
						</div>
					</div>
				</div>
								
			</div>
		</section>
		
		
		<section id="team" class="our-experts">
			<div class="container">
				<div class="row">
					<div class="col-md-8 col-md-offset-2 text-center">  
						<h1 class="section-title">小Jn开发者团队
						<p class="section-para">点击头像查看联系方式</p>
					</h1></div>
				</div>
				<div class="row">
					<div class="col-sm-3">
						<div class="expert-box">
							<img src="http://q1.qlogo.cn/g?b=qq&nk=3413517512&s=640" alt>
							<div class="expert-overflow">
							QQ 保密<br>
							Email 保密@qq.com
							</div>
							<div class="name-plate text-center">
								<h3 class="expert-name">滑稽MC</h3>滑稽MC怎么会开发这种垃圾</h3>								
								<font><i class="fa fa-user">创始人，总开发，总策划，总投资</i></font><br>
								<font><i class="fa fa-map-marker">湖南 - 娄底</i></font>
							</div>
						</div>
					</div>
					<div class="col-sm-3">
						<div class="expert-box">
							<img src="http://q1.qlogo.cn/g?b=qq&nk=2760415735&s=640" alt>
							<div class="expert-overflow">
							QQ 2760415735<br>
							Email 2760415735@qq.com
							</div>
							<div class="name-plate text-center">
								<h3 class="expert-name">小狗杂</h3>
								<font><i class="fa fa-user">小Jn第一个使用者</i></font><br>
								<font><i class="fa fa-map-marker">搬砖，魔改大佬</i></font>
							</div>
						</div>
					</div>

						</div>
					</div>
				</div>
			</div>	
		</section>
		
		
		<section id="contact" class="contact">
			<div class="container">
				<div class="row">
					<div class="col-md-8 col-md-offset-2 text-center">  
						<h1 class="section-title">联系我们
						<p class="section-para">让您的需求得到最快速的回复!!!</p>
					</h1></div>
				</div>
			<h5 align="center">想开始使用? <a href="/tool.php">点击打开</a>!!! 如有打广告，商业合作需求，请找滑稽MC</h5><br>
			<h5 align="center">我们的交流QQ群为：<a target="blank" href="https://jq.qq.com/?_wv=1027&k=p5ZfcLhV">1032050534</a></h5>
		</div></section>
		

		<footer class="footer">
			<div class="container">
				<div class="row">
					<div class="col-md-12 col-sm-12 col-md-12 text-center">
						<p>&copy Copyright 2020 滑稽MC All Rights Reserved.	<div style="width:300px;margin:0 auto; padding:20px 0;">
		 		<a target="_blank" href="http:///" style="display:inline-block;text-decoration:none;height:20px;line-height:20px;"><img src style="float:left;"><p style="float:left;height:20px;line-height:20px;margin: 0px 0px 0px 5px; color:#939393;"></p></a>
		 		<script type="text/javascript">document.write(unescape("%3Cspan id='cnzz_stat_icon_1279812358'%3E%3C/span%3E%3Cscript src='https://s9.cnzz.com/z_stat.php%3Fid%3D1279812358%26online%3D1%26show%3Dline' type='text/javascript'%3E%3C/script%3E"));</script>
		 	</div></p>
					</div>
				</div>
			</div>	
		</footer>
		<script src="js/jquery.min.js"></script>
		<script src="js/bootstrap.min.js"></script>
		<script src="js/owl.carousel.min.js"></script>
		<script src="js/custom.js"></script>
</body>
</html></div>
EOF;
// }