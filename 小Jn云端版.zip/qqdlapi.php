<?php ob_start(); ?><!doctype html>
<html lang="zh-cmn-Hans">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, shrink-to-fit=no"/>
    <meta name="renderer" content="webkit"/>
    <meta name="force-rendering" content="webkit"/>
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"/>

    <!-- MDUI CSS -->
    <link rel="stylesheet" href="https://unpkg.com/mdui@1.0.2/dist/css/mdui.min.css"/>
    
  </head>
  <body>
   

    <!-- MDUI JavaScript -->
    <script src="https://unpkg.com/mdui@1.0.2/dist/js/mdui.min.js"></script>
  </body>
</html><div class="mdui-typo-display-3"><div class="mdui-typo-display-3">

<?php
ini_set("display_errors","off");
$kw=$_GET["txt"];
if($kw==null){$kw=$_COOKIE["qq"];}
$mark1="id=";
$mark2="&access_token=";
$st =stripos($kw,$mark1);
$ed =stripos($kw,$mark2);
//ID
$id=mb_substr($kw,($st+3),($ed-$st)-19,'UTF-8');
	$mark1="access_token=";
$mark2="&pay_token";
$st =stripos($kw,$mark1);
$ed =stripos($kw,$mark2);
//KEY
$key=mb_substr($kw,($st+13),($ed-$st)-13,'UTF-8');
//请求
$url="http://floor.huluxia.com/qq/login/ANDROID/2.1?platform=2&gkey=&device_code=&market_id=floor_web&app_version=&versioncode=&access_token=".$key."&openid=".$id;


$ch = curl_init();

curl_setopt($ch, CURLOPT_URL,$url);

curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);

curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);//如果把这行注释掉的话，就会直接输出 

 $dl = curl_exec($ch); 
 
 //分析信息
 $returnJson=json_decode($dl,true);
$msg=$returnJson["msg"];
$key=$returnJson["_key"];
$uid=$returnJson["user"]["userID"];
 $name=$returnJson["user"]["nick"];
 $jnsb=$key;
 if($jnsb!=null){
 //{echo'{"key":'.$arr["_key"].', "uid":'.$arr["user"]["userID"].'}';
 echo"登录成功";
 
    setrawcookie("name",$name,time()+3600 * 24 * 365);
    setrawcookie("uid",$uid,time()+3600 * 24 * 365);
   
      setrawcookie("ekey",$jnsb,time()+3600 * 24 * 365);
            setrawcookie("qq",$_GET["txt"],time()+3600 * 24 * 365);


Header("Location: /tool.php");ob_end_flush();
  }else
 {echo $msg;
 setrawcookie("qq","",time()+3600 * 24 * 365);}
//iapp源码（参考用的，没什么实际作用）
//ss("http://floor.huluxia.com/qq/login/ANDROID/2.1?platform=2&gkey=&device_code=&market_id=floor_web&app_version=&versioncode=&access_token="+KEY+"&openid="+ID+"",葫芦侠信息)
 // hs(葫芦侠信息,null,"utf-8",null,true,"",数据返回)
//  json(数据返回,数据返回)
//  json(数据返回,"get","_key",sss.葫芦侠key)
 // json(数据返回,"get","user",sss.u)
 // json(sss.u,"get","userID",sss.uid)