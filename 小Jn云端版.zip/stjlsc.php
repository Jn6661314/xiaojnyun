<?php
setrawcookie("hulu","0",time()+2592000000000);

?>
已删除