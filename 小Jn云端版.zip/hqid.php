
<?php 

//屏蔽错误
error_reporting(0);
//调用本地数据



?>
<!doctype html>
<html lang="zh-cmn-Hans">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, shrink-to-fit=no"/>
    <meta name="renderer" content="webkit"/>
    <meta name="force-rendering" content="webkit"/>
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"/>

    <!-- MDUI CSS -->
    <link
      rel="stylesheet"
      href="https://unpkg.com/mdui@1.0.2/dist/css/mdui.min.css"

    />
    <title>小Jn消息中心</title>
  </head>
  <body>
        <body class="mdui-appbar-with-toolbar">
  <div class="mdui-appbar mdui-appbar-fixed mdui-appbar-scroll-hide">
    <div class="mdui-toolbar mdui-color-theme">
  <a href="javascript:window.history.back();" class="mdui-btn mdui-btn-icon"><i class="mdui-icon material-icons">keyboard_arrow_left</i></a>
  <span class="mdui-typo-title">小Jn</span>
  <div class="mdui-toolbar-spacer"></div>
  
  

  <a href="javascript:location.reload();" class="mdui-btn mdui-btn-icon"><i class="mdui-icon material-icons">refresh</i></a>
<button class="mdui-btn mdui-btn-icon" mdui-menu="{target:'#main-menu'}"><i class="mdui-icon material-icons">more_vert</i></button>

<ul class="mdui-menu" id="main-menu">
jnyyds
              
            </ul>
  		</div>
	</div>
		<script src="./js/mdui.min.js"></script> 	  <script>     if(localStorage.darkTheme)         document.body.classList.add("mdui-theme-layout-dark");      document.getElementById("switch-theme").addEventListener(         "click",         () => document.body.classList.toggle("mdui-theme-layout-dark") ?             (localStorage.darkTheme = true) :             (delete localStorage.darkTheme)     );  </script><p id="switch-theme">>点此切换黑白</p> <script>      if(localStorage.darkTheme)         document.body.classList.add("mdui-theme-layout-dark");           document.getElementById("switch-theme").addEventListener(         "click",         () => document.body.classList.toggle("mdui-theme-layout-dark") ?             (localStorage.darkTheme = true) :             (delete localStorage.darkTheme)     ); </script>          	</li>             </ul>   		</div> 	</div> 	
	<script src="./js/jquery.min.js"></script>
	<script type="text/javascript" charset="utf-8">
	  $(window).scroll(function(){
	    var scrollTop = $(window).scrollTop();
	   if (scrollTop < 100) {
	      $(".mdui-APPbar").removeClass("mdui-color-theme");
          $(".mdui-APPbar").addClass("mdui-text-color-black");
          $(".mdui-APPbar").removeClass("mdui-text-color-white")
	   } else {
	      $(".mdui-APPbar").addClass("mdui-text-color-white");
	      $(".mdui-APPbar").addClass("mdui-color-theme");
	      $(".mdui-APPbar").removeClass("mdui-text-color-black");
	   }
	  });
	</script>
 
</div>


    <!-- MDUI JavaScript -->
    <script
      src="https://unpkg.com/mdui@1.0.2/dist/js/mdui.min.js"

    ></script>
  </body>
</html>


<?php

//<!--判断是否登陆-->


$pl=file_get_contents("http://floor.huluxia.com/friendship/following/list/ANDROID/2.0?platform=2&gkey=000000&app_version=4.1.1.8.2&versioncode=344&market_id=tool_tencent&_key=".$jnyun=$_GET["key"]."&device_code=%5Bd%5D19e64e24-e8ae-4e97-9f4a-7983c918a962&phone_brand_type=HW&start=0&count=48&user_id=".$_GET["u"]);

$jsonStr = $pl;

$arr = json_decode($pl,true);


for($i=0;$i<48;$i++)
{
//超级获取术

$user=$arr["friendships"][$i]["user"]["userID"];//用户ID
$tx=$arr["friendships"][$i]["user"]["avatar"];//头像
$name=$arr["friendships"][$i]["user"]["nick"];//昵称


echo <<<EOF
 



<html>
 <head> 
  <meta charset="utf-8"> 
  <!--响应式--> 
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no"> 
  <script src="js/jq.js"></script> 
 </head> 
 <ul class="mdui-list">
 <body id="v1"> 
 <br><li class="mdui-list-item mdui-ripple">
 <hr id="v2">
   <img src=$tx alt=$name id="v7" height="30" width="30">
   
  </br>
  <br>
  <p>$name</p></a>
  </br>
  <br>
  
  </br>
  uid:$user
  <script src="https://cdn.bootcss.com/clipboard.js/1.7.1/clipboard.min.js"></script>
<script src="https://code.jquery.com/jquery-3.3.1.min.js"></script>
<div><span id="btn$user" data-clipboard-text="$user">一键复制</span></div>
<div id="show$user" style="display: none;">已复制</div>
<script>
	var btn=document.getElementById('btn$user');
	var clipboard=new Clipboard(btn$user);
	clipboard.on('success', function(e){
		$('#show$user').slideDown().delay(1500).slideUp(300);
		console.log(e);
	});
	clipboard.on('error', function(e){
		$('#show$user').slideDown().delay(1500).slideUp(300);
		console.log(e);
	});
</script>
 
  
  

  </li>
  </ul>
 </body>
</html>
EOF;

}
?>

<div class="mdui-panel" mdui-panel>



  