<?php
//登录
//error_reporting(0);
$curl = curl_init();


$ip_long = array(
       array('607649792', '608174079'), //36.56.0.0-36.63.255.255
       array('1038614528', '1039007743'), //61.232.0.0-61.237.255.255
       array('1783627776', '1784676351'), //106.80.0.0-106.95.255.255
       array('2035023872', '2035154943'), //121.76.0.0-121.77.255.255
       array('2078801920', '2079064063'), //123.232.0.0-123.235.255.255
       array('-1950089216', '-1948778497'), //139.196.0.0-139.215.255.255
       array('-1425539072', '-1425014785'), //171.8.0.0-171.15.255.255
       array('-1236271104', '-1235419137'), //182.80.0.0-182.92.255.255
       array('-770113536', '-768606209'), //210.25.0.0-210.47.255.255
       array('-569376768', '-564133889'), //222.16.0.0-222.95.255.255
   );
   $rand_key = mt_rand(0, 9);
   $ip= long2ip(mt_rand($ip_long[$rand_key][0], $ip_long[$rand_key][1]));
$header = array("Connection: Keep-Alive","Accept: text/html, application/xhtml+xml, */*", "Pragma: no-cache", "Accept-Language: zh-Hans-CN,zh-Hans;q=0.8,en-US;q=0.5,en;q=0.3","User-Agent: okhttp/3.8.1");

	curl_setopt($curl,CURLOPT_URL,'http://floor.huluxia.com/account/login/ANDROID/4.0?platform=2&gkey=000000&app_version=4.1.1.6.2&versioncode=335&market_id=tool_tencent&_key=&phone_brand_type=UN&device_code=[d]16485814-230d-424c-8af1-fda8f42d1e25&password='.md5($_GET["key"]).'&login_type=2&account='.$_GET["phone"]."%0A");
	curl_setopt($curl,CURLOPT_RETURNTRANSFER,1);
	curl_setopt($curl,CURLOPT_CONNECTTIMEOUT,10);
	curl_setopt($curl,CURLOPT_FOLLOWLOCATION,1);
	curl_setopt($curl, CURLOPT_HTTPHEADER, $header);
	//curl_setopt($curl,CURLOPT_HTTPHEADER,['X-FORWARDED-FOR:164.89.81.12','CLIENT-IP:164.89.81.12']);
	curl_setopt($curl,CURLOPT_REFERER,'');
	curl_setopt($curl,CURLOPT_USERAGENT,'okhttp/3.8.1');
	$post= curl_exec($curl);
	curl_close($curl);
	$arr = json_decode($post, true);
// Access values from the associative array

$jnsb=$arr["_key"];
if($jnsb!=null){
//{echo'{"key":'.$arr["_key"].', "uid":'.$arr["user"]["userID"].'}';
//echo"good";
$userMsg=file_get_contents("http://floor.huluxia.com/user/info/ANDROID/2.1?_key=".$jnsb."&user_id=".$arr["user"]["userID"]);
$user=json_decode($userMsg,true);
$name=$user["nick"];
$returnJson=json_decode($post,true);
$msg=$returnJson["msg"];
$key=$returnJson["_key"];
$uid=$returnJson["user"]["userID"];
}else{exit("登录失败");}

$wcnm=file_get_contents("http://floor.huluxia.com/message/new/list/ANDROID/4.0?platform=2&gkey=000000&app_version=4.1.1.2.2&versioncode=318&market_id=tool_tencent&_key=".$key."&device_code=%5Bw%5D02%3A00%3A00%3A00%3A00%3A00%5Bd%5De2f734cc-549b-4349-a311-244c64fcc71e&type_id=2&start=0&count=1");
$returnJsonhl=json_decode($wcnm,true);
$arr2 = json_decode($wcnm,true);
//超级获取术
echo"<p>他人评论内容：".$a=$arr2["datas"][0]["content"]["text"]."</p>";//评论内容
echo"<p>评论ID:".$plid=$arr2["datas"][0]["content"]["commentID"]."</p>";//评论ID
echo"<p>该评论人ID:".$user=$arr2["datas"][0]["content"]["user"]["userID"]."</p>";//用户ID
$tx=$arr2["datas"][0]["content"]["user"]["avatar"];//头像
echo"<p>该评论人昵称:".$name=$arr2["datas"][0]["content"]["user"]["nick"]."</p>";//昵称



$ys=$arr2["datas"][0]["content"]["seq"];//楼层
$plid=$arr2["datas"][0]["content"]["commentID"];//评论ID

echo$hlsq=$returnJsonhl["datas"][0]["content"]["score"];

//tzid获取
$get = "http://floor.huluxia.com/message/new/list/ANDROID/4.0?platform=2&gkey=000000&app_version=4.0.1.7&versioncode=300&market_id=tool_tencent&_key=".$key."&device_code=%5Bw%5D02%3A00%3A00%3A00%3A00%3A00%5Bd%5De2f734cc-549b-4349-a311-244c64fcc71e&type_id=2&start=0&count=1";
   $pl = file_get_contents($get);
    $pl_begin = mb_strpos($pl,',"title":"') + mb_strlen(',"title":"');//提取的开始位置
$pl_end = mb_strpos($pl,'","ext":null,"detail":null,"') - $pl_begin;//提取的结束位置
$plw = mb_substr($pl,$pl_begin,$pl_end);
$h = $plw;
$id = file_get_contents($get);
    $id_begin = mb_strpos($id,'{"postID":') + mb_strlen('{"postID":');//提取的开始位置
$id_end = mb_strpos($id,',"title":"'.$h) - $id_begin;//提取的结束位置
$tzid = mb_substr($id,$id_begin,$id_end);
//读取记录
$myfilert2 = fopen("1.txt", "r") or die("Unable to open file!");
$f2 = fread($myfilert2,filesize("1.txt"));
fclose($myfilert2);
$plid=$arr2["datas"][0]["content"]["commentID"];//评论ID
if(strpos($plid,$f2))
{echo"已回复，空参数防止多次回复";}else{
if($hlsq>0)
{
    //执行关注

$user=$arr2["datas"][0]["content"]["user"]["userID"];
    $gzdf = "http://floor.huluxia.com/friendship/follow/ANDROID/2.0?user_id=".$user."&platform=2&gkey=000000&app_version=4.0.1.7&versioncode=300&market_id=tool_tencent&_key=".$key."&device_code=%5Bw%5D02%3A00%3A00%3A00%3A00%3A00%5Bd%5De2f734cc-549b-4349-a311-244c64fcc71e";
   echo "关注返回信息".$gzgzgz = file_get_contents($gzdf);
   
$url3 = "http://floor.huluxia.com/comment/create/ANDROID/2.0?platform=2&gkey=000000&app_version=4.0.1.7&versioncode=300&market_id=tool_tencent&_key=".$key."&device_code=%5Bw%5D02%3A00%3A00%3A00%3A00%3A00%5Bd%5De2f734cc-549b-4349-a311-244c64fcc71e&post_id=".$tzid."&comment_id=".$plid."&text=关注你了!".$sjs;
     $zt = file_get_contents($url3);
     $jsonStr = $zt;

$arr2 = json_decode($zt,true);
     echo"<p>处理状态：" .$plw=$arr2["msg"]."</p>"; 
      //记录

    $myfile2 = fopen("1.txt", "w") or die("Unable to open file!");
$txt2 = $f2.$plid."\n";
fwrite($myfile2, $txt2);
fclose($myfile2);

}else{echo"这个逼没有给你葫芦，本AI坚决不关注他";}}