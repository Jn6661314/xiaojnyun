<?php
//批量管理
 $filename='my.txt';
 $ex=file_exists($filename);//检测文件存在与否
if($ex==1)
{
$b=file($filename);
$c=count($b)/1;
$d=$c;
 

$h=$b[$yi];
$number=$text=str_replace(array("/r", "/n", "/r/n"), "", $h);

//截取后部分

 $key = substr($number,strripos($number,"----")+4);

//截取前面部分

$phone = substr($text,0,strrpos($text,"----"));

 $filename='my.txt';
 $ex=file_exists($filename);//检测文件存在与否

//关注

$i=$_GET["id"];
     
$h=$b[$i];
$number=$text=str_replace(array("/r", "/n", "/r/n"), "", $h);

//截取后部分

 $key = substr($number,strripos($number,"----")+4);

//截取前面部分

 $phone = substr($text,0,strrpos($text,"----"));

echo'{"key":'.$key.', "p":'.$phone.'}';
}